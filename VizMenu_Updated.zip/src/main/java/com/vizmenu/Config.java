package com.vizmenu;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.util.math.MathHelper;

import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

public class Config {
    public static Config I = new Config();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    /** Position (in % of the screen), scale and background of a HUD element. */
    public static class HudBox {
        public boolean bg = true;
        public double x = 0;
        public double y = 0;
        public double scale = 1.0;

        public HudBox() {}

        public HudBox(double x, double y) {
            this.x = x;
            this.y = y;
        }
    }

    // ---- general
    public int cfgVersion = 0;
    public boolean openOnRightClick = true;
    public Map<String, Integer> binds = new HashMap<>();

    // ---- HUD
    public boolean watermark = true;
    public boolean wmVersion = true;
    public boolean wmAnim = true;
    public HudBox wmBox = new HudBox(1, 1);

    public boolean crosshair = false;
    public int chStyle = 0;          // 0 cross, 1 dot, 2 circle, 3 cross + dot
    public double chSize = 6;
    public double chThick = 1;
    public double chGap = 3;
    public int chColorMode = 0;      // 0 white, 1 custom, 2 rainbow
    public double chHue = 270;
    public double chAlpha = 1.0;
    public boolean chOutline = true;
    public boolean chDynamic = false;
    public boolean chTargetRed = true;

    public boolean fps = true;
    public HudBox fpsBox = new HudBox(1, 9);

    public boolean coords = true;
    public int coordsDecimals = 0;
    public boolean coordsDir = true;
    public boolean coordsNether = false;
    public HudBox coordsBox = new HudBox(1, 16);

    public boolean armorHud = true;
    public boolean armorVertical = true;
    public int armorDurability = 1; // 0 off, 1 number, 2 percent
    public HudBox armorBox = new HudBox(1, 45);

    public boolean potionHud = true;
    public boolean potionHideVanilla = true;
    public int potionStyle = 0; // 0 detailed, 1 compact
    public boolean potionBars = true;
    public HudBox potionBox = new HudBox(100, 4);

    // ---- Combat
    public boolean cps = false;
    public HudBox cpsBox = new HudBox(1, 30);

    public boolean targetInfo = false;
    public boolean targetNumber = true;
    public HudBox targetBox = new HudBox(50, 62);

    public boolean killFx = false;
    public int killMode = 2;         // 0 lightning, 1 spirit, 2 both
    public int killColor = 0;        // 0 electric, 1 purple, 2 rainbow, 3 white
    public boolean killPlayersOnly = false;

    public boolean esp = false;
    public int espMode = 0;          // 0 orbs + ring, 1 orbs, 2 ring
    public int espColor = 0;         // 0 gradient, 1 purple, 2 rainbow, 3 white
    public double espOrbs = 4;
    public double espSize = 1.0;
    public double espSpeed = 1.0;

    // ---- Movement
    public boolean autoSprint = false;
    public boolean trail = false;
    public int trailMode = 0;        // 0 ribbon, 1 dots, 2 particles
    public int trailColor = 0;       // 0 gradient, 1 purple, 2 rainbow
    public double trailThick = 3;
    public boolean trailLanding = true;
    public int trailStyle = 0;       // particle style (mode 2)
    public double trailLength = 30;
    public boolean trailAirOnly = false;

    public boolean jumpCircle = false;
    public int jcColor = 0;          // 0 gradient, 1 purple, 2 rainbow, 3 white
    public double jcSize = 2.2;
    public double jcSpeed = 1.0;
    public boolean jcDouble = true;

    // ---- Player
    public boolean swingAnim = false;
    public int swingMode = 0;        // 0 smooth drop, 1 slow drop, 2 slash, 3 chop, 4 push
    public double swingStrength = 1.0;

    public boolean customHand = false;
    public double handX = 0;
    public double handY = 0;
    public double handZ = 0;
    public double handScale = 1.0;

    public boolean freelook = false;
    public boolean freelookToggle = false;
    public boolean freelookThird = true;

    public boolean freecam = false;
    public double freecamSpeed = 12;

    public boolean fullbright = false;
    public boolean blockOverlay = false;
    public boolean blockRainbow = false;
    public double blockHue = 270;
    public double blockAlpha = 0.9;

    // ---- Misc
    public boolean weather = false;
    public int weatherType = 0; // 0 clear, 1 rain, 2 thunder
    public boolean timeChanger = false;
    public int timeValue = 6000;
    public boolean sky = false;
    public int skyMode = 0;          // 0 aurora, 1 stars, 2 galaxy
    public double skyTint = 0.5;
    public double skyStars = 1.0;
    public int skyAurora = 0;        // 0 green, 1 blue, 2 pink
    public boolean skyNightOnly = false;

    public boolean misty = false;
    public int mistStyle = 0;        // 0 white, 1 blue, 2 purple, 3 warm
    public double mistStrength = 0.6;
    public boolean mistWisps = true;

    public boolean menuSkin = true;
    public boolean menuAnimBg = true;
    public boolean menuRound = true;
    public boolean menuLight = true;
    public int menuAccent = 0;       // 0 purple, 1 orange, 2 blue, 3 pink, 4 green

    public boolean mainMenu = true;
    public boolean clock24 = true;
    public boolean clockSeconds = false;
    public boolean clockDate = true;
    public int clockStyle = 2; // 0 white, 1 purple, 2 gradient
    public boolean aspectOn = false;
    public double aspect = 16.0 / 9.0;

    public int outlineColor() {
        float h = blockRainbow ? (System.currentTimeMillis() % 4000L) / 4000f : (float) (blockHue / 360.0);
        int rgb = MathHelper.hsvToRgb(h, 0.85f, 1.0f) & 0xFFFFFF;
        int a = Math.round((float) blockAlpha * 255f);
        return (a << 24) | rgb;
    }

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("vizmenu.json");
    }

    public static void load() {
        try {
            Path p = path();
            if (Files.exists(p)) {
                try (Reader r = Files.newBufferedReader(p)) {
                    Config c = GSON.fromJson(r, Config.class);
                    if (c != null) I = c;
                }
            }
        } catch (Exception ignored) {
        }
        if (I.binds == null) I.binds = new HashMap<>();
        if (I.wmBox == null) I.wmBox = new HudBox(1, 1);
        if (I.fpsBox == null) I.fpsBox = new HudBox(1, 9);
        if (I.coordsBox == null) I.coordsBox = new HudBox(1, 16);
        if (I.armorBox == null) I.armorBox = new HudBox(1, 45);
        if (I.potionBox == null) I.potionBox = new HudBox(100, 4);
        if (I.cpsBox == null) I.cpsBox = new HudBox(1, 30);
        if (I.targetBox == null) I.targetBox = new HudBox(50, 62);
        if (I.cfgVersion < 2) {
            // watermark now sits top-left: move the other top-left elements below it
            I.fpsBox.x = 1; I.fpsBox.y = 9;
            I.coordsBox.x = 1; I.coordsBox.y = 16;
            I.cpsBox.x = 1; I.cpsBox.y = 30;
            I.cfgVersion = 2;
        }
    }

    public static void save() {
        try {
            Files.writeString(path(), GSON.toJson(I));
        } catch (Exception ignored) {
        }
    }
}
