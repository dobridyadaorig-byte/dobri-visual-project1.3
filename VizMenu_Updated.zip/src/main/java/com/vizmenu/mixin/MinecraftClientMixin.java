package com.vizmenu.mixin;

import com.vizmenu.Config;
import com.vizmenu.ui.MainMenuScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** Swaps the vanilla title screen for the DobriVisual main menu. */
@Mixin(MinecraftClient.class)
public abstract class MinecraftClientMixin {

    @ModifyVariable(method = "setScreen", at = @At("HEAD"), argsOnly = true, require = 0)
    private Screen viz$mainMenu(Screen screen) {
        if (Config.I.mainMenu && screen != null && screen.getClass() == TitleScreen.class) {
            return new MainMenuScreen();
        }
        return screen;
    }
}
