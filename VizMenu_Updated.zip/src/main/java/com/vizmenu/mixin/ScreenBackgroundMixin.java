package com.vizmenu.mixin;

import com.vizmenu.Config;
import com.vizmenu.ui.MenuBackground;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** World / server / settings screens (outside a world) get the animated DobriVisual background. */
@Mixin(Screen.class)
public abstract class ScreenBackgroundMixin {

    @Inject(method = "renderBackground", at = @At("HEAD"), cancellable = true, require = 0)
    private void viz$background(DrawContext ctx, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        Config c = Config.I;
        if (!c.menuSkin || !c.menuAnimBg) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world != null) return;
        MenuBackground.draw(ctx, mc, ctx.getScaledWindowWidth(), ctx.getScaledWindowHeight());
        ci.cancel();
    }
}
