package com.vizmenu.mixin;

import com.vizmenu.Config;
import net.minecraft.client.gui.hud.InGameHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public abstract class InGameHudMixin {

    @Inject(method = "renderStatusEffectOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private void viz$hideVanillaEffects(CallbackInfo ci) {
        if (Config.I.potionHud && Config.I.potionHideVanilla) ci.cancel();
    }

    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true, require = 0)
    private void viz$hideVanillaCrosshair(CallbackInfo ci) {
        if (Config.I.crosshair) ci.cancel();
    }
}
