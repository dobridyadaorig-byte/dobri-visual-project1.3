package com.vizmenu.mixin;

import com.vizmenu.CameraControl;
import net.minecraft.client.render.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Freecam: moves the camera away from the player. */
@Mixin(Camera.class)
public abstract class CameraPositionMixin {

    @Shadow
    protected abstract void setPos(double x, double y, double z);

    @Inject(method = "update", at = @At("RETURN"), require = 0)
    private void viz$freecam(CallbackInfo ci) {
        if (CameraControl.camActive) {
            CameraControl.updateFly();
            this.setPos(CameraControl.camX, CameraControl.camY, CameraControl.camZ);
        }
    }
}
