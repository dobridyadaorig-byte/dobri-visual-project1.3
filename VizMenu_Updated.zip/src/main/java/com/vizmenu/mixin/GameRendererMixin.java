package com.vizmenu.mixin;

import com.vizmenu.Config;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {

    @ModifyArg(
            method = "getBasicProjectionMatrix",
            at = @At(value = "INVOKE", target = "Lorg/joml/Matrix4f;perspective(FFFF)Lorg/joml/Matrix4f;"),
            index = 1,
            require = 0
    )
    private float viz$aspect(float aspect) {
        return Config.I.aspectOn ? (float) Config.I.aspect : aspect;
    }
}
