package com.vizmenu.mixin;

import com.vizmenu.Config;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Custom hand (offsets / scale) and ready-made swing animations for the first-person hand. */
@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {
    private static MatrixStack viz$pushed;

    /** With a custom swing animation the vanilla arc is switched off (swingProgress = 0). */
    @ModifyVariable(method = "renderFirstPersonItem", at = @At("HEAD"), argsOnly = true, ordinal = 2, require = 0)
    private float viz$noVanillaSwing(float swingProgress) {
        return Config.I.swingAnim ? 0.0f : swingProgress;
    }

    @ModifyVariable(method = "renderFirstPersonItem", at = @At("HEAD"), argsOnly = true, require = 0)
    private MatrixStack viz$hand(MatrixStack m) {
        Config c = Config.I;
        if (m == null || !(c.customHand || c.swingAnim)) return m;
        m.push();
        viz$pushed = m;

        if (c.customHand) {
            m.translate((float) c.handX, (float) c.handY, (float) c.handZ);
            float s = (float) c.handScale;
            if (s != 1.0f) {
                m.translate(0.45f, -0.35f, -0.7f);
                m.scale(s, s, s);
                m.translate(-0.45f, 0.35f, 0.7f);
            }
        }

        if (c.swingAnim) {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player != null) {
                float td = mc.getRenderTickCounter().getTickProgress(false);
                double p = mc.player.getHandSwingProgress(td);
                if (p > 0.0001 && p < 1.0) viz$swing(m, c.swingMode, p, c.swingStrength);
            }
        }
        return m;
    }

    @Inject(method = "renderFirstPersonItem", at = @At("RETURN"), require = 0)
    private void viz$handEnd(CallbackInfo ci) {
        if (viz$pushed != null) {
            viz$pushed.pop();
            viz$pushed = null;
        }
    }

    /** Every preset starts and ends at rest, so nothing snaps. */
    private static void viz$swing(MatrixStack m, int mode, double p, double k) {
        double q = p * p * (3.0 - 2.0 * p);          // smoothstep
        double bell = Math.sin(Math.PI * q);
        m.translate(0.45f, -0.35f, -0.7f);           // pivot near the hand
        switch (mode) {
            case 0 -> {                               // smooth drop
                m.translate((float) (0.04 * bell * k), (float) (-0.36 * bell * k), (float) (-0.10 * bell * k));
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees((float) (-30.0 * bell * k)));
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees((float) (8.0 * bell * k)));
            }
            case 1 -> {                               // slow, deeper drop
                double q2 = q * q * (3.0 - 2.0 * q);
                double b2 = Math.sin(Math.PI * q2);
                m.translate((float) (0.05 * b2 * k), (float) (-0.52 * b2 * k), (float) (-0.18 * b2 * k));
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees((float) (-42.0 * b2 * k)));
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees((float) (10.0 * b2 * k)));
            }
            case 2 -> {                               // slash
                double s2 = Math.sin(2.0 * Math.PI * q);
                m.translate((float) (-0.28 * s2 * k), (float) (-0.16 * bell * k), (float) (-0.12 * bell * k));
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees((float) (38.0 * s2 * k)));
                m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees((float) (-18.0 * s2 * k)));
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees((float) (-14.0 * bell * k)));
            }
            case 3 -> {                               // chop
                double b3 = Math.sin(Math.PI * Math.pow(q, 0.7));
                m.translate(0.0f, (float) (-0.30 * b3 * k), (float) (-0.36 * b3 * k));
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees((float) (-52.0 * b3 * k)));
            }
            default -> {                              // push
                m.translate(0.0f, (float) (-0.06 * bell * k), (float) (-0.55 * bell * k));
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees((float) (-10.0 * bell * k)));
            }
        }
        m.translate(-0.45f, 0.35f, 0.7f);
    }
}
