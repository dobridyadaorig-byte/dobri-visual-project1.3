package com.vizmenu.mixin;

import com.vizmenu.Config;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.widget.EntryListWidget;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Lets the animated background show through the world and server lists. */
@Mixin(EntryListWidget.class)
public abstract class ListBackgroundMixin {

    @Inject(method = "drawMenuListBackground", at = @At("HEAD"), cancellable = true, require = 0)
    private void viz$listBackground(CallbackInfo ci) {
        Config c = Config.I;
        if (c.menuSkin && c.menuAnimBg && MinecraftClient.getInstance().world == null) ci.cancel();
    }
}
