package com.vizmenu.mixin;

import com.vizmenu.CameraControl;
import net.minecraft.client.render.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

/** Freelook / Freecam: overrides the camera angles (before the third-person offset is computed). */
@Mixin(Camera.class)
public abstract class CameraRotationMixin {

    @ModifyArg(
            method = "update",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/Camera;setRotation(FF)V"),
            index = 0,
            require = 0
    )
    private float viz$yaw(float yaw) {
        return CameraControl.yaw(yaw);
    }

    @ModifyArg(
            method = "update",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/Camera;setRotation(FF)V"),
            index = 1,
            require = 0
    )
    private float viz$pitch(float pitch) {
        return CameraControl.pitch(pitch);
    }
}
