package com.vizmenu.mixin;

import com.vizmenu.CameraControl;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Freecam: the player must not walk while you fly the camera. */
@Mixin(KeyBinding.class)
public abstract class KeyBindingMixin {

    @Inject(method = "isPressed", at = @At("HEAD"), cancellable = true, require = 0)
    private void viz$blockMovement(CallbackInfoReturnable<Boolean> cir) {
        if (!CameraControl.camActive) return;
        GameOptions o = MinecraftClient.getInstance().options;
        if (o == null) return;
        Object self = this;
        if (self == o.forwardKey || self == o.backKey || self == o.leftKey || self == o.rightKey
                || self == o.jumpKey || self == o.sneakKey || self == o.sprintKey) {
            cir.setReturnValue(false);
        }
    }
}
