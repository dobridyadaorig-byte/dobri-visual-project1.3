package com.vizmenu.mixin;

import com.vizmenu.Config;
import com.vizmenu.ui.Theme;
import com.vizmenu.ui.Ui;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.PressableWidget;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Rounded buttons on the world / server / settings screens (outside a world). */
@Mixin(PressableWidget.class)
public abstract class ButtonSkinMixin {

    @Inject(method = "renderWidget", at = @At("HEAD"), cancellable = true, require = 0)
    private void viz$button(DrawContext ctx, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        Config c = Config.I;
        if (!c.menuSkin || !c.menuRound) return;
        ClickableWidget w = (ClickableWidget) (Object) this;
        if (!(w instanceof ButtonWidget)) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world != null) return;

        Ui.begin(mc);
        boolean hov = w.isHovered() && w.active;
        int acc = Theme.accent();
        double x = w.getX(), y = w.getY(), bw = w.getWidth(), bh = w.getHeight();
        double r = Math.min(bh / 2.0, 10.0);
        int base = w.active ? 0xD0191A21 : 0x90121317;
        Ui.rr(ctx, x - 1, y - 1, bw + 2, bh + 2, r + 1, hov ? acc : 0x40FFFFFF);
        Ui.rr(ctx, x, y, bw, bh, r, hov ? 0xE02A1F4A : base);

        TextRenderer tr = mc.textRenderer;
        int tw = tr.getWidth(w.getMessage());
        int col = w.active ? 0xFFFFFFFF : 0xFF8B8C98;
        ctx.drawText(tr, w.getMessage(), (int) (x + (bw - tw) / 2.0), (int) (y + (bh - 8) / 2.0), col, false);
        ci.cancel();
    }
}
