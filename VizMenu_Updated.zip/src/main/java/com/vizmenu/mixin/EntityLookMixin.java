package com.vizmenu.mixin;

import com.vizmenu.CameraControl;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** While Freelook / Freecam is active the mouse turns the camera instead of the player. */
@Mixin(Entity.class)
public abstract class EntityLookMixin {

    @Inject(method = "changeLookDirection", at = @At("HEAD"), cancellable = true, require = 0)
    private void viz$look(double dx, double dy, CallbackInfo ci) {
        if (!CameraControl.camActive && !CameraControl.lookActive) return;
        if ((Object) this != MinecraftClient.getInstance().player) return;
        if (CameraControl.mouse(dx, dy)) ci.cancel();
    }
}
