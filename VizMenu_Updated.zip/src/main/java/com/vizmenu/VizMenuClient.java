package com.vizmenu;

import com.vizmenu.ui.MenuScreen;
import com.vizmenu.ui.Module;
import com.vizmenu.ui.Modules;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public class VizMenuClient implements ClientModInitializer {
    public static final KeyBinding.Category CATEGORY = KeyBinding.Category.create(Identifier.of("vizmenu", "main"));
    public static KeyBinding OPEN;
    public static KeyBinding FREELOOK;

    private final boolean[] bindWas = new boolean[64];
    private boolean rmbWas = false;
    private boolean nvAdded = false;
    private int trailTick = 0;
    private ParticleEffect[] trailStyles;
    private final BlockPos.Mutable mp = new BlockPos.Mutable();
    private Perspective prevPerspective;

    @Override
    public void onInitializeClient() {
        Config.load();

        OPEN = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.vizmenu.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, CATEGORY));
        FREELOOK = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.vizmenu.freelook", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_LEFT_ALT, CATEGORY));

        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
        HudElementRegistry.addLast(Identifier.of("vizmenu", "hud"), (ctx, tc) -> Hud.render(ctx, tc));
    }

    private void setLook(MinecraftClient mc, ClientPlayerEntity p, boolean on) {
        if (on == CameraControl.lookActive) return;
        if (on) {
            CameraControl.lookYaw = p.getYaw();
            CameraControl.lookPitch = p.getPitch();
            if (Config.I.freelookThird) {
                prevPerspective = mc.options.getPerspective();
                mc.options.setPerspective(Perspective.THIRD_PERSON_BACK);
            }
            CameraControl.lookActive = true;
        } else {
            CameraControl.lookActive = false;
            if (prevPerspective != null) {
                mc.options.setPerspective(prevPerspective);
                prevPerspective = null;
            }
        }
    }

    private void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        if (p == null || w == null) {
            rmbWas = false;
            nvAdded = false;
            CameraControl.lookActive = false;
            CameraControl.stopFreecam();
            prevPerspective = null;
            return;
        }
        Config c = Config.I;

        // ---- open menu: key or right click with empty hands on air
        while (OPEN.wasPressed()) {
            if (mc.currentScreen == null) mc.setScreen(new MenuScreen());
        }
        boolean rmb = mc.options.useKey.isPressed();
        if (rmb && !rmbWas && mc.currentScreen == null && c.openOnRightClick) {
            HitResult h = mc.crosshairTarget;
            boolean air = h == null || h.getType() == HitResult.Type.MISS;
            if (air && p.getMainHandStack().isEmpty() && p.getOffHandStack().isEmpty()) {
                mc.setScreen(new MenuScreen());
            }
        }
        rmbWas = rmb;

        // ---- function key binds
        if (!c.binds.isEmpty()) {
            long handle = mc.getWindow().getHandle();
            for (int i = 0; i < Modules.ALL.size() && i < bindWas.length; i++) {
                Module m = Modules.ALL.get(i);
                int k = m.bind();
                if (k < 0) {
                    bindWas[i] = false;
                    continue;
                }
                boolean down = GLFW.glfwGetKey(handle, k) == GLFW.GLFW_PRESS;
                if (down && !bindWas[i] && mc.currentScreen == null) {
                    m.toggle();
                    p.sendMessage(Text.literal(m.name + (m.isOn() ? " ON" : " OFF")), true);
                }
                bindWas[i] = down;
            }
        }

        // ---- freecam / freelook
        if (c.freecam) {
            if (!CameraControl.camActive) {
                setLook(mc, p, false);
                CameraControl.startFreecam(p.getX(), p.getEyeY(), p.getZ(), p.getYaw(), p.getPitch());
            }
        } else if (CameraControl.camActive) {
            CameraControl.stopFreecam();
        }
        if (c.freelook && !CameraControl.camActive) {
            if (c.freelookToggle) {
                while (FREELOOK.wasPressed()) setLook(mc, p, !CameraControl.lookActive);
            } else {
                while (FREELOOK.wasPressed()) { /* drain */ }
                setLook(mc, p, FREELOOK.isPressed());
            }
        } else if (CameraControl.lookActive) {
            setLook(mc, p, false);
        }

        // ---- fullbright (client-side night vision, hidden icon)
        if (c.fullbright || nvAdded) {
            StatusEffectInstance nv = p.getStatusEffect(StatusEffects.NIGHT_VISION);
            if (c.fullbright) {
                if (nv == null) {
                    p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1_000_000, 0, false, false, false));
                    nvAdded = true;
                }
            } else {
                if (nv != null && !nv.shouldShowIcon()) p.removeStatusEffect(StatusEffects.NIGHT_VISION);
                nvAdded = false;
            }
        }

        // ---- auto sprint
        if (c.autoSprint && !p.isSprinting()
                && mc.options.forwardKey.isPressed()
                && !p.isSneaking() && !p.isUsingItem()
                && !p.horizontalCollision
                && p.getHungerManager().getFoodLevel() > 6
                && !p.hasStatusEffect(StatusEffects.BLINDNESS)) {
            p.setSprinting(true);
        }

        // ---- trail (particle mode only; ribbon / dots are drawn in Effects)
        if (c.trail && c.trailMode == 2 && (!c.trailAirOnly || !p.isOnGround())) {
            Vec3d v = p.getVelocity();
            if (v.x * v.x + v.z * v.z > 0.0025 || Math.abs(v.y) > 0.1) {
                if (++trailTick % 4 == 0) spawnTrail(mc, p, c);
            }
        }

        // ---- jump circle, ribbon trail path, kill effect
        Effects.tick(mc, p, c);
        Sky.tick(mc, p, c);

        // ---- weather (client-side)
        if (c.weather) {
            float rain = c.weatherType == 0 ? 0f : 1f;
            float thunder = c.weatherType == 2 ? 1f : 0f;
            w.setRainGradient(rain);
            w.setThunderGradient(thunder);
        }
    }

    private void spawnTrail(MinecraftClient mc, ClientPlayerEntity p, Config c) {
        if (trailStyles == null) {
            trailStyles = new ParticleEffect[]{
                    ParticleTypes.END_ROD, ParticleTypes.FLAME, ParticleTypes.SOUL_FIRE_FLAME,
                    ParticleTypes.ELECTRIC_SPARK, ParticleTypes.HAPPY_VILLAGER
            };
        }
        ParticleEffect type = trailStyles[Math.max(0, Math.min(c.trailStyle, trailStyles.length - 1))];
        Vec3d v = p.getVelocity();
        double x = p.getX(), y = p.getY() + 0.1, z = p.getZ();
        double vx = v.x, vy = v.y, vz = v.z;
        int steps = (int) c.trailLength;
        int stride = Math.max(2, steps / 10);
        for (int i = 1; i <= steps; i++) {
            x += vx;
            y += vy;
            z += vz;
            if (!mc.world.getBlockState(mp.set(x, y, z)).isAir()) break;
            if (vy <= 0 && !mc.world.getBlockState(mp.set(x, y - 0.2, z)).isAir()) vy = 0;
            else vy = (vy - 0.08) * 0.98;
            vx *= 0.9;
            vz *= 0.9;
            if (i % stride == 0) {
                mc.particleManager.addParticle(type, x, y, z, 0.0, 0.0, 0.0);
            }
        }
    }
}
