package com.vizmenu;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

/** Shared state for Freelook and Freecam. */
public final class CameraControl {
    // freelook
    public static boolean lookActive = false;
    public static float lookYaw, lookPitch;

    // freecam
    public static boolean camActive = false;
    public static double camX, camY, camZ;
    public static float camYaw, camPitch;

    private static long lastNs = 0L;
    private static int kF = -1, kB = -1, kL = -1, kR = -1, kUp = -1, kDown = -1, kSprint = -1;

    private CameraControl() {}

    public static float yaw(float original) {
        if (camActive) return camYaw;
        return lookActive ? lookYaw : original;
    }

    public static float pitch(float original) {
        if (camActive) return camPitch;
        return lookActive ? lookPitch : original;
    }

    /** Mouse movement while Freelook / Freecam is active; returns true if it was consumed. */
    public static boolean mouse(double dx, double dy) {
        if (camActive) {
            camYaw += (float) (dx * 0.15);
            camPitch = MathHelper.clamp(camPitch + (float) (dy * 0.15), -90f, 90f);
            return true;
        }
        if (lookActive) {
            lookYaw += (float) (dx * 0.15);
            lookPitch = MathHelper.clamp(lookPitch + (float) (dy * 0.15), -90f, 90f);
            return true;
        }
        return false;
    }

    private static int code(KeyBinding kb) {
        try {
            InputUtil.Key k = InputUtil.fromTranslationKey(kb.getBoundKeyTranslationKey());
            return k.getCategory() == InputUtil.Type.KEYSYM ? k.getCode() : -1;
        } catch (Exception e) {
            return -1;
        }
    }

    public static void startFreecam(double x, double y, double z, float yaw, float pitch) {
        camX = x;
        camY = y;
        camZ = z;
        camYaw = yaw;
        camPitch = pitch;
        lastNs = 0L;
        GameOptions o = MinecraftClient.getInstance().options;
        kF = code(o.forwardKey);
        kB = code(o.backKey);
        kL = code(o.leftKey);
        kR = code(o.rightKey);
        kUp = code(o.jumpKey);
        kDown = code(o.sneakKey);
        kSprint = code(o.sprintKey);
        camActive = true;
    }

    public static void stopFreecam() {
        camActive = false;
        lastNs = 0L;
    }

    private static boolean down(long h, int key) {
        return key >= 0 && GLFW.glfwGetKey(h, key) == GLFW.GLFW_PRESS;
    }

    /** Called once per rendered frame while the camera is being updated. */
    public static void updateFly() {
        if (!camActive) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        long now = System.nanoTime();
        double dt = lastNs == 0L ? 0.0 : Math.min(0.1, (now - lastNs) / 1.0e9);
        lastNs = now;
        if (mc.currentScreen != null || dt <= 0.0) return;

        long h = mc.getWindow().getHandle();
        double yr = Math.toRadians(camYaw), pr = Math.toRadians(camPitch);
        double fx = -Math.sin(yr) * Math.cos(pr), fy = -Math.sin(pr), fz = Math.cos(yr) * Math.cos(pr);
        double rx = -Math.cos(yr), rz = -Math.sin(yr);

        double mx = 0, my = 0, mz = 0;
        if (down(h, kF)) { mx += fx; my += fy; mz += fz; }
        if (down(h, kB)) { mx -= fx; my -= fy; mz -= fz; }
        if (down(h, kR)) { mx += rx; mz += rz; }
        if (down(h, kL)) { mx -= rx; mz -= rz; }
        if (down(h, kUp)) my += 1.0;
        if (down(h, kDown)) my -= 1.0;

        double len = Math.sqrt(mx * mx + my * my + mz * mz);
        if (len < 1.0e-6) return;
        double speed = Config.I.freecamSpeed * (down(h, kSprint) ? 2.5 : 1.0);
        camX += mx / len * speed * dt;
        camY += my / len * speed * dt;
        camZ += mz / len * speed * dt;
    }
}
