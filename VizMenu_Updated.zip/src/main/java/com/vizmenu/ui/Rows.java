package com.vizmenu.ui;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleFunction;
import java.util.function.DoubleSupplier;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

/** Setting rows shown inside an expanded module card (rounded, theme aware). */
final class Rows {
    private Rows() {}

    abstract static class Row {
        int x, y, w;
        final int h;

        Row(int h) { this.h = h; }

        abstract void draw(DrawContext c, TextRenderer f, int mx, int my);

        boolean click(double mx, double my, int btn) { return false; }

        void drag(double mx) { }

        boolean hit(double mx, double my) {
            return mx >= x && mx < x + w && my >= y && my < y + h;
        }
    }

    static class Label extends Row {
        final String text;

        Label(String text) { super(14); this.text = text; }

        @Override
        void draw(DrawContext c, TextRenderer f, int mx, int my) {
            c.drawText(f, text, x, y + 3, Theme.dim(), false);
        }
    }

    static class Toggle extends Row {
        final String label;
        final BooleanSupplier get;
        final Consumer<Boolean> set;

        Toggle(String label, BooleanSupplier get, Consumer<Boolean> set) {
            super(24);
            this.label = label; this.get = get; this.set = set;
        }

        @Override
        void draw(DrawContext c, TextRenderer f, int mx, int my) {
            c.drawText(f, label, x, y + (h - 8) / 2, Theme.text(), false);
            boolean on = get.getAsBoolean();
            double tx = x + w - 26, ty = y + (h - 14) / 2.0;
            Ui.rr(c, tx, ty, 26, 14, 7, on ? Theme.accent() : Theme.track());
            Ui.circle(c, on ? tx + 19 : tx + 7, ty + 7, 5.2, Theme.knob());
        }

        @Override
        boolean click(double mx, double my, int btn) {
            if (btn != 0) return false;
            set.accept(!get.getAsBoolean());
            return true;
        }
    }

    static class Cycle extends Row {
        final String label;
        final String[] opts;
        final IntSupplier get;
        final IntConsumer set;

        Cycle(String label, String[] opts, IntSupplier get, IntConsumer set) {
            super(26);
            this.label = label; this.opts = opts; this.get = get; this.set = set;
        }

        @Override
        void draw(DrawContext c, TextRenderer f, int mx, int my) {
            c.drawText(f, label, x, y + (h - 8) / 2, Theme.text(), false);
            String t = opts[MathHelper.clamp(get.getAsInt(), 0, opts.length - 1)];
            int pw = Math.max(64, f.getWidth(t) + 28);
            double bx = x + w - pw;
            Ui.rr(c, bx, y + 2, pw, h - 4, 7, hit(mx, my) ? Theme.track() : Theme.soft());
            c.drawText(f, t, (int) bx + 9, y + (h - 8) / 2, Theme.text(), false);
            Ui.chevron(c, bx + pw - 11, y + h / 2.0, true, Theme.dim());
        }

        @Override
        boolean click(double mx, double my, int btn) {
            int n = opts.length;
            int cur = get.getAsInt();
            if (btn == 0) set.accept((cur + 1) % n);
            else if (btn == 1) set.accept((cur + n - 1) % n);
            else return false;
            return true;
        }
    }

    static class Buttons extends Row {
        final String[] labels;
        final IntConsumer action;

        Buttons(String[] labels, IntConsumer action) {
            super(26);
            this.labels = labels; this.action = action;
        }

        private double bw() { return (w - (labels.length - 1) * 4.0) / labels.length; }

        @Override
        void draw(DrawContext c, TextRenderer f, int mx, int my) {
            double bw = bw();
            for (int i = 0; i < labels.length; i++) {
                double bx = x + i * (bw + 4);
                boolean hov = mx >= bx && mx < bx + bw && my >= y && my < y + h;
                Ui.rr(c, bx, y + 2, bw, h - 4, 7, hov ? Theme.accent() : Theme.soft());
                c.drawText(f, labels[i], (int) (bx + (bw - f.getWidth(labels[i])) / 2), y + (h - 8) / 2,
                        hov ? 0xFFFFFFFF : Theme.text(), false);
            }
        }

        @Override
        boolean click(double mx, double my, int btn) {
            if (btn != 0) return false;
            double bw = bw();
            for (int i = 0; i < labels.length; i++) {
                double bx = x + i * (bw + 4);
                if (mx >= bx && mx < bx + bw) {
                    action.accept(i);
                    return true;
                }
            }
            return false;
        }
    }

    static class Slider extends Row {
        final String label;
        final double min, max, step;
        final DoubleSupplier get;
        final DoubleConsumer set;
        final DoubleFunction<String> fmt;
        final IntSupplier knob;

        Slider(String label, double min, double max, double step, DoubleSupplier get,
               DoubleConsumer set, DoubleFunction<String> fmt, IntSupplier knob) {
            super(30);
            this.label = label; this.min = min; this.max = max; this.step = step;
            this.get = get; this.set = set; this.fmt = fmt; this.knob = knob;
        }

        @Override
        void draw(DrawContext c, TextRenderer f, int mx, int my) {
            double v = get.getAsDouble();
            String vs = fmt.apply(v);
            int acc = knob != null ? knob.getAsInt() : Theme.accent();
            c.drawText(f, label, x, y + 2, Theme.text(), false);
            c.drawText(f, vs, x + w - f.getWidth(vs), y + 2, acc, false);
            double t = MathHelper.clamp((v - min) / (max - min), 0, 1);
            double ty = y + 19.0;
            Ui.rr(c, x, ty - 1.5, w, 3, 1.5, Theme.track());
            double fw = w * t;
            if (fw > 0.5) Ui.rr(c, x, ty - 1.5, fw, 3, 1.5, acc);
            double kx = x + fw;
            Ui.circle(c, kx, ty, 5.2, acc);
            Ui.circle(c, kx, ty, 3.2, Theme.knob());
        }

        @Override
        boolean click(double mx, double my, int btn) {
            if (btn != 0) return false;
            drag(mx);
            return true;
        }

        @Override
        void drag(double mx) {
            double t = MathHelper.clamp((mx - x) / (double) w, 0, 1);
            double v = min + t * (max - min);
            v = Math.round(v / step) * step;
            v = MathHelper.clamp(v, min, max);
            set.accept(v);
        }
    }
}
