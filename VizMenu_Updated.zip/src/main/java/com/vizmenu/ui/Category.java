package com.vizmenu.ui;

public enum Category {
    HUD("HUD"),
    COMBAT("Combat"),
    MOVEMENT("Movement"),
    PLAYER("Player"),
    MISC("Misc");

    public final String label;

    Category(String label) {
        this.label = label;
    }
}
