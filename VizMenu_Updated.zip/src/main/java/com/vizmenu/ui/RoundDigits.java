package com.vizmenu.ui;

import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Smooth digits with rounded stroke ends (not a Minecraft font).
 * Glyphs are rasterised once per size into a few rectangles and then drawn with plain fills.
 * Coordinates are in device pixels (the caller scales the matrix by 1 / guiScale).
 */
public final class RoundDigits {
    private static final float[][][] PATHS = new float[11][][]; // 0-9 digits, 10 colon (single points)

    private static final class Glyphs {
        int unit, pad, h;
        final int[] w = new int[11];
        final int[][] rects = new int[11][];
    }

    private static final Map<Integer, Glyphs> CACHE = new HashMap<>();

    private RoundDigits() {}

    // ---------------------------------------------------------------- shapes
    private static final class P {
        final List<Float> pts = new ArrayList<>();

        P to(double x, double y) {
            pts.add((float) x);
            pts.add((float) y);
            return this;
        }

        /** Elliptical arc, angles in degrees, 270 = top, increasing = clockwise on screen. */
        P arc(double cx, double cy, double rx, double ry, double a0, double a1) {
            int n = Math.max(6, (int) Math.ceil(Math.abs(a1 - a0) / 6.0));
            for (int i = 0; i <= n; i++) {
                double a = Math.toRadians(a0 + (a1 - a0) * i / n);
                to(cx + rx * Math.cos(a), cy + ry * Math.sin(a));
            }
            return this;
        }

        P quad(double x0, double y0, double cx, double cy, double x1, double y1) {
            int n = 14;
            for (int i = 0; i <= n; i++) {
                double t = i / (double) n, u = 1 - t;
                to(u * u * x0 + 2 * u * t * cx + t * t * x1, u * u * y0 + 2 * u * t * cy + t * t * y1);
            }
            return this;
        }

        float[] done() {
            float[] r = new float[pts.size()];
            for (int i = 0; i < r.length; i++) r[i] = pts.get(i);
            return r;
        }
    }

    private static float[] rotate180(float[] p) {
        float[] r = new float[p.length];
        for (int i = 0; i < p.length; i += 2) {
            r[i] = 1f - p[i];
            r[i + 1] = 2f - p[i + 1];
        }
        return r;
    }

    static {
        PATHS[0] = new float[][]{
                new P().arc(0.5, 0.5, 0.5, 0.5, 180, 360).arc(0.5, 1.5, 0.5, 0.5, 0, 180).to(0, 0.5).done()
        };
        PATHS[1] = new float[][]{new P().to(0.12, 0.42).to(0.58, 0.0).to(0.58, 2.0).done()};
        PATHS[2] = new float[][]{new P().arc(0.5, 0.5, 0.5, 0.5, 190, 395).to(0.0, 2.0).to(1.0, 2.0).done()};
        PATHS[3] = new float[][]{
                new P().arc(0.5, 0.5, 0.5, 0.5, 200, 450).arc(0.5, 1.5, 0.5, 0.5, 270, 520).done()
        };
        PATHS[4] = new float[][]{new P().to(0.72, 2.0).to(0.72, 0.0).to(0.0, 1.35).to(1.0, 1.35).done()};
        PATHS[5] = new float[][]{
                new P().to(0.92, 0.0).to(0.14, 0.0).to(0.1, 0.92).arc(0.5, 1.4, 0.5, 0.6, 235, 520).done()
        };
        float[] six = new P().quad(0.92, 0.1, 0.0, 0.05, 0.0, 1.4).arc(0.5, 1.4, 0.5, 0.6, 180, 540).done();
        PATHS[6] = new float[][]{six};
        PATHS[7] = new float[][]{new P().to(0.0, 0.0).to(1.0, 0.0).to(0.38, 2.0).done()};
        PATHS[8] = new float[][]{
                new P().arc(0.5, 0.5, 0.44, 0.5, 0, 360).done(),
                new P().arc(0.5, 1.5, 0.5, 0.5, 0, 360).done()
        };
        PATHS[9] = new float[][]{rotate180(six)};
        PATHS[10] = new float[][]{new float[]{0.3f, 0.68f}, new float[]{0.3f, 1.32f}};
    }

    // ---------------------------------------------------------------- rasterising
    private static void stamp(boolean[][] bm, float cx, float cy, float r) {
        int y0 = Math.max(0, (int) Math.floor(cy - r));
        int y1 = Math.min(bm.length - 1, (int) Math.ceil(cy + r));
        for (int y = y0; y <= y1; y++) {
            float dy = y + 0.5f - cy;
            float rem = r * r - dy * dy;
            if (rem < 0) continue;
            float half = (float) Math.sqrt(rem);
            int xa = Math.max(0, (int) Math.ceil(cx - half - 0.5f));
            int xb = Math.min(bm[0].length - 1, (int) Math.floor(cx + half - 0.5f));
            for (int x = xa; x <= xb; x++) bm[y][x] = true;
        }
    }

    private static void stampPath(boolean[][] bm, float[] path, int unit, int pad, float r) {
        if (path.length == 2) {
            stamp(bm, path[0] * unit + pad, path[1] * unit + pad, r);
            return;
        }
        for (int i = 0; i + 3 < path.length; i += 2) {
            float x0 = path[i] * unit + pad, y0 = path[i + 1] * unit + pad;
            float x1 = path[i + 2] * unit + pad, y1 = path[i + 3] * unit + pad;
            float d = (float) Math.hypot(x1 - x0, y1 - y0);
            int n = Math.max(1, (int) Math.ceil(d / 0.6f));
            for (int s = 0; s <= n; s++) {
                float t = s / (float) n;
                stamp(bm, x0 + (x1 - x0) * t, y0 + (y1 - y0) * t, r);
            }
        }
    }

    private static int[] runs(boolean[] row) {
        List<Integer> l = new ArrayList<>();
        int x = 0;
        while (x < row.length) {
            if (row[x]) {
                int s = x;
                while (x < row.length && row[x]) x++;
                l.add(s);
                l.add(x);
            } else {
                x++;
            }
        }
        int[] r = new int[l.size()];
        for (int i = 0; i < r.length; i++) r[i] = l.get(i);
        return r;
    }

    private static int[] toRects(boolean[][] bm) {
        List<Integer> out = new ArrayList<>();
        int[] prev = new int[0];
        int start = 0;
        for (int y = 0; y <= bm.length; y++) {
            int[] cur = y < bm.length ? runs(bm[y]) : new int[0];
            if (y == 0) {
                prev = cur;
                start = 0;
                continue;
            }
            if (!Arrays.equals(cur, prev)) {
                for (int i = 0; i < prev.length; i += 2) {
                    out.add(prev[i]);
                    out.add(start);
                    out.add(prev[i + 1]);
                    out.add(y);
                }
                prev = cur;
                start = y;
            }
        }
        int[] r = new int[out.size()];
        for (int i = 0; i < r.length; i++) r[i] = out.get(i);
        return r;
    }

    private static Glyphs glyphs(int unit) {
        Glyphs g = CACHE.get(unit);
        if (g != null) return g;
        if (CACHE.size() > 6) CACHE.clear();
        g = new Glyphs();
        g.unit = unit;
        float r = Math.max(1.5f, unit * 0.085f);
        g.pad = (int) Math.ceil(r * 1.3f) + 1;
        g.h = 2 * unit + 2 * g.pad;
        for (int d = 0; d <= 10; d++) {
            int gw = (d == 10 ? Math.round(unit * 0.6f) : unit) + 2 * g.pad;
            boolean[][] bm = new boolean[g.h][gw];
            float rr = d == 10 ? r * 1.3f : r;
            for (float[] path : PATHS[d]) stampPath(bm, path, unit, g.pad, rr);
            g.w[d] = gw;
            g.rects[d] = toRects(bm);
        }
        CACHE.put(unit, g);
        return g;
    }

    // ---------------------------------------------------------------- public api
    private static int index(char ch) {
        if (ch >= '0' && ch <= '9') return ch - '0';
        return ch == ':' ? 10 : -1;
    }

    public static int advance(char ch, int unit) {
        int i = index(ch);
        if (i < 0) return Math.round(unit * 0.5f);
        return i == 10 ? Math.round(unit * 0.55f) : Math.round(unit * 1.38f);
    }

    public static int width(String s, int unit) {
        int w = 0;
        for (int i = 0; i < s.length(); i++) w += advance(s.charAt(i), unit);
        return w - Math.round(unit * 0.38f);
    }

    public static int height(int unit) {
        return 2 * unit;
    }

    public static int pad(int unit) {
        return glyphs(unit).pad;
    }

    /** Draws one glyph with its stroke origin at (x, y); returns the advance. */
    public static int drawChar(DrawContext ctx, char ch, int x, int y, int unit, int color) {
        int i = index(ch);
        if (i >= 0) {
            Glyphs g = glyphs(unit);
            int ox = x - g.pad, oy = y - g.pad;
            int[] r = g.rects[i];
            for (int k = 0; k + 3 < r.length; k += 4) {
                ctx.fill(ox + r[k], oy + r[k + 1], ox + r[k + 2], oy + r[k + 3], color);
            }
        }
        return advance(ch, unit);
    }
}
