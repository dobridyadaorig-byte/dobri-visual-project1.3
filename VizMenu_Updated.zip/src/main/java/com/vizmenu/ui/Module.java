package com.vizmenu.ui;

import com.vizmenu.Config;
import net.minecraft.client.util.InputUtil;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Supplier;

/** One toggleable function shown in the menu. */
public final class Module {
    private static final Map<Integer, String> KEY_NAMES = new HashMap<>();

    public final String id;
    public final String name;
    public final String desc;
    public final Category category;
    private final BooleanSupplier get;
    private final Consumer<Boolean> set;
    final Supplier<List<Rows.Row>> settings;

    Module(Category category, String id, String name, String desc,
           BooleanSupplier get, Consumer<Boolean> set, Supplier<List<Rows.Row>> settings) {
        this.category = category;
        this.id = id;
        this.name = name;
        this.desc = desc;
        this.get = get;
        this.set = set;
        this.settings = settings;
    }

    public boolean isOn() {
        return get.getAsBoolean();
    }

    public void toggle() {
        set.accept(!get.getAsBoolean());
    }

    public int bind() {
        Integer k = Config.I.binds.get(id);
        return k == null ? -1 : k;
    }

    public void setBind(int key) {
        if (key < 0) Config.I.binds.remove(id);
        else Config.I.binds.put(id, key);
    }

    public String bindLabel() {
        int k = bind();
        if (k < 0) return "";
        String s = KEY_NAMES.get(k);
        if (s == null) {
            try {
                s = InputUtil.Type.KEYSYM.createFromCode(k).getLocalizedText().getString();
            } catch (Exception e) {
                s = "key " + k;
            }
            KEY_NAMES.put(k, s);
        }
        return "[" + s + "]";
    }
}
