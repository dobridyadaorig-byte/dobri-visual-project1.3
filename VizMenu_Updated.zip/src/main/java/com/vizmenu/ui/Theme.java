package com.vizmenu.ui;

import com.vizmenu.Config;

/** Colours of the settings menu (light / dark + accent). */
public final class Theme {
    public static final int[] ACCENTS = {0xFF8B5CF6, 0xFFF97316, 0xFF3B82F6, 0xFFEC4899, 0xFF22C55E};
    public static final String[] ACCENT_NAMES = {"фиолетовый", "оранжевый", "синий", "розовый", "зелёный"};

    private Theme() {}

    private static boolean light() { return Config.I.menuLight; }

    public static int accent() { return ACCENTS[Math.floorMod(Config.I.menuAccent, ACCENTS.length)]; }
    public static int window() { return light() ? 0xFFF1F1F5 : 0xFF121317; }
    public static int sidebar() { return light() ? 0xFFF9F9FB : 0xFF0E0F12; }
    public static int card() { return light() ? 0xFFFFFFFF : 0xFF1B1C22; }
    public static int cardHover() { return light() ? 0xFFF7F7FA : 0xFF21222A; }
    public static int border() { return light() ? 0xFFE4E4EA : 0xFF2A2B33; }
    public static int text() { return light() ? 0xFF15151A : 0xFFEDEDF2; }
    public static int dim() { return light() ? 0xFF8A8A95 : 0xFF8B8C98; }
    public static int soft() { return light() ? 0xFFEEEEF3 : 0xFF2A2B33; }
    public static int track() { return light() ? 0xFFE2E2E9 : 0xFF383944; }
    public static int knob() { return 0xFFFFFFFF; }
}
