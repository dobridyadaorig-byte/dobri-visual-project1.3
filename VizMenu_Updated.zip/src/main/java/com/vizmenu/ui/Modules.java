package com.vizmenu.ui;

import com.vizmenu.Config;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Supplier;

/** Registry of all functions, grouped by category. */
public final class Modules {
    public static final List<Module> ALL = new ArrayList<>();

    private Modules() {}

    private static Config c() {
        return Config.I;
    }

    private static void add(Category cat, String id, String name, String desc,
                            BooleanSupplier get, Consumer<Boolean> set, Supplier<List<Rows.Row>> settings) {
        ALL.add(new Module(cat, id, name, desc, get, set, settings));
    }

    private static String f2(double v) {
        return String.format("%.2f", v);
    }

    private static String clock(int ticks) {
        int mins = (int) ((((ticks / 1000.0) + 6.0) % 24.0) * 60.0);
        return String.format("%02d:%02d", mins / 60, mins % 60);
    }

    /** Background / position / scale rows shared by all HUD elements. */
    private static List<Rows.Row> box(Config.HudBox b, List<Rows.Row> l) {
        l.add(new Rows.Toggle("Background", () -> b.bg, v -> b.bg = v));
        l.add(new Rows.Slider("Position X", 0, 100, 1, () -> b.x, v -> b.x = v, v -> (int) v + "%", null));
        l.add(new Rows.Slider("Position Y", 0, 100, 1, () -> b.y, v -> b.y = v, v -> (int) v + "%", null));
        l.add(new Rows.Slider("Scale", 0.5, 2.0, 0.05, () -> b.scale, v -> b.scale = v, v -> f2(v) + "x", null));
        return l;
    }

    private static List<Rows.Row> none() {
        List<Rows.Row> l = new ArrayList<>();
        l.add(new Rows.Label("Нет дополнительных настроек."));
        return l;
    }

    static {
        // ------------------------------------------------------------ HUD
        add(Category.HUD, "watermark", "Watermark", "Водяной знак DobriVisual слева сверху",
                () -> c().watermark, v -> c().watermark = v,
                () -> {
                    List<Rows.Row> l = new ArrayList<>();
                    l.add(new Rows.Toggle("Animated colors", () -> c().wmAnim, v -> c().wmAnim = v));
                    l.add(new Rows.Toggle("Show version", () -> c().wmVersion, v -> c().wmVersion = v));
                    return box(c().wmBox, l);
                });

        add(Category.HUD, "fps", "FPS", "Показывает текущий FPS",
                () -> c().fps, v -> c().fps = v,
                () -> box(c().fpsBox, new ArrayList<>()));

        add(Category.HUD, "coords", "Coordinates", "Координаты XYZ и направление взгляда",
                () -> c().coords, v -> c().coords = v,
                () -> {
                    List<Rows.Row> l = new ArrayList<>();
                    l.add(new Rows.Cycle("Decimals", new String[]{"0", "1", "2"},
                            () -> c().coordsDecimals, v -> c().coordsDecimals = v));
                    l.add(new Rows.Toggle("Facing direction", () -> c().coordsDir, v -> c().coordsDir = v));
                    l.add(new Rows.Toggle("Nether / Overworld coords", () -> c().coordsNether, v -> c().coordsNether = v));
                    return box(c().coordsBox, l);
                });

        add(Category.HUD, "armor", "Armor status", "Надетая броня и её прочность на экране",
                () -> c().armorHud, v -> c().armorHud = v,
                () -> {
                    List<Rows.Row> l = new ArrayList<>();
                    l.add(new Rows.Cycle("Layout", new String[]{"Vertical", "Horizontal"},
                            () -> c().armorVertical ? 0 : 1, v -> c().armorVertical = (v == 0)));
                    l.add(new Rows.Cycle("Durability", new String[]{"Off", "Number", "Percent"},
                            () -> c().armorDurability, v -> c().armorDurability = v));
                    return box(c().armorBox, l);
                });

        add(Category.HUD, "potions", "Potion visuals", "Список эффектов с таймерами в красивом виде",
                () -> c().potionHud, v -> c().potionHud = v,
                () -> {
                    List<Rows.Row> l = new ArrayList<>();
                    l.add(new Rows.Toggle("Hide vanilla effects", () -> c().potionHideVanilla, v -> c().potionHideVanilla = v));
                    l.add(new Rows.Cycle("Style", new String[]{"Detailed", "Compact"},
                            () -> c().potionStyle, v -> c().potionStyle = v));
                    l.add(new Rows.Toggle("Timer bars", () -> c().potionBars, v -> c().potionBars = v));
                    return box(c().potionBox, l);
                });

        add(Category.HUD, "crosshair", "Custom crosshair", "Свой прицел: стиль, цвет, размер, зазор",
                () -> c().crosshair, v -> c().crosshair = v,
                () -> {
                    List<Rows.Row> l = new ArrayList<>();
                    l.add(new Rows.Cycle("Style", new String[]{"Cross", "Dot", "Circle", "Cross + dot"},
                            () -> c().chStyle, v -> c().chStyle = v));
                    l.add(new Rows.Cycle("Color", new String[]{"White", "Custom", "Rainbow"},
                            () -> c().chColorMode, v -> c().chColorMode = v));
                    l.add(new Rows.Slider("Color (hue)", 0, 360, 1, () -> c().chHue,
                            v -> { c().chHue = v; c().chColorMode = 1; }, v -> (int) v + "\u00B0",
                            () -> 0xFF000000 | (MathHelper.hsvToRgb((float) (c().chHue / 360.0), 0.85f, 1f) & 0xFFFFFF)));
                    l.add(new Rows.Slider("Size", 2, 20, 1, () -> c().chSize, v -> c().chSize = v, v -> (int) v + " px", null));
                    l.add(new Rows.Slider("Thickness", 1, 4, 1, () -> c().chThick, v -> c().chThick = v, v -> (int) v + " px", null));
                    l.add(new Rows.Slider("Gap", 0, 10, 1, () -> c().chGap, v -> c().chGap = v, v -> (int) v + " px", null));
                    l.add(new Rows.Slider("Opacity", 0.2, 1.0, 0.05, () -> c().chAlpha, v -> c().chAlpha = v,
                            v -> Math.round(v * 100) + "%", null));
                    l.add(new Rows.Toggle("Outline", () -> c().chOutline, v -> c().chOutline = v));
                    l.add(new Rows.Toggle("Spread when moving", () -> c().chDynamic, v -> c().chDynamic = v));
                    l.add(new Rows.Toggle("Red on target", () -> c().chTargetRed, v -> c().chTargetRed = v));
                    return l;
                });

        // --------------------------------------------------------- Combat
        add(Category.COMBAT, "cps", "CPS counter", "Сколько раз в секунду ты кликаешь ЛКМ",
                () -> c().cps, v -> c().cps = v,
                () -> box(c().cpsBox, new ArrayList<>()));

        add(Category.COMBAT, "target", "Target info", "Имя и здоровье моба или игрока в прицеле",
                () -> c().targetInfo, v -> c().targetInfo = v,
                () -> {
                    List<Rows.Row> l = new ArrayList<>();
                    l.add(new Rows.Toggle("Health number", () -> c().targetNumber, v -> c().targetNumber = v));
                    return box(c().targetBox, l);
                });

        add(Category.COMBAT, "killfx", "Kill effect", "После убийства: молния или дух, улетающий вверх",
                () -> c().killFx, v -> c().killFx = v,
                () -> {
                    List<Rows.Row> l = new ArrayList<>();
                    l.add(new Rows.Cycle("Effect", new String[]{"Lightning", "Spirit", "Both"},
                            () -> c().killMode, v -> c().killMode = v));
                    l.add(new Rows.Cycle("Color", new String[]{"Electric", "Purple", "Rainbow", "White"},
                            () -> c().killColor, v -> c().killColor = v));
                    l.add(new Rows.Toggle("Players only", () -> c().killPlayersOnly, v -> c().killPlayersOnly = v));
                    l.add(new Rows.Label("Срабатывает на цели, которую ты бил."));
                    l.add(new Rows.Label("Рисуется модом, не частицами Minecraft."));
                    return l;
                });

        add(Category.COMBAT, "esp", "Target ESP", "Сферы и кольцо летают вокруг цели в прицеле",
                () -> c().esp, v -> c().esp = v,
                () -> {
                    List<Rows.Row> l = new ArrayList<>();
                    l.add(new Rows.Cycle("Mode", new String[]{"Orbs + ring", "Orbs", "Ring"},
                            () -> c().espMode, v -> c().espMode = v));
                    l.add(new Rows.Cycle("Color", new String[]{"Gradient", "Purple", "Rainbow", "White"},
                            () -> c().espColor, v -> c().espColor = v));
                    l.add(new Rows.Slider("Orbs", 2, 8, 1, () -> c().espOrbs, v -> c().espOrbs = v,
                            v -> (int) v + " pcs", null));
                    l.add(new Rows.Slider("Size", 0.7, 2.0, 0.05, () -> c().espSize, v -> c().espSize = v,
                            v -> f2(v) + "x", null));
                    l.add(new Rows.Slider("Speed", 0.5, 3.0, 0.1, () -> c().espSpeed, v -> c().espSpeed = v,
                            v -> f2(v) + "x", null));
                    return l;
                });

        // ------------------------------------------------------- Movement
        add(Category.MOVEMENT, "autosprint", "Auto sprint", "Бежишь сам, Ctrl зажимать не нужно",
                () -> c().autoSprint, v -> c().autoSprint = v,
                Modules::none);

        add(Category.MOVEMENT, "trail", "Predictive trail", "Светящаяся линия показывает, куда ты полетишь",
                () -> c().trail, v -> c().trail = v,
                () -> {
                    List<Rows.Row> l = new ArrayList<>();
                    l.add(new Rows.Cycle("Mode", new String[]{"Ribbon", "Dots", "Particles"},
                            () -> c().trailMode, v -> c().trailMode = v));
                    l.add(new Rows.Cycle("Color", new String[]{"Gradient", "Purple", "Rainbow"},
                            () -> c().trailColor, v -> c().trailColor = v));
                    l.add(new Rows.Slider("Length", 10, 60, 1, () -> c().trailLength, v -> c().trailLength = v,
                            v -> (int) v + " ticks", null));
                    l.add(new Rows.Slider("Thickness", 1, 6, 1, () -> c().trailThick, v -> c().trailThick = v,
                            v -> (int) v + " px", null));
                    l.add(new Rows.Toggle("Landing marker", () -> c().trailLanding, v -> c().trailLanding = v));
                    l.add(new Rows.Toggle("Only in air", () -> c().trailAirOnly, v -> c().trailAirOnly = v));
                    l.add(new Rows.Cycle("Particle style", new String[]{"End rod", "Flame", "Soul fire", "Spark", "Green"},
                            () -> c().trailStyle, v -> c().trailStyle = v));
                    return l;
                });

        add(Category.MOVEMENT, "jumpcircle", "Jump circle", "Кольцо на земле расходится при каждом прыжке",
                () -> c().jumpCircle, v -> c().jumpCircle = v,
                () -> {
                    List<Rows.Row> l = new ArrayList<>();
                    l.add(new Rows.Cycle("Color", new String[]{"Gradient", "Purple", "Rainbow", "White"},
                            () -> c().jcColor, v -> c().jcColor = v));
                    l.add(new Rows.Slider("Size", 1.0, 4.0, 0.1, () -> c().jcSize, v -> c().jcSize = v,
                            v -> f2(v) + " blocks", null));
                    l.add(new Rows.Slider("Speed", 0.5, 2.0, 0.1, () -> c().jcSpeed, v -> c().jcSpeed = v,
                            v -> f2(v) + "x", null));
                    l.add(new Rows.Toggle("Double ring", () -> c().jcDouble, v -> c().jcDouble = v));
                    l.add(new Rows.Label("Рисуется эффектом мода, не частицами Minecraft."));
                    return l;
                });

        // --------------------------------------------------------- Player
        add(Category.PLAYER, "fullbright", "Fullbright", "Максимальная яркость везде, даже в пещерах",
                () -> c().fullbright, v -> c().fullbright = v,
                Modules::none);

        add(Category.PLAYER, "blockoverlay", "Block overlay", "Свой цвет контура блока, на который смотришь",
                () -> c().blockOverlay, v -> c().blockOverlay = v,
                () -> {
                    List<Rows.Row> l = new ArrayList<>();
                    l.add(new Rows.Toggle("Rainbow", () -> c().blockRainbow, v -> c().blockRainbow = v));
                    l.add(new Rows.Slider("Color (hue)", 0, 360, 1, () -> c().blockHue, v -> c().blockHue = v,
                            v -> (int) v + "\u00B0",
                            () -> 0xFF000000 | (MathHelper.hsvToRgb((float) (c().blockHue / 360.0), 0.85f, 1f) & 0xFFFFFF)));
                    l.add(new Rows.Slider("Opacity", 0.1, 1.0, 0.05, () -> c().blockAlpha, v -> c().blockAlpha = v,
                            v -> Math.round(v * 100) + "%", null));
                    return l;
                });

        add(Category.PLAYER, "customhand", "Custom hand", "Положение и размер руки и предмета в руке",
                () -> c().customHand, v -> c().customHand = v,
                () -> {
                    List<Rows.Row> l = new ArrayList<>();
                    l.add(new Rows.Slider("Offset X", -1.0, 1.0, 0.01, () -> c().handX, v -> c().handX = v, v -> f2(v), null));
                    l.add(new Rows.Slider("Offset Y", -1.0, 1.0, 0.01, () -> c().handY, v -> c().handY = v, v -> f2(v), null));
                    l.add(new Rows.Slider("Offset Z", -1.0, 1.0, 0.01, () -> c().handZ, v -> c().handZ = v, v -> f2(v), null));
                    l.add(new Rows.Slider("Scale", 0.3, 2.0, 0.05, () -> c().handScale, v -> c().handScale = v,
                            v -> f2(v) + "x", null));
                    l.add(new Rows.Buttons(new String[]{"Reset"}, i -> {
                        c().handX = 0; c().handY = 0; c().handZ = 0; c().handScale = 1.0;
                    }));
                    return l;
                });

        add(Category.PLAYER, "swinganim", "Swing animation", "Предмет плавно опускается при ударе, а не просто бьёт",
                () -> c().swingAnim, v -> c().swingAnim = v,
                () -> {
                    List<Rows.Row> l = new ArrayList<>();
                    l.add(new Rows.Cycle("Preset", new String[]{"Smooth drop", "Slow drop", "Slash", "Chop", "Push"},
                            () -> c().swingMode, v -> { c().swingMode = v; c().swingAnim = true; }));
                    l.add(new Rows.Slider("Strength", 0.3, 2.0, 0.05, () -> c().swingStrength, v -> c().swingStrength = v,
                            v -> f2(v) + "x", null));
                    l.add(new Rows.Label("Работает при ударе по цели и взмахе в воздух."));
                    return l;
                });

        add(Category.PLAYER, "freelook", "Freelook", "Оглядывайся камерой, не поворачивая персонажа",
                () -> c().freelook, v -> c().freelook = v,
                () -> {
                    List<Rows.Row> l = new ArrayList<>();
                    l.add(new Rows.Toggle("Toggle mode (not hold)", () -> c().freelookToggle, v -> c().freelookToggle = v));
                    l.add(new Rows.Toggle("Third person while active", () -> c().freelookThird, v -> c().freelookThird = v));
                    l.add(new Rows.Label("Клавиша: Left Alt (меняется в Управлении)."));
                    return l;
                });

        add(Category.PLAYER, "freecam", "Freecam", "Свободная камера, пока персонаж стоит на месте",
                () -> c().freecam, v -> c().freecam = v,
                () -> {
                    List<Rows.Row> l = new ArrayList<>();
                    l.add(new Rows.Slider("Speed", 2, 40, 1, () -> c().freecamSpeed, v -> c().freecamSpeed = v,
                            v -> (int) v + " bl/s", null));
                    l.add(new Rows.Label("Полёт: WASD, Пробел / Shift. Бег = быстрее."));
                    return l;
                });

        // ----------------------------------------------------------- Misc
        add(Category.MISC, "weather", "Weather control", "Погода только у тебя (на стороне клиента)",
                () -> c().weather, v -> c().weather = v,
                () -> {
                    List<Rows.Row> l = new ArrayList<>();
                    l.add(new Rows.Cycle("Weather", new String[]{"Clear", "Rain", "Thunder"},
                            () -> c().weatherType, v -> { c().weatherType = v; c().weather = true; }));
                    return l;
                });

        add(Category.MISC, "time", "Time changer", "Время суток только у тебя (на стороне клиента)",
                () -> c().timeChanger, v -> c().timeChanger = v,
                () -> {
                    List<Rows.Row> l = new ArrayList<>();
                    l.add(new Rows.Slider("Time of day", 0, 24000, 100, () -> c().timeValue,
                            v -> { c().timeValue = (int) v; c().timeChanger = true; },
                            v -> clock((int) v), null));
                    int[] presets = {23000, 1000, 6000, 12000, 13000, 18000};
                    l.add(new Rows.Buttons(new String[]{"Dawn", "Day", "Noon", "Dusk", "Night", "Mid."}, i -> {
                        c().timeValue = presets[i];
                        c().timeChanger = true;
                    }));
                    return l;
                });

        add(Category.MISC, "aspect", "Aspect ratio", "Своё соотношение сторон картинки в игре",
                () -> c().aspectOn, v -> c().aspectOn = v,
                () -> {
                    List<Rows.Row> l = new ArrayList<>();
                    l.add(new Rows.Slider("Ratio", 0.5, 4.0, 0.01, () -> c().aspect,
                            v -> { c().aspect = v; c().aspectOn = true; }, v -> f2(v), null));
                    double[] pr = {16.0 / 9.0, 16.0 / 10.0, 4.0 / 3.0, 21.0 / 9.0, 1.0, 32.0 / 9.0};
                    l.add(new Rows.Buttons(new String[]{"16:9", "16:10", "4:3", "21:9", "1:1", "32:9"}, i -> {
                        c().aspect = pr[i];
                        c().aspectOn = true;
                    }));
                    l.add(new Rows.Buttons(new String[]{"-0.05", "+0.05", "Reset"}, i -> {
                        if (i == 0) c().aspect = Math.max(0.5, c().aspect - 0.05);
                        if (i == 1) c().aspect = Math.min(4.0, c().aspect + 0.05);
                        if (i == 2) c().aspect = 16.0 / 9.0;
                        c().aspectOn = true;
                    }));
                    l.add(new Rows.Label("Меняет только картинку мира, HUD остаётся прежним."));
                    return l;
                });

        add(Category.MISC, "sky", "Custom sky", "Своё небо: северное сияние, звёзды или галактика",
                () -> c().sky, v -> c().sky = v,
                () -> {
                    List<Rows.Row> l = new ArrayList<>();
                    l.add(new Rows.Cycle("Mode", new String[]{"Aurora", "Stars", "Galaxy"},
                            () -> c().skyMode, v -> c().skyMode = v));
                    l.add(new Rows.Slider("Sky darkening", 0.0, 1.0, 0.05, () -> c().skyTint, v -> c().skyTint = v,
                            v -> Math.round(v * 100) + "%", null));
                    l.add(new Rows.Slider("Stars amount", 0.3, 2.0, 0.1, () -> c().skyStars, v -> c().skyStars = v,
                            v -> f2(v) + "x", null));
                    l.add(new Rows.Cycle("Aurora colors", new String[]{"Green", "Blue", "Pink"},
                            () -> c().skyAurora, v -> c().skyAurora = v));
                    l.add(new Rows.Toggle("Night only", () -> c().skyNightOnly, v -> c().skyNightOnly = v));
                    l.add(new Rows.Label("Рисуется поверх картинки, горы и дома не перекрываются."));
                    return l;
                });

        add(Category.MISC, "misty", "Misty", "Красивый туман: дымка у горизонта и плывущие облака",
                () -> c().misty, v -> c().misty = v,
                () -> {
                    List<Rows.Row> l = new ArrayList<>();
                    l.add(new Rows.Cycle("Color", new String[]{"White", "Blue", "Purple", "Warm"},
                            () -> c().mistStyle, v -> c().mistStyle = v));
                    l.add(new Rows.Slider("Strength", 0.1, 1.0, 0.05, () -> c().mistStrength, v -> c().mistStrength = v,
                            v -> Math.round(v * 100) + "%", null));
                    l.add(new Rows.Toggle("Drifting wisps", () -> c().mistWisps, v -> c().mistWisps = v));
                    return l;
                });

        add(Category.MISC, "mainmenu", "Custom main menu", "Своё главное меню с большими часами",
                () -> c().mainMenu, v -> c().mainMenu = v,
                () -> {
                    List<Rows.Row> l = new ArrayList<>();
                    l.add(new Rows.Toggle("24-hour clock", () -> c().clock24, v -> c().clock24 = v));
                    l.add(new Rows.Toggle("Show seconds", () -> c().clockSeconds, v -> c().clockSeconds = v));
                    l.add(new Rows.Toggle("Show date", () -> c().clockDate, v -> c().clockDate = v));
                    l.add(new Rows.Cycle("Clock color", new String[]{"White", "Purple", "Gradient"},
                            () -> c().clockStyle, v -> c().clockStyle = v));
                    l.add(new Rows.Label("Применится при следующем открытии главного меню."));
                    return l;
                });

        add(Category.MISC, "menuskin", "Custom menus", "Миры, сервера и настройки в стиле DobriVisual",
                () -> c().menuSkin, v -> c().menuSkin = v,
                () -> {
                    List<Rows.Row> l = new ArrayList<>();
                    l.add(new Rows.Toggle("Animated background", () -> c().menuAnimBg, v -> c().menuAnimBg = v));
                    l.add(new Rows.Toggle("Rounded buttons", () -> c().menuRound, v -> c().menuRound = v));
                    l.add(new Rows.Label("Только вне мира: выбор мира, сервера, настройки."));
                    return l;
                });

        add(Category.MISC, "rmbopen", "Open on right click", "ПКМ пустой рукой по воздуху открывает меню",
                () -> c().openOnRightClick, v -> c().openOnRightClick = v,
                Modules::none);
    }
}
