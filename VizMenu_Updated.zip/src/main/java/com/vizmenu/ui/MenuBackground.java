package com.vizmenu.ui;

import com.vizmenu.Brand;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.Random;

/** Animated background for the main menu and the world / server / settings screens. */
public final class MenuBackground {
    private static final int BOKEH = 34;
    private static final float[] BX = new float[BOKEH], BP = new float[BOKEH], BR = new float[BOKEH], BS = new float[BOKEH];
    private static final int[] BC = {0xA78BFA, 0xE879F9, 0x67E8F9, 0x818CF8};
    private static final int STARS = 60;
    private static final float[] SX = new float[STARS], SY = new float[STARS], SP = new float[STARS];

    static {
        Random r = new Random(11L);
        for (int i = 0; i < BOKEH; i++) {
            BX[i] = r.nextFloat();
            BP[i] = r.nextFloat();
            BR[i] = 1.2f + r.nextFloat() * 4.5f;
            BS[i] = 0.015f + r.nextFloat() * 0.03f;
        }
        for (int i = 0; i < STARS; i++) {
            SX[i] = r.nextFloat();
            SY[i] = r.nextFloat() * 0.75f;
            SP[i] = r.nextFloat() * 6.28f;
        }
    }

    private MenuBackground() {}

    private static int argb(int a, int rgb) {
        return (Math.max(0, Math.min(255, a)) << 24) | (rgb & 0xFFFFFF);
    }

    public static void draw(DrawContext c, MinecraftClient mc, int w, int h) {
        Ui.begin(mc);
        double t = System.currentTimeMillis() / 1000.0;

        // slowly drifting base gradient
        float k1 = 0.5f + 0.5f * (float) Math.sin(t * 0.15);
        float k2 = 0.5f + 0.5f * (float) Math.sin(t * 0.11 + 2.0);
        int top = Brand.lerp(0xFF07070C, 0xFF0C0A22, k1);
        int bot = Brand.lerp(0xFF170F30, 0xFF0A1C30, k2);
        c.fillGradient(0, 0, w, h, top, bot);

        // three large soft glows moving on slow loops
        int[] glow = {0x8B5CF6, 0xE879F9, 0x38BDF8};
        for (int i = 0; i < 3; i++) {
            double gx = w * (0.5 + 0.38 * Math.sin(t * (0.10 + i * 0.037) + i * 2.1));
            double gy = h * (0.5 + 0.30 * Math.sin(t * (0.13 + i * 0.029) + i * 1.3));
            double r = h * (0.38 + 0.05 * Math.sin(t * 0.2 + i));
            Ui.softDisc(c, gx, gy, r, argb(7, glow[i]));
            Ui.softDisc(c, gx, gy, r * 0.72, argb(9, glow[i]));
            Ui.softDisc(c, gx, gy, r * 0.46, argb(12, glow[i]));
            Ui.softDisc(c, gx, gy, r * 0.24, argb(14, glow[i]));
        }

        // twinkling stars
        for (int i = 0; i < STARS; i++) {
            float tw = 0.5f + 0.5f * (float) Math.sin(t * 1.1 + SP[i]);
            int a = (int) (30 + 110 * tw);
            int sx = (int) (SX[i] * w), sy = (int) (SY[i] * h);
            c.fill(sx, sy, sx + 1, sy + 1, argb(a, 0xFFFFFF));
        }

        // floating bokeh rising slowly
        for (int i = 0; i < BOKEH; i++) {
            double cyc = (t * BS[i] + BP[i]) % 1.0;
            double y = h * (1.08 - cyc * 1.2);
            double x = w * BX[i] + Math.sin(t * 0.4 + BP[i] * 6.28) * w * 0.02;
            double fade = Math.sin(Math.PI * Math.min(1.0, Math.max(0.0, cyc)));
            int a = (int) (60 * fade);
            if (a < 2) continue;
            Ui.circle(c, x, y, BR[i] * 1.8, argb(a / 3, BC[i % BC.length]));
            Ui.circle(c, x, y, BR[i], argb(a, BC[i % BC.length]));
        }
    }
}
