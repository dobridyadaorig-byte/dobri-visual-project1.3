package com.vizmenu.ui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public final class Ui {
    public static final int BORDER = 0xFF2B2C35;
    public static final int PANEL = 0xFF15161A;
    public static final int ROW = 0xFF1E1F26;
    public static final int ROWH = 0xFF272832;
    public static final int ACC = 0xFF8B5CF6;
    public static final int TXT = 0xFFE9E9F0;
    public static final int DIM = 0xFF8B8C98;
    public static final int OFF = 0xFF3A3B46;

    private Ui() {}

    /** Rectangle with softly cut corners. */
    public static void rrect(DrawContext c, int x, int y, int w, int h, int col) {
        if (w <= 2 || h <= 2) {
            c.fill(x, y, x + w, y + h, col);
            return;
        }
        c.fill(x + 1, y, x + w - 1, y + h, col);
        c.fill(x, y + 1, x + 1, y + h - 1, col);
        c.fill(x + w - 1, y + 1, x + w, y + h - 1, col);
    }

    /** Fully rounded (pill-shaped) rectangle. */
    public static void pill(DrawContext c, int x, int y, int w, int h, int col) {
        double r = h / 2.0;
        for (int i = 0; i < h; i++) {
            double dy = (i + 0.5) - r;
            int inset = (int) Math.round(r - Math.sqrt(Math.max(0.0, r * r - dy * dy)));
            c.fill(x + inset, y + i, x + w - inset, y + i + 1, col);
        }
    }

    // ------------------------------------------------------------------
    // Smooth shapes: laid out in GUI units, drawn in framebuffer pixels.
    public static double sf = 1.0;
    public static int devW = 1920, devH = 1080;

    public static void begin(MinecraftClient mc) {
        sf = mc.getWindow().getScaleFactor();
        devW = mc.getWindow().getFramebufferWidth();
        devH = mc.getWindow().getFramebufferHeight();
    }

    /** Rounded rectangle with radius r (GUI units). */
    public static void rr(DrawContext c, double x, double y, double w, double h, double r, int col) {
        if ((col >>> 24) == 0 || w <= 0 || h <= 0) return;
        c.getMatrices().pushMatrix();
        float inv = (float) (1.0 / sf);
        c.getMatrices().scale(inv, inv);
        int X = (int) Math.round(x * sf), Y = (int) Math.round(y * sf);
        int W = (int) Math.round(w * sf), H = (int) Math.round(h * sf);
        int R = (int) Math.round(r * sf);
        R = Math.min(R, Math.min(W, H) / 2);
        if (R <= 0) {
            c.fill(X, Y, X + W, Y + H, col);
        } else {
            int step = Math.max(1, R / 24);
            for (int i = 0; i < R; i += step) {
                int s = Math.min(step, R - i);
                double dy = R - i - s * 0.5;
                int inset = R - (int) Math.round(Math.sqrt(Math.max(0.0, (double) R * R - dy * dy)));
                c.fill(X + inset, Y + i, X + W - inset, Y + i + s, col);
                c.fill(X + inset, Y + H - i - s, X + W - inset, Y + H - i, col);
            }
            c.fill(X, Y + R, X + W, Y + H - R, col);
        }
        c.getMatrices().popMatrix();
    }

    public static void circle(DrawContext c, double cx, double cy, double r, int col) {
        rr(c, cx - r, cy - r, r * 2, r * 2, r, col);
    }

    /** Large soft disc (backgrounds), rows are batched for speed. */
    public static void softDisc(DrawContext c, double cx, double cy, double r, int col) {
        if ((col >>> 24) == 0 || r <= 0) return;
        double X = cx * sf, Y = cy * sf, R = r * sf;
        if (X + R < 0 || X - R > devW || Y + R < 0 || Y - R > devH) return;
        c.getMatrices().pushMatrix();
        float inv = (float) (1.0 / sf);
        c.getMatrices().scale(inv, inv);
        int ri = (int) Math.ceil(R);
        int step = Math.max(1, ri / 40);
        int ix = (int) Math.round(X), iy = (int) Math.round(Y);
        for (int dy = -ri; dy < ri; dy += step) {
            double yy = dy + step * 0.5;
            double rem = R * R - yy * yy;
            if (rem <= 0) continue;
            int hw = (int) Math.round(Math.sqrt(rem));
            c.fill(ix - hw, iy + dy, ix + hw, iy + dy + step, col);
        }
        c.getMatrices().popMatrix();
    }

    /** Small chevron: down when open, right when closed. */
    public static void chevron(DrawContext c, double cx, double cy, boolean down, int col) {
        c.getMatrices().pushMatrix();
        float inv = (float) (1.0 / sf);
        c.getMatrices().scale(inv, inv);
        double X = cx * sf, Y = cy * sf, s = 3.2 * sf;
        int t = Math.max(2, (int) Math.round(1.1 * sf));
        int n = 10;
        for (int i = 0; i <= n; i++) {
            double k = i / (double) n;
            double ax, ay, bx, by;
            if (down) {
                ax = X - s + k * s; ay = Y - s * 0.5 + k * s * 0.9;
                bx = X + s - k * s; by = ay;
            } else {
                ax = X - s * 0.5 + k * s * 0.9; ay = Y - s + k * s;
                bx = ax; by = Y + s - k * s;
            }
            int x1 = (int) Math.round(ax), y1 = (int) Math.round(ay);
            int x2 = (int) Math.round(bx), y2 = (int) Math.round(by);
            c.fill(x1 - t / 2, y1 - t / 2, x1 - t / 2 + t, y1 - t / 2 + t, col);
            c.fill(x2 - t / 2, y2 - t / 2, x2 - t / 2 + t, y2 - t / 2 + t, col);
        }
        c.getMatrices().popMatrix();
    }
}
