package com.vizmenu;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Jump circle, predictive trail, kill effect (lightning / spirit) and target ESP. All drawn by the mod. */
public final class Effects {
    private static final Random RND = new Random();
    private static final BlockPos.Mutable MP = new BlockPos.Mutable();
    private static final double[] PT = new double[3];

    // ---- jump circle
    private static final int MAX_RINGS = 6;
    private static final double[] RX = new double[MAX_RINGS], RY = new double[MAX_RINGS], RZ = new double[MAX_RINGS];
    private static final long[] RT = new long[MAX_RINGS];
    private static int ringCount = 0;
    private static boolean wasGround = true;
    private static double groundX, groundY, groundZ;
    private static final double[] RING_X = new double[49], RING_Y = new double[49];
    private static final boolean[] RING_OK = new boolean[49];

    // ---- trail
    private static final int MAX_TRAIL = 64;
    private static final double[] TX = new double[MAX_TRAIL], TY = new double[MAX_TRAIL], TZ = new double[MAX_TRAIL];
    private static int trailN = 0;
    private static boolean trailLands = false;
    private static double baseX, baseY, baseZ;

    // ---- kill effect
    private static final int MAX_TRACK = 8;
    private static final LivingEntity[] TRK = new LivingEntity[MAX_TRACK];
    private static final long[] TRK_T = new long[MAX_TRACK];
    private static boolean killDirty = false;

    private static final int BOLT_N = 16;
    private static final class Bolt {
        final double[] x = new double[BOLT_N + 1], y = new double[BOLT_N + 1], z = new double[BOLT_N + 1];
        final double[][] bx = new double[3][6], by = new double[3][6], bz = new double[3][6];
        double cx, cy, cz;
        long t0;
    }
    private static final class Spirit {
        double x, y, z, w, h;
        long t0;
    }
    private static final List<Bolt> BOLTS = new ArrayList<>();
    private static final List<Spirit> SPIRITS = new ArrayList<>();

    // ---- target esp
    private static LivingEntity espEnt;
    private static long espTime;
    private static final int MAX_ORB = 24;
    private static final double[] OX = new double[MAX_ORB], OY = new double[MAX_ORB], OD = new double[MAX_ORB],
            OR = new double[MAX_ORB], OA = new double[MAX_ORB];
    private static final int[] ORGB = new int[MAX_ORB];
    private static final int[] ORDER = new int[MAX_ORB];

    private Effects() {}

    // ================================================================== helpers
    private static int ac(double a, int rgb) {
        return (Math.max(0, Math.min(255, (int) (a * 255.0))) << 24) | (rgb & 0xFFFFFF);
    }

    private static int colorAt(int mode, float k, long now) {
        switch (mode) {
            case 1: return 0xFFA78BFA;
            case 2: return 0xFF000000 | (MathHelper.hsvToRgb(((k + now / 2500f) % 1f + 1f) % 1f, 0.8f, 1f) & 0xFFFFFF);
            case 3: return 0xFFFFFFFF;
            default: return Brand.lerp(0xFF8B5CF6, 0xFFE879F9, 0.5f + 0.5f * (float) Math.sin(k * 6.2831853f + now / 500f));
        }
    }

    /** Kill effect palette: electric (white / blue), purple, rainbow, white. */
    private static int killRgb(int mode, float k, long now, boolean core) {
        switch (mode) {
            case 1: return core ? 0xE9D5FF : 0xA78BFA;
            case 2: return MathHelper.hsvToRgb(((k * 0.7f + now / 2000f) % 1f + 1f) % 1f, core ? 0.3f : 0.8f, 1f) & 0xFFFFFF;
            case 3: return core ? 0xFFFFFF : 0xD8DCE8;
            default: return core ? 0xFFFFFF : 0x9CC4FF;
        }
    }

    // ===================================================================== tick
    public static void tick(MinecraftClient mc, ClientPlayerEntity p, Config c) {
        // jump circle
        boolean ground = p.isOnGround();
        if (ground) {
            groundX = p.getX();
            groundY = p.getY();
            groundZ = p.getZ();
        }
        if (c.jumpCircle && wasGround && !ground && p.getVelocity().y > 0.1) {
            addRing(groundX, groundY, groundZ);
        }
        wasGround = ground;

        // predictive trail path
        if (c.trail && c.trailMode != 2) simTrail(mc, p, c);
        else trailN = 0;

        // target esp + kill effect
        long now = System.currentTimeMillis();
        espTick(mc, c, now);
        killTick(mc, c, now);
    }

    // ============================================================ jump circle
    private static void addRing(double x, double y, double z) {
        if (ringCount == MAX_RINGS) {
            for (int i = 1; i < MAX_RINGS; i++) {
                RX[i - 1] = RX[i]; RY[i - 1] = RY[i]; RZ[i - 1] = RZ[i]; RT[i - 1] = RT[i];
            }
            ringCount--;
        }
        RX[ringCount] = x;
        RY[ringCount] = y;
        RZ[ringCount] = z;
        RT[ringCount] = System.currentTimeMillis();
        ringCount++;
    }

    private static void removeRing(int i) {
        for (int k = i + 1; k < ringCount; k++) {
            RX[k - 1] = RX[k]; RY[k - 1] = RY[k]; RZ[k - 1] = RZ[k]; RT[k - 1] = RT[k];
        }
        ringCount--;
    }

    /** fixedRgb >= 0 overrides the palette. */
    private static void drawRing(DrawContext ctx, double x, double y, double z, double r, double alpha,
                                 int mode, int thin, long now, int fixedRgb) {
        if (alpha * 255.0 < 3.0) return;
        int n = 48;
        for (int i = 0; i <= n; i++) {
            double a = i * (Math.PI * 2.0 / n);
            RING_OK[i] = Proj.project(x + Math.cos(a) * r, y, z + Math.sin(a) * r, PT);
            RING_X[i] = PT[0];
            RING_Y[i] = PT[1];
        }
        int a255 = (int) Math.max(0, Math.min(255, alpha * 255.0));
        int aGlow = (int) (a255 * 0.22);
        for (int i = 0; i < n; i++) {
            if (!RING_OK[i] || !RING_OK[i + 1]) continue;
            int rgb = (fixedRgb >= 0 ? fixedRgb : colorAt(mode, i / (float) n, now)) & 0xFFFFFF;
            Proj.line(ctx, RING_X[i], RING_Y[i], RING_X[i + 1], RING_Y[i + 1], thin * 4, (aGlow << 24) | rgb);
            Proj.line(ctx, RING_X[i], RING_Y[i], RING_X[i + 1], RING_Y[i + 1], thin, (a255 << 24) | rgb);
        }
    }

    private static void renderRings(DrawContext ctx, Config c, long now) {
        int thin = Math.max(2, Proj.fbh / 320);
        for (int i = ringCount - 1; i >= 0; i--) {
            double dur = 900.0 / Math.max(0.3, c.jcSpeed);
            double t = (now - RT[i]) / dur;
            if (t >= 1.0) {
                removeRing(i);
                continue;
            }
            double e = 1.0 - Math.pow(1.0 - t, 3.0);
            double r = 0.3 + (c.jcSize - 0.3) * e;
            drawRing(ctx, RX[i], RY[i] + 0.03, RZ[i], r, Math.pow(1.0 - t, 1.4), c.jcColor, thin, now, -1);
            if (c.jcDouble && t > 0.1) {
                double t2 = (t - 0.1) / 0.9;
                double e2 = 1.0 - Math.pow(1.0 - t2, 3.0);
                double r2 = 0.2 + (c.jcSize * 0.62 - 0.2) * e2;
                drawRing(ctx, RX[i], RY[i] + 0.03, RZ[i], r2, Math.pow(1.0 - t2, 1.6) * 0.7, c.jcColor, thin, now, -1);
            }
        }
    }

    // ================================================================= trail
    private static void simTrail(MinecraftClient mc, ClientPlayerEntity p, Config c) {
        Vec3d v = p.getVelocity();
        boolean moving = v.x * v.x + v.z * v.z > 0.0025 || Math.abs(v.y) > 0.1;
        if (!moving || (c.trailAirOnly && p.isOnGround())) {
            trailN = 0;
            return;
        }
        double x = p.getX(), y = p.getY() + 0.1, z = p.getZ();
        baseX = p.getX();
        baseY = p.getY();
        baseZ = p.getZ();
        double vx = v.x, vy = v.y, vz = v.z;
        int steps = Math.min(MAX_TRAIL - 1, (int) c.trailLength);
        boolean startedAirborne = !p.isOnGround();
        trailN = 0;
        trailLands = false;
        TX[trailN] = x; TY[trailN] = y; TZ[trailN] = z; trailN++;
        for (int i = 1; i <= steps; i++) {
            x += vx;
            y += vy;
            z += vz;
            if (!mc.world.getBlockState(MP.set(x, y, z)).isAir()) {
                trailLands = startedAirborne;
                break;
            }
            if (vy <= 0 && !mc.world.getBlockState(MP.set(x, y - 0.2, z)).isAir()) vy = 0;
            else vy = (vy - 0.08) * 0.98;
            vx *= 0.9;
            vz *= 0.9;
            TX[trailN] = x; TY[trailN] = y; TZ[trailN] = z; trailN++;
        }
    }

    private static void renderTrail(DrawContext ctx, MinecraftClient mc, Config c, float td, long now) {
        if (trailN < 2) return;
        Vec3d lp = mc.player.getLerpedPos(td);
        double sx = lp.x - baseX, sy = lp.y - baseY, sz = lp.z - baseZ;
        int thin = Math.max(2, (int) Math.round(c.trailThick * Proj.fbh / 540.0));
        double px = 0, py = 0;
        boolean prevOk = false;
        for (int i = 0; i < trailN; i++) {
            boolean ok = Proj.project(TX[i] + sx, TY[i] + sy, TZ[i] + sz, PT);
            double cxp = PT[0], cyp = PT[1];
            float f = i / (float) (trailN - 1);
            if (ok && prevOk) {
                int a = (int) (235 * Math.pow(1.0 - f, 0.9));
                int rgb;
                if (c.trailColor == 1) rgb = 0xA78BFA;
                else if (c.trailColor == 2) rgb = MathHelper.hsvToRgb(((f * 0.8f + now / 2500f) % 1f + 1f) % 1f, 0.8f, 1f) & 0xFFFFFF;
                else rgb = Brand.lerp(0xFF8B5CF6, 0xFF67E8F9, f) & 0xFFFFFF;
                int w = Math.max(2, Math.round(thin * (1.0f - 0.55f * f)));
                if (c.trailMode == 1) {
                    if ((i & 1) == 0) {
                        Proj.line(ctx, cxp, cyp, cxp, cyp, w * 3, ((a / 4) << 24) | rgb);
                        Proj.line(ctx, cxp, cyp, cxp, cyp, w * 2, (a << 24) | rgb);
                    }
                } else {
                    Proj.line(ctx, px, py, cxp, cyp, w * 3, ((a / 5) << 24) | rgb);
                    Proj.line(ctx, px, py, cxp, cyp, w, (a << 24) | rgb);
                }
            }
            px = cxp;
            py = cyp;
            prevOk = ok;
        }
        if (c.trailLanding && trailLands) {
            int last = trailN - 1;
            drawRing(ctx, TX[last] + sx, TY[last] + sy - 0.05, TZ[last] + sz, 0.35, 0.8,
                    c.trailColor == 1 ? 1 : (c.trailColor == 2 ? 2 : 0), Math.max(2, thin), now, -1);
        }
    }

    // ============================================================== target esp
    private static void espTick(MinecraftClient mc, Config c, long now) {
        if (!c.esp) {
            espEnt = null;
            return;
        }
        if (mc.crosshairTarget instanceof EntityHitResult hit && hit.getEntity() instanceof LivingEntity tgt
                && tgt != mc.player) {
            espEnt = tgt;
            espTime = now;
        }
        if (espEnt != null && (espEnt.isRemoved() || !espEnt.isAlive() || now - espTime > 3000L)) espEnt = null;
    }

    private static void renderEsp(DrawContext ctx, MinecraftClient mc, Config c, float td, long now) {
        LivingEntity e = espEnt;
        if (e == null) return;
        long age = now - espTime;
        double fade = age < 2200L ? 1.0 : Math.max(0.0, 1.0 - (age - 2200L) / 800.0);
        if (fade < 0.02) return;

        Vec3d lp = e.getLerpedPos(td);
        double w = e.getWidth(), h = e.getHeight();
        double t = now / 1000.0 * c.espSpeed;
        double size = c.espSize;
        int thin = Math.max(2, Proj.fbh / 320);

        // ring flying up and down the body, with a short ghost trail
        if (c.espMode != 1) {
            double r = (w * 0.5 + 0.38) * size;
            for (int k = 0; k < 4; k++) {
                double fk = 0.5 + 0.5 * Math.sin(t * 1.7 - k * 0.28);
                double a = fade * (k == 0 ? 0.95 : 0.5 / k);
                drawRing(ctx, lp.x, lp.y + fk * h, lp.z, r, a, c.espColor, thin, now, -1);
            }
        }

        // orbs circling the target
        if (c.espMode != 2) {
            int n = Math.max(2, Math.min(8, (int) c.espOrbs));
            int cnt = 0;
            double r = (w * 0.5 + 0.6) * size;
            for (int i = 0; i < n; i++) {
                double ang = t * 1.9 + i * (Math.PI * 2.0 / n);
                double yy = lp.y + h * (0.15 + 0.7 * (0.5 + 0.5 * Math.sin(t * 1.25 + i * 1.9)));
                int rgb = colorAt(c.espColor, i / (float) n, now) & 0xFFFFFF;
                for (int tr = 0; tr < 3; tr++) {
                    double a2 = ang - tr * 0.22;
                    if (!Proj.project(lp.x + Math.cos(a2) * r, yy, lp.z + Math.sin(a2) * r, PT)) continue;
                    OX[cnt] = PT[0];
                    OY[cnt] = PT[1];
                    OD[cnt] = Proj.lastDepth();
                    OR[cnt] = Proj.pxRadius(0.11 * size * (1.0 - tr * 0.28));
                    OA[cnt] = fade * (1.0 - tr * 0.38);
                    ORGB[cnt] = rgb;
                    cnt++;
                }
            }
            // far orbs first
            for (int i = 0; i < cnt; i++) ORDER[i] = i;
            for (int i = 1; i < cnt; i++) {
                int key = ORDER[i];
                int j = i - 1;
                while (j >= 0 && OD[ORDER[j]] < OD[key]) {
                    ORDER[j + 1] = ORDER[j];
                    j--;
                }
                ORDER[j + 1] = key;
            }
            for (int q = 0; q < cnt; q++) {
                int i = ORDER[q];
                Proj.disc(ctx, OX[i], OY[i], OR[i] * 2.4, ac(OA[i] * 0.12, ORGB[i]));
                Proj.disc(ctx, OX[i], OY[i], OR[i] * 1.5, ac(OA[i] * 0.30, ORGB[i]));
                Proj.disc(ctx, OX[i], OY[i], OR[i], ac(OA[i] * 0.95, 0xFFFFFF));
            }
        }
    }

    // ============================================================ kill effect
    private static void track(LivingEntity le, long now) {
        int free = -1, oldest = 0;
        for (int i = 0; i < MAX_TRACK; i++) {
            if (TRK[i] == le) {
                TRK_T[i] = now;
                return;
            }
            if (TRK[i] == null && free < 0) free = i;
            if (TRK_T[i] < TRK_T[oldest]) oldest = i;
        }
        int slot = free >= 0 ? free : oldest;
        TRK[slot] = le;
        TRK_T[slot] = now;
    }

    private static void killTick(MinecraftClient mc, Config c, long now) {
        if (!c.killFx) {
            if (killDirty) {
                BOLTS.clear();
                SPIRITS.clear();
                for (int i = 0; i < MAX_TRACK; i++) TRK[i] = null;
                killDirty = false;
            }
            return;
        }
        killDirty = true;
        if (mc.options.attackKey.isPressed() && mc.crosshairTarget instanceof EntityHitResult hit
                && hit.getEntity() instanceof LivingEntity tgt && tgt != mc.player) {
            track(tgt, now);
        }
        for (int i = 0; i < MAX_TRACK; i++) {
            LivingEntity le = TRK[i];
            if (le == null) continue;
            if (now - TRK_T[i] > 8000L) {
                TRK[i] = null;
                continue;
            }
            if (le.isDead() || le.getHealth() <= 0f || le.isRemoved()) {
                if (!c.killPlayersOnly || le instanceof PlayerEntity) onKill(le, c, now);
                TRK[i] = null;
            }
        }
    }

    private static void onKill(LivingEntity le, Config c, long now) {
        if (c.killMode == 0 || c.killMode == 2) startBolt(le.getX(), le.getY(), le.getZ(), now);
        if (c.killMode == 1 || c.killMode == 2) startSpirit(le, now);
    }

    private static void startBolt(double x, double y, double z, long now) {
        if (BOLTS.size() >= 4) BOLTS.remove(0);
        Bolt b = new Bolt();
        b.cx = x; b.cy = y; b.cz = z; b.t0 = now;
        double top = y + 26.0;
        double ox = 0, oz = 0;
        for (int i = 0; i <= BOLT_N; i++) {
            double t = i / (double) BOLT_N;
            if (i > 0) {
                double m = 1.6 * (1.0 - t * 0.6);
                ox += (RND.nextDouble() - 0.5) * m;
                oz += (RND.nextDouble() - 0.5) * m;
            }
            double pull = t * t * t;
            b.x[i] = x + ox * (1.0 - pull);
            b.y[i] = top - (top - y) * t;
            b.z[i] = z + oz * (1.0 - pull);
        }
        for (int k = 0; k < 3; k++) {
            int from = 3 + RND.nextInt(8);
            double ang = RND.nextDouble() * Math.PI * 2.0;
            b.bx[k][0] = b.x[from];
            b.by[k][0] = b.y[from];
            b.bz[k][0] = b.z[from];
            for (int j = 1; j < 6; j++) {
                b.bx[k][j] = b.bx[k][j - 1] + Math.cos(ang) * 0.8 + (RND.nextDouble() - 0.5) * 0.6;
                b.by[k][j] = b.by[k][j - 1] - (1.2 + RND.nextDouble());
                b.bz[k][j] = b.bz[k][j - 1] + Math.sin(ang) * 0.8 + (RND.nextDouble() - 0.5) * 0.6;
            }
        }
        BOLTS.add(b);
    }

    private static void startSpirit(LivingEntity le, long now) {
        if (SPIRITS.size() >= 4) SPIRITS.remove(0);
        Spirit s = new Spirit();
        s.x = le.getX(); s.y = le.getY(); s.z = le.getZ();
        s.w = le.getWidth(); s.h = le.getHeight();
        s.t0 = now;
        SPIRITS.add(s);
    }

    private static void renderBolts(DrawContext ctx, Config c, long now) {
        int th = Math.max(2, Proj.fbh / 360);
        for (int bi = BOLTS.size() - 1; bi >= 0; bi--) {
            Bolt b = BOLTS.get(bi);
            long age = now - b.t0;
            if (age > 750L) {
                BOLTS.remove(bi);
                continue;
            }
            double a = age < 90L ? 1.0 : (age < 150L ? 0.35 : (age < 230L ? 1.0 : Math.max(0.0, 1.0 - (age - 230L) / 520.0)));
            if (a < 0.02) continue;

            // screen flash
            if (age < 260L) {
                int fa = (int) (55 * (1.0 - age / 260.0));
                ctx.fill(0, 0, Proj.fbw, Proj.fbh, (fa << 24) | 0xFFFFFF);
            }

            // main bolt
            double px = 0, py = 0;
            boolean prev = false;
            for (int i = 0; i <= BOLT_N; i++) {
                boolean ok = Proj.project(b.x[i], b.y[i], b.z[i], PT);
                if (ok && prev) {
                    int glow = killRgb(c.killColor, i / (float) BOLT_N, now, false);
                    int core = killRgb(c.killColor, i / (float) BOLT_N, now, true);
                    Proj.line(ctx, px, py, PT[0], PT[1], th * 6, ac(a * 0.16, glow));
                    Proj.line(ctx, px, py, PT[0], PT[1], th * 3, ac(a * 0.5, glow));
                    Proj.line(ctx, px, py, PT[0], PT[1], th, ac(a, core));
                }
                px = PT[0];
                py = PT[1];
                prev = ok;
            }
            // branches
            for (int k = 0; k < 3; k++) {
                prev = false;
                for (int j = 0; j < 6; j++) {
                    boolean ok = Proj.project(b.bx[k][j], b.by[k][j], b.bz[k][j], PT);
                    if (ok && prev) {
                        int glow = killRgb(c.killColor, 0.5f, now, false);
                        Proj.line(ctx, px, py, PT[0], PT[1], th * 3, ac(a * 0.3, glow));
                        Proj.line(ctx, px, py, PT[0], PT[1], Math.max(2, th * 2 / 3), ac(a * 0.8, killRgb(c.killColor, 0.5f, now, true)));
                    }
                    px = PT[0];
                    py = PT[1];
                    prev = ok;
                }
            }
            // ground impact
            if (age < 450L) {
                double r = 0.4 + (age / 350.0) * 1.8;
                drawRing(ctx, b.cx, b.cy + 0.03, b.cz, r, Math.pow(1.0 - age / 450.0, 1.2), 0, Math.max(2, th),
                        now, killRgb(c.killColor, 0.3f, now, false));
            }
        }
    }

    private static void renderSpirits(DrawContext ctx, Config c, long now) {
        for (int si = SPIRITS.size() - 1; si >= 0; si--) {
            Spirit s = SPIRITS.get(si);
            double t = (now - s.t0) / 1900.0;
            if (t >= 1.0) {
                SPIRITS.remove(si);
                continue;
            }
            double e = t * t * (3.0 - 2.0 * t);
            double alpha = Math.min(1.0, t * 8.0) * Math.pow(1.0 - t, 1.1);
            if (alpha < 0.012) continue;
            double sc = Math.max(0.6, s.h / 1.8);
            double cy = s.y + s.h * 0.5 + e * 6.5;
            double sway = Math.sin(t * 9.0) * 0.25 * (0.3 + t);
            int body = killRgb(c.killColor, 0.2f, now, false);
            int core = killRgb(c.killColor, 0.2f, now, true);

            // soft aura
            if (Proj.project(s.x + sway * 0.4, cy, s.z, PT)) {
                double rr = Proj.pxRadius(0.95 * sc);
                Proj.disc(ctx, PT[0], PT[1], rr, ac(alpha * 0.10, body));
                Proj.disc(ctx, PT[0], PT[1], rr * 0.6, ac(alpha * 0.13, body));
            }

            // wavy tail, far end first
            for (int k = 6; k >= 1; k--) {
                double off = sway * (0.4 + 0.3 * k) + Math.sin(k * 0.9 + t * 7.0) * 0.07 * k;
                double wy = cy + 0.25 * sc - k * 0.2 * sc;
                if (!Proj.project(s.x + off, wy, s.z, PT)) continue;
                double rr = Proj.pxRadius(0.26 * sc * (1.0 - k * 0.11));
                int rgb = killRgb(c.killColor, k / 7f, now, false);
                double a = alpha * (0.62 - k * 0.07);
                Proj.disc(ctx, PT[0], PT[1], rr * 1.5, ac(a * 0.25, rgb));
                Proj.disc(ctx, PT[0], PT[1], rr, ac(a, rgb));
            }

            // head with face
            if (Proj.project(s.x + sway * 0.4, cy + 0.25 * sc, s.z, PT)) {
                double hx = PT[0], hy = PT[1];
                double rr = Proj.pxRadius(0.26 * sc);
                Proj.disc(ctx, hx, hy, rr * 1.6, ac(alpha * 0.22, body));
                Proj.disc(ctx, hx, hy, rr, ac(alpha * 0.9, core));
                double es = Math.max(2.0, rr * 0.2);
                int eye = ac(alpha * 0.9, 0x101018);
                int ex1 = (int) Math.round(hx - rr * 0.38), ex2 = (int) Math.round(hx + rr * 0.38);
                int ey = (int) Math.round(hy - rr * 0.1);
                int ei = (int) Math.round(es);
                ctx.fill(ex1 - ei / 2, ey - ei / 2, ex1 - ei / 2 + ei, ey - ei / 2 + ei * 3 / 2, eye);
                ctx.fill(ex2 - ei / 2, ey - ei / 2, ex2 - ei / 2 + ei, ey - ei / 2 + ei * 3 / 2, eye);
                int mx = (int) Math.round(hx), my = (int) Math.round(hy + rr * 0.32);
                ctx.fill(mx - ei, my, mx + ei, my + Math.max(2, ei), eye);
            }

            // little wisps spiraling up
            for (int j = 0; j < 5; j++) {
                double ang = t * 8.0 + j * 1.256;
                double rad = 0.5 * sc * (0.6 + 0.4 * t);
                double wy = cy + (j * 0.3 - 0.5) * sc + e * 0.5;
                if (!Proj.project(s.x + Math.cos(ang) * rad, wy, s.z + Math.sin(ang) * rad, PT)) continue;
                double rr = Proj.pxRadius(0.05 * sc);
                Proj.disc(ctx, PT[0], PT[1], rr * 2.0, ac(alpha * 0.2, body));
                Proj.disc(ctx, PT[0], PT[1], rr, ac(alpha * 0.8, core));
            }
        }
    }

    // =============================================================== render
    public static void render(DrawContext ctx, MinecraftClient mc, Config c, float td) {
        boolean rings = c.jumpCircle && ringCount > 0;
        boolean trail = c.trail && c.trailMode != 2 && trailN > 1;
        boolean bolts = !BOLTS.isEmpty();
        boolean spirits = !SPIRITS.isEmpty();
        boolean esp = c.esp && espEnt != null;
        if (!rings && !trail && !bolts && !spirits && !esp) return;
        if (mc.currentScreen != null) return;
        if (!Proj.ensure(mc, td)) return;

        long now = System.currentTimeMillis();
        float sf = (float) mc.getWindow().getScaleFactor();
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(1f / sf, 1f / sf);
        if (rings) renderRings(ctx, c, now);
        if (trail) renderTrail(ctx, mc, c, td, now);
        if (esp) renderEsp(ctx, mc, c, td, now);
        if (spirits) renderSpirits(ctx, c, now);
        if (bolts) renderBolts(ctx, c, now);
        ctx.getMatrices().popMatrix();
    }
}
