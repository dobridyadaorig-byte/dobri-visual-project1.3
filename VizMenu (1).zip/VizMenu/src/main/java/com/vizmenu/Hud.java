package com.vizmenu;

import com.vizmenu.ui.Ui;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class Hud {
    private static final Map<String, Integer> MAXD = new HashMap<>();
    private static final String[] ROMAN = {"", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};

    private Hud() {}

    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        Config c = Config.I;
        if (c.handGlow) handGlow(ctx, mc, c);
        if (c.potionHud) potions(ctx, mc, c);
        if (c.armorHud) armor(ctx, mc, c);
    }

    private static void disc(DrawContext ctx, int cx, int cy, int r, int argb) {
        for (int dy = -r; dy < r; dy += 2) {
            int hw = (int) Math.sqrt((double) r * r - (double) dy * dy);
            ctx.fill(cx - hw, cy + dy, cx + hw, cy + dy + 2, argb);
        }
    }

    private static void handGlow(DrawContext ctx, MinecraftClient mc, Config c) {
        if (!mc.options.getPerspective().isFirstPerson()) return;
        if (c.glowOnlyItem && mc.player.getMainHandStack().isEmpty()) return;
        int sw = ctx.getScaledWindowWidth();
        int sh = ctx.getScaledWindowHeight();
        boolean right = mc.options.getMainArm().getValue() == Arm.RIGHT;
        int cx = Math.round(sw * (right ? 0.74f : 0.26f));
        int cy = Math.round(sh * 0.90f);
        int rgb = c.glowRgb();
        double pulse = 0.88 + 0.12 * Math.sin(System.currentTimeMillis() / 350.0);
        int layers = 8;
        int a = (int) Math.min(255, Math.round(c.glowIntensity * pulse * 30.0));
        int big = (int) (sh * 0.20 * c.glowSize);
        int col = (a << 24) | rgb;
        for (int i = 0; i < layers; i++) {
            int r = big * (layers - i) / layers;
            if (r > 1) disc(ctx, cx, cy, r, col);
        }
    }

    private static String time(int ticks) {
        int s = Math.max(0, ticks / 20);
        return (s / 60) + ":" + (s % 60 < 10 ? "0" : "") + (s % 60);
    }

    private static void potions(DrawContext ctx, MinecraftClient mc, Config c) {
        List<StatusEffectInstance> list = new ArrayList<>();
        for (StatusEffectInstance e : mc.player.getStatusEffects()) {
            if (e.shouldShowIcon()) list.add(e);
        }
        if (list.isEmpty()) {
            MAXD.clear();
            return;
        }
        TextRenderer f = mc.textRenderer;
        boolean det = c.potionStyle == 0;
        int rowW = det ? 116 : 100;
        int rowH = det ? 26 : 15;
        int gap = 3;
        int totalH = list.size() * (rowH + gap) - gap;
        float s = (float) c.potionScale;
        int sw = ctx.getScaledWindowWidth();
        int sh = ctx.getScaledWindowHeight();
        int x = Math.round((sw - rowW * s) * (float) (c.potionX / 100.0));
        int y = Math.round((sh - totalH * s) * (float) (c.potionY / 100.0));

        Set<String> alive = new HashSet<>();
        boolean blink = (System.currentTimeMillis() / 250L) % 2L == 0L;

        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate((float) x, (float) y);
        ctx.getMatrices().scale(s, s);

        int i = 0;
        for (StatusEffectInstance e : list) {
            int ry = i * (rowH + gap);
            i++;
            String key = e.getEffectType().getIdAsString();
            alive.add(key);
            int dur = e.getDuration();
            int max = Math.max(MAXD.getOrDefault(key, 0), dur);
            MAXD.put(key, max);
            float frac = e.isInfinite() ? 1f : Math.min(1f, dur / (float) Math.max(1, max));

            int col = 0xFF000000 | (e.getEffectType().value().getColor() & 0xFFFFFF);
            Ui.rrect(ctx, 0, ry, rowW, rowH, 0xC0121316);
            ctx.fill(1, ry + 3, 3, ry + rowH - 3, col);

            int amp = e.getAmplifier();
            String name = e.getEffectType().value().getName().getString()
                    + (amp > 0 ? " " + ROMAN[Math.min(amp, ROMAN.length - 1)] : "");
            String t = e.isInfinite() ? "\u221E" : time(dur);
            boolean low = !e.isInfinite() && dur < 200;
            int tcol = low ? ((dur < 100 && !blink) ? 0xFF7A2E2E : 0xFFFF5555) : 0xFFB4B4C0;

            ctx.drawText(f, name, 8, ry + 3, 0xFFFFFFFF, true);
            if (det) {
                ctx.drawText(f, t, 8, ry + 13, tcol, false);
                if (c.potionBars) {
                    ctx.fill(8, ry + rowH - 4, rowW - 6, ry + rowH - 2, 0xFF2A2B33);
                    ctx.fill(8, ry + rowH - 4, 8 + Math.round((rowW - 14) * frac), ry + rowH - 2, col);
                }
            } else {
                ctx.drawText(f, t, rowW - 6 - f.getWidth(t), ry + 3, tcol, false);
                if (c.potionBars) {
                    ctx.fill(3, ry + rowH - 2, 3 + Math.round((rowW - 6) * frac), ry + rowH - 1, col);
                }
            }
        }
        ctx.getMatrices().popMatrix();
        MAXD.keySet().retainAll(alive);
    }

    private static void armor(DrawContext ctx, MinecraftClient mc, Config c) {
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        List<ItemStack> st = new ArrayList<>();
        for (EquipmentSlot sl : slots) {
            ItemStack is = mc.player.getEquippedStack(sl);
            if (!is.isEmpty()) st.add(is);
        }
        if (st.isEmpty()) return;

        TextRenderer f = mc.textRenderer;
        boolean vert = c.armorVertical;
        boolean text = c.armorDurability != 0;
        int n = st.size();
        int gap = 3;
        int cw = vert ? 20 + (text ? 34 : 0) : (text ? 30 : 20);
        int ch = vert ? 20 : 20 + (text ? 11 : 0);
        int totalW = vert ? cw : n * cw + (n - 1) * gap;
        int totalH = vert ? n * ch + (n - 1) * gap : ch;

        float s = (float) c.armorScale;
        int sw = ctx.getScaledWindowWidth();
        int sh = ctx.getScaledWindowHeight();
        int x = Math.round((sw - totalW * s) * (float) (c.armorX / 100.0));
        int y = Math.round((sh - totalH * s) * (float) (c.armorY / 100.0));

        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate((float) x, (float) y);
        ctx.getMatrices().scale(s, s);

        for (int i = 0; i < n; i++) {
            ItemStack is = st.get(i);
            int cx = vert ? 0 : i * (cw + gap);
            int cy = vert ? i * (ch + gap) : 0;
            if (c.armorBg) Ui.rrect(ctx, cx, cy, cw, ch, 0xA0121316);
            int ix = vert ? cx + 2 : cx + (cw - 16) / 2;
            ctx.drawItem(is, ix, cy + 2);

            if (text && is.isDamageable()) {
                int max = is.getMaxDamage();
                int left = max - is.getDamage();
                String t = c.armorDurability == 2
                        ? Math.round(left * 100f / Math.max(1, max)) + "%"
                        : String.valueOf(left);
                int col = 0xFF000000 | (is.getItemBarColor() & 0xFFFFFF);
                if (vert) {
                    ctx.drawText(f, t, cx + 24, cy + 6, col, true);
                } else {
                    ctx.drawText(f, t, cx + (cw - f.getWidth(t)) / 2, cy + 21, col, true);
                }
            }
        }
        ctx.getMatrices().popMatrix();
    }
}
