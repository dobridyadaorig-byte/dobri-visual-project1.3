package com.vizmenu;

import com.vizmenu.ui.MenuScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.HitResult;
import org.lwjgl.glfw.GLFW;

public class VizMenuClient implements ClientModInitializer {
    public static KeyBinding OPEN;
    private boolean rmbWas = false;
    private boolean nvAdded = false;

    @Override
    public void onInitializeClient() {
        Config.load();

        OPEN = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.vizmenu.open",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyBinding.Category.create(Identifier.of("vizmenu", "main"))
        ));

        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
        HudElementRegistry.addLast(Identifier.of("vizmenu", "hud"), (ctx, tc) -> Hud.render(ctx));
    }

    private void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        if (p == null || w == null) {
            rmbWas = false;
            nvAdded = false;
            return;
        }

        // Open menu: keybind (Right Shift) ...
        while (OPEN.wasPressed()) {
            if (mc.currentScreen == null) mc.setScreen(new MenuScreen());
        }
        // ... or right click with empty hands on empty air
        boolean rmb = mc.options.useKey.isPressed();
        if (rmb && !rmbWas && mc.currentScreen == null && Config.I.openOnRightClick) {
            HitResult h = mc.crosshairTarget;
            boolean air = h == null || h.getType() == HitResult.Type.MISS;
            if (air && p.getMainHandStack().isEmpty() && p.getOffHandStack().isEmpty()) {
                mc.setScreen(new MenuScreen());
            }
        }
        rmbWas = rmb;

        Config c = Config.I;

        // Fullbright (client-side night vision, no particles / icon)
        StatusEffectInstance nv = p.getStatusEffect(StatusEffects.NIGHT_VISION);
        if (c.fullbright) {
            if (nv == null) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1_000_000, 0, false, false, false));
                nvAdded = true;
            }
        } else if (nvAdded) {
            if (nv != null && !nv.shouldShowIcon()) p.removeStatusEffect(StatusEffects.NIGHT_VISION);
            nvAdded = false;
        }

        // Weather control (client-side)
        switch (c.weatherMode) {
            case 1 -> { w.setRainGradient(0f); w.setThunderGradient(0f); }
            case 2 -> { w.setRainGradient(1f); w.setThunderGradient(0f); }
            case 3 -> { w.setRainGradient(1f); w.setThunderGradient(1f); }
            default -> { }
        }
    }
}
