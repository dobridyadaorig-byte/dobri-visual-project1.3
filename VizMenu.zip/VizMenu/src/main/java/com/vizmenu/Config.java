package com.vizmenu;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.util.math.MathHelper;

import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;

public class Config {
    public static Config I = new Config();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    // Menu
    public boolean openOnRightClick = true;

    // Fullbright
    public boolean fullbright = false;

    // Weather / Time (0 = server, 1.. = override)
    public int weatherMode = 0; // 0 server, 1 clear, 2 rain, 3 thunder
    public int timeMode = 0;    // 0 server, 1 fixed
    public int timeValue = 6000;

    // Potion visuals
    public boolean potionHud = true;
    public boolean potionHideVanilla = true;
    public int potionStyle = 0; // 0 detailed, 1 compact
    public boolean potionBars = true;
    public double potionX = 100;
    public double potionY = 4;
    public double potionScale = 1.0;

    // Armor status
    public boolean armorHud = true;
    public boolean armorVertical = true;
    public int armorDurability = 1; // 0 off, 1 number, 2 percent
    public boolean armorBg = true;
    public double armorX = 1;
    public double armorY = 40;
    public double armorScale = 1.0;

    // Block overlay
    public boolean blockOverlay = false;
    public boolean blockRainbow = false;
    public double blockHue = 270;
    public double blockAlpha = 0.9;

    // Aspect ratio
    public boolean aspectOn = false;
    public double aspect = 16.0 / 9.0;

    public int outlineColor() {
        float h = blockRainbow ? (System.currentTimeMillis() % 4000L) / 4000f : (float) (blockHue / 360.0);
        int rgb = MathHelper.hsvToRgb(h, 0.85f, 1.0f) & 0xFFFFFF;
        int a = Math.round((float) blockAlpha * 255f);
        return (a << 24) | rgb;
    }

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("vizmenu.json");
    }

    public static void load() {
        try {
            Path p = path();
            if (Files.exists(p)) {
                try (Reader r = Files.newBufferedReader(p)) {
                    Config c = GSON.fromJson(r, Config.class);
                    if (c != null) I = c;
                }
            }
        } catch (Exception ignored) {
        }
    }

    public static void save() {
        try {
            Files.writeString(path(), GSON.toJson(I));
        } catch (Exception ignored) {
        }
    }
}
