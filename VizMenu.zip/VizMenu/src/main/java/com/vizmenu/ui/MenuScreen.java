package com.vizmenu.ui;

import com.vizmenu.Config;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleFunction;
import java.util.function.DoubleSupplier;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.function.Consumer;

public class MenuScreen extends Screen {
    static final int PW = 420, PH = 262, SIDE = 112;
    static final int C_BORDER = 0xFF2B2C35, C_PANEL = 0xFF15161A, C_SIDE = 0xFF101114;
    static final int C_ROW = 0xFF1E1F26, C_ROWH = 0xFF272832, C_ACC = 0xFF8B5CF6;
    static final int C_TXT = 0xFFE9E9F0, C_DIM = 0xFF8B8C98, C_OFF = 0xFF3A3B46;

    private static final String[] TABS = {
            "Fullbright", "Weather & Time", "Potions", "Armor", "Block overlay", "Aspect ratio", "Menu"
    };
    private static int lastTab = 0;

    private int tab = lastTab;
    private final List<Row> rows = new ArrayList<>();
    private Row dragging;
    private int scroll = 0;
    private int contentH = 0;

    public MenuScreen() {
        super(Text.literal("Viz Menu"));
    }

    @Override
    protected void init() {
        build();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void removed() {
        Config.save();
    }

    private int px() { return (width - PW) / 2; }
    private int py() { return (height - PH) / 2; }

    // ---------------------------------------------------------------- tabs
    private void build() {
        rows.clear();
        scroll = 0;
        Config c = Config.I;
        switch (tab) {
            case 0 -> {
                rows.add(new Toggle("Fullbright", () -> c.fullbright, v -> c.fullbright = v));
                rows.add(new Label("Maximum brightness everywhere, caves included."));
            }
            case 1 -> {
                rows.add(new Cycle("Weather", new String[]{"Server", "Clear", "Rain", "Thunder"},
                        () -> c.weatherMode, v -> c.weatherMode = v));
                rows.add(new Cycle("Time", new String[]{"Server", "Fixed"},
                        () -> c.timeMode, v -> c.timeMode = v));
                rows.add(new Slider("Time of day", 0, 24000, 100, () -> c.timeValue,
                        v -> { c.timeValue = (int) v; c.timeMode = 1; },
                        v -> clock((int) v), null));
                int[] presets = {23000, 1000, 6000, 12000, 13000, 18000};
                rows.add(new Buttons(new String[]{"Dawn", "Day", "Noon", "Dusk", "Night", "Mid."}, i -> {
                    c.timeValue = presets[i];
                    c.timeMode = 1;
                }));
                rows.add(new Label("Client-side only: other players are unaffected."));
            }
            case 2 -> {
                rows.add(new Toggle("Potion HUD", () -> c.potionHud, v -> c.potionHud = v));
                rows.add(new Toggle("Hide vanilla effects", () -> c.potionHideVanilla, v -> c.potionHideVanilla = v));
                rows.add(new Cycle("Style", new String[]{"Detailed", "Compact"},
                        () -> c.potionStyle, v -> c.potionStyle = v));
                rows.add(new Toggle("Timer bars", () -> c.potionBars, v -> c.potionBars = v));
                rows.add(new Slider("Position X", 0, 100, 1, () -> c.potionX, v -> c.potionX = v, v -> (int) v + "%", null));
                rows.add(new Slider("Position Y", 0, 100, 1, () -> c.potionY, v -> c.potionY = v, v -> (int) v + "%", null));
                rows.add(new Slider("Scale", 0.5, 2.0, 0.05, () -> c.potionScale, v -> c.potionScale = v, v -> f2(v) + "x", null));
            }
            case 3 -> {
                rows.add(new Toggle("Armor status", () -> c.armorHud, v -> c.armorHud = v));
                rows.add(new Cycle("Layout", new String[]{"Vertical", "Horizontal"},
                        () -> c.armorVertical ? 0 : 1, v -> c.armorVertical = (v == 0)));
                rows.add(new Cycle("Durability", new String[]{"Off", "Number", "Percent"},
                        () -> c.armorDurability, v -> c.armorDurability = v));
                rows.add(new Toggle("Background", () -> c.armorBg, v -> c.armorBg = v));
                rows.add(new Slider("Position X", 0, 100, 1, () -> c.armorX, v -> c.armorX = v, v -> (int) v + "%", null));
                rows.add(new Slider("Position Y", 0, 100, 1, () -> c.armorY, v -> c.armorY = v, v -> (int) v + "%", null));
                rows.add(new Slider("Scale", 0.5, 2.0, 0.05, () -> c.armorScale, v -> c.armorScale = v, v -> f2(v) + "x", null));
            }
            case 4 -> {
                rows.add(new Toggle("Block overlay", () -> c.blockOverlay, v -> c.blockOverlay = v));
                rows.add(new Toggle("Rainbow", () -> c.blockRainbow, v -> c.blockRainbow = v));
                rows.add(new Slider("Color (hue)", 0, 360, 1, () -> c.blockHue, v -> c.blockHue = v,
                        v -> (int) v + "\u00B0",
                        () -> 0xFF000000 | (MathHelper.hsvToRgb((float) (c.blockHue / 360.0), 0.85f, 1f) & 0xFFFFFF)));
                rows.add(new Slider("Opacity", 0.1, 1.0, 0.05, () -> c.blockAlpha, v -> c.blockAlpha = v,
                        v -> Math.round(v * 100) + "%", null));
                rows.add(new Label("Recolors the outline of the targeted block."));
            }
            case 5 -> {
                rows.add(new Toggle("Custom aspect ratio", () -> c.aspectOn, v -> c.aspectOn = v));
                rows.add(new Slider("Ratio", 0.5, 4.0, 0.01, () -> c.aspect,
                        v -> { c.aspect = v; c.aspectOn = true; }, v -> f2(v), null));
                double[] pr = {16.0 / 9.0, 16.0 / 10.0, 4.0 / 3.0, 21.0 / 9.0, 1.0, 32.0 / 9.0};
                rows.add(new Buttons(new String[]{"16:9", "16:10", "4:3", "21:9", "1:1", "32:9"}, i -> {
                    c.aspect = pr[i];
                    c.aspectOn = true;
                }));
                rows.add(new Buttons(new String[]{"-0.05", "+0.05", "Reset"}, i -> {
                    if (i == 0) c.aspect = Math.max(0.5, c.aspect - 0.05);
                    if (i == 1) c.aspect = Math.min(4.0, c.aspect + 0.05);
                    if (i == 2) { c.aspect = 16.0 / 9.0; c.aspectOn = false; }
                    if (i != 2) c.aspectOn = true;
                }));
                rows.add(new Label("Changes the world view only, HUD stays native."));
            }
            default -> {
                rows.add(new Toggle("Open on right click", () -> c.openOnRightClick, v -> c.openOnRightClick = v));
                rows.add(new Label("Right click with empty hands on empty air."));
                rows.add(new Label("Key: Right Shift (change it in Controls)."));
            }
        }
    }

    private static String f2(double v) {
        return String.format("%.2f", v);
    }

    private static String clock(int ticks) {
        int mins = (int) ((((ticks / 1000.0) + 6.0) % 24.0) * 60.0);
        return String.format("%02d:%02d", mins / 60, mins % 60);
    }

    // ---------------------------------------------------------------- render
    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        c.fill(0, 0, width, height, 0x55000000);
        int px = px(), py = py();
        Ui.rrect(c, px - 1, py - 1, PW + 2, PH + 2, C_BORDER);
        Ui.rrect(c, px, py, PW, PH, C_PANEL);
        Ui.rrect(c, px, py, SIDE, PH, C_SIDE);

        c.drawText(textRenderer, "viz menu", px + 14, py + 14, C_ACC, false);

        for (int i = 0; i < TABS.length; i++) {
            int ty = py + 36 + i * 24;
            boolean sel = i == tab;
            boolean hov = mx >= px + 6 && mx < px + SIDE - 6 && my >= ty && my < ty + 20;
            if (sel) {
                Ui.rrect(c, px + 6, ty, SIDE - 12, 20, C_ROW);
                c.fill(px + 6, ty + 4, px + 8, ty + 16, C_ACC);
            } else if (hov) {
                Ui.rrect(c, px + 6, ty, SIDE - 12, 20, C_ROWH);
            }
            c.drawText(textRenderer, TABS[i], px + 16, ty + 6, sel ? C_TXT : C_DIM, false);
        }

        int cx = px + SIDE + 14, cy = py + 14, cw = PW - SIDE - 28, ch = PH - 28;
        boolean mouseInClip = my >= cy && my < cy + ch;
        c.enableScissor(cx - 2, cy, cx + cw + 2, cy + ch);
        int y = cy - scroll;
        for (Row r : rows) {
            r.x = cx;
            r.y = y;
            r.w = cw;
            r.draw(c, textRenderer, mouseInClip ? mx : -1000, mouseInClip ? my : -1000);
            y += r.h + 6;
        }
        contentH = y + scroll - cy;
        c.disableScissor();

        if (contentH > ch) {
            int bh = Math.max(20, ch * ch / contentH);
            int by = cy + (ch - bh) * scroll / Math.max(1, contentH - ch);
            c.fill(px + PW - 6, by, px + PW - 4, by + bh, C_OFF);
        }
    }

    // ---------------------------------------------------------------- input
    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y();
        int btn = click.button();
        int px = px(), py = py();

        if (mx < px || mx > px + PW || my < py || my > py + PH) {
            close();
            return true;
        }
        for (int i = 0; i < TABS.length; i++) {
            int ty = py + 36 + i * 24;
            if (mx >= px + 6 && mx < px + SIDE - 6 && my >= ty && my < ty + 20) {
                tab = i;
                lastTab = i;
                build();
                return true;
            }
        }
        int cy = py + 14, ch = PH - 28;
        if (my >= cy && my < cy + ch) {
            for (Row r : rows) {
                if (r.hit(mx, my) && r.click(mx, my, btn)) {
                    dragging = r;
                    return true;
                }
            }
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        if (dragging != null) {
            dragging.drag(click.x());
            return true;
        }
        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        dragging = null;
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int max = Math.max(0, contentH - (PH - 28));
        scroll = MathHelper.clamp(scroll - (int) (verticalAmount * 14), 0, max);
        return true;
    }

    // ---------------------------------------------------------------- rows
    abstract static class Row {
        int x, y, w;
        final int h;

        Row(int h) { this.h = h; }

        abstract void draw(DrawContext c, TextRenderer f, int mx, int my);

        boolean click(double mx, double my, int btn) { return false; }

        void drag(double mx) { }

        boolean hit(double mx, double my) {
            return mx >= x && mx < x + w && my >= y && my < y + h;
        }
    }

    static class Label extends Row {
        final String text;

        Label(String text) { super(14); this.text = text; }

        @Override
        void draw(DrawContext c, TextRenderer f, int mx, int my) {
            c.drawText(f, text, x + 2, y + 3, C_DIM, false);
        }
    }

    static class Toggle extends Row {
        final String label;
        final BooleanSupplier get;
        final Consumer<Boolean> set;

        Toggle(String label, BooleanSupplier get, Consumer<Boolean> set) {
            super(26);
            this.label = label; this.get = get; this.set = set;
        }

        @Override
        void draw(DrawContext c, TextRenderer f, int mx, int my) {
            Ui.rrect(c, x, y, w, h, hit(mx, my) ? C_ROWH : C_ROW);
            c.drawText(f, label, x + 10, y + (h - 8) / 2, C_TXT, false);
            boolean on = get.getAsBoolean();
            int tx = x + w - 38, ty = y + (h - 12) / 2;
            Ui.rrect(c, tx, ty, 28, 12, on ? C_ACC : C_OFF);
            int kx = on ? tx + 17 : tx + 1;
            c.fill(kx, ty + 1, kx + 10, ty + 11, 0xFFFFFFFF);
        }

        @Override
        boolean click(double mx, double my, int btn) {
            if (btn != 0) return false;
            set.accept(!get.getAsBoolean());
            return true;
        }
    }

    static class Cycle extends Row {
        final String label;
        final String[] opts;
        final IntSupplier get;
        final IntConsumer set;

        Cycle(String label, String[] opts, IntSupplier get, IntConsumer set) {
            super(26);
            this.label = label; this.opts = opts; this.get = get; this.set = set;
        }

        @Override
        void draw(DrawContext c, TextRenderer f, int mx, int my) {
            Ui.rrect(c, x, y, w, h, hit(mx, my) ? C_ROWH : C_ROW);
            c.drawText(f, label, x + 10, y + (h - 8) / 2, C_TXT, false);
            String t = opts[MathHelper.clamp(get.getAsInt(), 0, opts.length - 1)];
            int pw = Math.max(64, f.getWidth(t) + 20);
            int bx = x + w - pw - 8;
            Ui.rrect(c, bx, y + 4, pw, h - 8, C_OFF);
            c.drawText(f, t, bx + (pw - f.getWidth(t)) / 2, y + (h - 8) / 2, C_ACC, false);
        }

        @Override
        boolean click(double mx, double my, int btn) {
            int n = opts.length;
            int cur = get.getAsInt();
            if (btn == 0) set.accept((cur + 1) % n);
            else if (btn == 1) set.accept((cur + n - 1) % n);
            else return false;
            return true;
        }
    }

    static class Buttons extends Row {
        final String[] labels;
        final IntConsumer action;

        Buttons(String[] labels, IntConsumer action) {
            super(24);
            this.labels = labels; this.action = action;
        }

        private int bw() { return (w - (labels.length - 1) * 4) / labels.length; }

        @Override
        void draw(DrawContext c, TextRenderer f, int mx, int my) {
            int bw = bw();
            for (int i = 0; i < labels.length; i++) {
                int bx = x + i * (bw + 4);
                boolean hov = mx >= bx && mx < bx + bw && my >= y && my < y + h;
                Ui.rrect(c, bx, y, bw, h, hov ? C_ACC : C_OFF);
                c.drawText(f, labels[i], bx + (bw - f.getWidth(labels[i])) / 2, y + (h - 8) / 2, C_TXT, false);
            }
        }

        @Override
        boolean click(double mx, double my, int btn) {
            if (btn != 0) return false;
            int bw = bw();
            for (int i = 0; i < labels.length; i++) {
                int bx = x + i * (bw + 4);
                if (mx >= bx && mx < bx + bw) {
                    action.accept(i);
                    return true;
                }
            }
            return false;
        }
    }

    static class Slider extends Row {
        final String label;
        final double min, max, step;
        final DoubleSupplier get;
        final DoubleConsumer set;
        final DoubleFunction<String> fmt;
        final IntSupplier knob;

        Slider(String label, double min, double max, double step, DoubleSupplier get,
               DoubleConsumer set, DoubleFunction<String> fmt, IntSupplier knob) {
            super(34);
            this.label = label; this.min = min; this.max = max; this.step = step;
            this.get = get; this.set = set; this.fmt = fmt; this.knob = knob;
        }

        @Override
        void draw(DrawContext c, TextRenderer f, int mx, int my) {
            Ui.rrect(c, x, y, w, h, hit(mx, my) ? C_ROWH : C_ROW);
            double v = get.getAsDouble();
            String vs = fmt.apply(v);
            c.drawText(f, label, x + 10, y + 6, C_TXT, false);
            c.drawText(f, vs, x + w - 10 - f.getWidth(vs), y + 6, C_DIM, false);
            int tx = x + 10, tw = w - 20, ty = y + 22;
            double t = MathHelper.clamp((v - min) / (max - min), 0, 1);
            c.fill(tx, ty, tx + tw, ty + 4, C_OFF);
            int fw = (int) Math.round(tw * t);
            c.fill(tx, ty, tx + fw, ty + 4, C_ACC);
            int kc = knob != null ? knob.getAsInt() : 0xFFFFFFFF;
            c.fill(tx + fw - 3, ty - 3, tx + fw + 3, ty + 7, 0xFFFFFFFF);
            c.fill(tx + fw - 2, ty - 2, tx + fw + 2, ty + 6, kc);
        }

        @Override
        boolean click(double mx, double my, int btn) {
            if (btn != 0) return false;
            drag(mx);
            return true;
        }

        @Override
        void drag(double mx) {
            double t = MathHelper.clamp((mx - (x + 10)) / (double) (w - 20), 0, 1);
            double v = min + t * (max - min);
            v = Math.round(v / step) * step;
            v = MathHelper.clamp(v, min, max);
            set.accept(v);
        }
    }
}
