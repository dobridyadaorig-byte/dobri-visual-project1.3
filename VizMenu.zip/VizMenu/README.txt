VIZ MENU — клиентский Fabric-мод для Minecraft Java 1.21.11

Меню: ПКМ пустой рукой по воздуху ИЛИ Right Shift (клавишу можно сменить в Управлении).
Вкладки: Fullbright, Weather & Time, Potions, Armor, Block overlay, Aspect ratio, Menu.
Настройки сохраняются в config/vizmenu.json.

КАК ПОЛУЧИТЬ .JAR (GitHub)
1. Загрузи ВСЁ содержимое этой папки в репозиторий (src, build.gradle, gradle.properties,
   settings.gradle и папку .github с build.yml).
2. Вкладка Actions -> запустится сборка "build" (или Run workflow).
3. Когда станет зелёной — открой её, внизу Artifacts -> VizMenu-jar -> скачай.
4. Внутри архива vizmenu-1.0.0.jar положи в папку mods вместе с Fabric API.

Нужно: Fabric Loader + Fabric API для 1.21.11, Java 21.
