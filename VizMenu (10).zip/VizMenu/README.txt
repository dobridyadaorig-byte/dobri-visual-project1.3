DobriVisual (проект VizMenu) — клиентский Fabric-мод для Minecraft Java 1.21.11

ОТКРЫТЬ МЕНЮ: ПКМ пустой рукой по воздуху ИЛИ Right Shift (меняется в Управлении).

В МЕНЮ
- Сверху разделы: HUD, Combat, Movement, Player, Misc.
- ЛКМ по функции — включить/выключить.
- ПКМ по функции — открыть её настройки (кнопка "< Back" возвращает назад).
- Колёсико мыши по функции — бинд: потом нажми клавишу. Esc — отмена, Del/Backspace — убрать бинд.
- Забинженная клавиша включает/выключает функцию в игре (сообщение в экшн-баре).

ФУНКЦИИ
HUD: FPS, Coordinates, Armor status, Potion visuals
Combat: CPS counter, Target info
Movement: Auto sprint, Predictive trail
Player: Fullbright, Block overlay
Misc: Weather control, Time changer, Aspect ratio, Open on right click

Настройки и бинды: config/vizmenu.json

ПОЛУЧИТЬ .JAR: положи VizMenu.zip в корень репозитория, workflow в .github/workflows соберёт мод.
Скачать jar: Actions -> последний запуск -> внизу Artifacts -> VizMenu-jar.

ШРИФТ
Во всей игре (меню, чат, HUD) вместо пиксельного шрифта используется Carlito (лицензия SIL OFL, файл LICENSE-Carlito.txt).
Настройки шрифта лежат в src/main/resources/assets/minecraft/font/default.json (size, shift).

ОПИСАНИЕ ФУНКЦИЙ
При наведении на функцию в меню её краткое описание показывается сверху, справа от названия DobriVisual.

НОВОЕ (v1.1.0)
- HUD -> Watermark: аккуратный водяной знак DobriVisual слева сверху (градиент, версия).
- Misc -> Custom main menu: свой экран главного меню с большим часами по центру
  (круглые цифры со скруглёнными краями, нарисованы модом, не шрифтом Minecraft).
  Настройки (ПКМ): 24-часовой формат, секунды, дата, цвет часов.
- Версия мода показана в меню (справа вверху) и на главном меню (внизу слева).
- Шрифт Carlito: assets/minecraft/font/default.json (см. раздел CAXTON)


CAXTON (чёткий векторный шрифт)
Мод интегрирован с Caxton: в default.json есть блок caxton_providers с шрифтом Carlito (обычный, жирный, курсив, жирный курсив).
- Если Caxton установлен — текст рисуется векторно (MSDF), чётко при любом масштабе, настоящий жирный и курсив.
- Если Caxton не установлен — используется обычный TTF Minecraft (тот же Carlito), ничего не ломается.
Скачай Caxton для Fabric 1.21.11 (Modrinth: Caxton, версия 0.9.0-beta.3+1.21.11-FABRIC) и положи jar в mods рядом с vizmenu.
Файлы шрифта для Caxton: assets/vizmenu/textures/font/


НОВОЕ (v1.2.0)
HUD: Custom crosshair (свой прицел)
Combat: Kill effect (цель рассыпается на частицы после убийства)
Movement: Predictive trail (светящаяся лента/точки, режим частиц остался), Jump circle (кольцо на земле при прыжке, рисуется модом, не частицами)
Player: Custom hand (положение/размер руки), Freelook (клавиша Left Alt, меняется в Управлении), Freecam (WASD, Пробел/Shift)
Misc: Misty (туман: дымка у горизонта и плывущие облака)
Описания функций в меню теперь на русском.
