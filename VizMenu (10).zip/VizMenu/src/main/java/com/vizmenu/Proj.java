package com.vizmenu;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.render.Camera;
import net.minecraft.util.math.Vec3d;

/** Projects world positions onto the screen so 3D-looking effects can be drawn on the HUD layer. */
public final class Proj {
    /** Real field of view (degrees) captured from the game renderer, or -1 if unknown. */
    public static float lastFov = -1f;

    public static int fbw, fbh;
    private static double cx, cy, cz;
    private static double fx, fy, fz, rx, ry, rz, ux, uy, uz;
    private static double tanHalf, aspect;

    private Proj() {}

    public static boolean setup(MinecraftClient mc, float td) {
        if (mc.player == null || mc.world == null) return false;
        if (mc.options.getPerspective() == Perspective.THIRD_PERSON_FRONT) return false;
        Camera cam = mc.gameRenderer.getCamera();
        Vec3d pos = cam.getCameraPos();
        cx = pos.x;
        cy = pos.y;
        cz = pos.z;

        float yaw = CameraControl.yaw(mc.player.getYaw(td));
        float pitch = CameraControl.pitch(mc.player.getPitch(td));
        double yr = Math.toRadians(yaw), pr = Math.toRadians(pitch);
        fx = -Math.sin(yr) * Math.cos(pr);
        fy = -Math.sin(pr);
        fz = Math.cos(yr) * Math.cos(pr);
        rx = -Math.cos(yr);
        ry = 0.0;
        rz = -Math.sin(yr);
        ux = ry * fz - rz * fy;
        uy = rz * fx - rx * fz;
        uz = rx * fy - ry * fx;

        double fov = lastFov > 1f ? lastFov : mc.options.getFov().getValue();
        tanHalf = Math.tan(Math.toRadians(fov) / 2.0);
        fbw = mc.getWindow().getFramebufferWidth();
        fbh = mc.getWindow().getFramebufferHeight();
        aspect = Config.I.aspectOn ? Config.I.aspect : fbw / (double) Math.max(1, fbh);
        return true;
    }

    public static float fovDegrees(MinecraftClient mc) {
        return lastFov > 1f ? lastFov : (float) mc.options.getFov().getValue();
    }

    /** Output in framebuffer pixels. Returns false when the point is behind the camera. */
    public static boolean project(double x, double y, double z, double[] out) {
        double dx = x - cx, dy = y - cy, dz = z - cz;
        double zc = dx * fx + dy * fy + dz * fz;
        if (zc < 0.05) return false;
        double xc = dx * rx + dy * ry + dz * rz;
        double yc = dx * ux + dy * uy + dz * uz;
        double nx = xc / (zc * tanHalf * aspect);
        double ny = yc / (zc * tanHalf);
        out[0] = fbw * 0.5 * (1.0 + nx);
        out[1] = fbh * 0.5 * (1.0 - ny);
        return true;
    }

    /** Thick line made of small squares (coordinates in framebuffer pixels). */
    public static void line(DrawContext ctx, double x0, double y0, double x1, double y1, int size, int argb) {
        double dx = x1 - x0, dy = y1 - y0;
        double len = Math.max(Math.abs(dx), Math.abs(dy));
        if (len > 6000.0 || Double.isNaN(len)) return;
        int h = size / 2;
        if (len < 1.0) {
            int x = (int) Math.round(x0), y = (int) Math.round(y0);
            ctx.fill(x - h, y - h, x - h + size, y - h + size, argb);
            return;
        }
        int n = Math.max(1, (int) Math.ceil(len / Math.max(1, size)));
        for (int i = 0; i <= n; i++) {
            double t = i / (double) n;
            int x = (int) Math.round(x0 + dx * t);
            int y = (int) Math.round(y0 + dy * t);
            ctx.fill(x - h, y - h, x - h + size, y - h + size, argb);
        }
    }
}
