package com.vizmenu;

import com.vizmenu.ui.Ui;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** All HUD elements. Strings are cached so almost nothing is allocated per frame. */
public final class Hud {
    private static final String[] ROMAN = {"", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
    private static final EquipmentSlot[] SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };

    private static final String[] LINES = new String[4];
    private static final int[] COLS = new int[4];

    // fps
    private static int fpsLast = -1;
    private static String fpsStr = "";

    // coords cache
    private static long coordKey = Long.MIN_VALUE;
    private static String coordLine = "", otherLine = "", dirLine = "";

    // cps
    private static final long[] CLICKS = new long[128];
    private static int clickHead = 0, clickCount = 0;
    private static boolean mouseWas = false;
    private static int cpsLast = -1;
    private static String cpsStr = "";

    // target
    private static LivingEntity target;
    private static long targetTime;

    // potions
    private static final class Fx {
        String base = "", name = "", time = "";
        int amp = -1, sec = -3, max = 0, frame = 0;
    }
    private static final Map<Object, Fx> FX_CACHE = new HashMap<>();
    private static final List<StatusEffectInstance> FX_LIST = new ArrayList<>();
    private static int frameId = 0;

    // armor
    private static final ItemStack[] ARM = new ItemStack[4];

    private Hud() {}

    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        Config c = Config.I;
        if (c.cps) trackClicks(mc);
        if (c.fps) fps(ctx, mc, c);
        if (c.coords) coords(ctx, mc, c);
        if (c.cps) cps(ctx, mc, c);
        if (c.targetInfo) target(ctx, mc, c);
        if (c.potionHud) potions(ctx, mc, c);
        if (c.armorHud) armor(ctx, mc, c);
    }

    // ------------------------------------------------------------ helpers
    private static void begin(DrawContext ctx, Config.HudBox b, int w, int h) {
        float s = (float) b.scale;
        int sw = ctx.getScaledWindowWidth();
        int sh = ctx.getScaledWindowHeight();
        int x = Math.round((sw - w * s) * (float) (b.x / 100.0));
        int y = Math.round((sh - h * s) * (float) (b.y / 100.0));
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate((float) x, (float) y);
        ctx.getMatrices().scale(s, s);
    }

    private static void end(DrawContext ctx) {
        ctx.getMatrices().popMatrix();
    }

    private static void textBox(DrawContext ctx, TextRenderer f, Config.HudBox b, int n) {
        int w = 0;
        for (int i = 0; i < n; i++) w = Math.max(w, f.getWidth(LINES[i]));
        w += 12;
        int h = n * 11 + 3;
        begin(ctx, b, w, h);
        if (b.bg) {
            Ui.rrect(ctx, 0, 0, w, h, 0xB0121316);
            ctx.fill(0, 2, 2, h - 2, Ui.ACC);
        }
        for (int i = 0; i < n; i++) {
            ctx.drawText(f, LINES[i], 7, 3 + i * 11, COLS[i], true);
        }
        end(ctx);
    }

    private static String time(int ticks) {
        int s = Math.max(0, ticks / 20);
        return (s / 60) + ":" + (s % 60 < 10 ? "0" : "") + (s % 60);
    }

    private static String num(double v, int dec) {
        if (dec == 0) return Integer.toString((int) Math.floor(v));
        long m = dec == 1 ? 10L : 100L;
        long r = Math.round(v * m);
        long a = Math.abs(r);
        long frac = a % m;
        String fs = dec == 2 && frac < 10 ? "0" + frac : Long.toString(frac);
        return (r < 0 ? "-" : "") + (a / m) + "." + fs;
    }

    // ---------------------------------------------------------------- FPS
    private static void fps(DrawContext ctx, MinecraftClient mc, Config c) {
        int fps = mc.getCurrentFps();
        if (fps != fpsLast) {
            fpsLast = fps;
            fpsStr = "FPS  " + fps;
        }
        LINES[0] = fpsStr;
        COLS[0] = fps >= 60 ? 0xFF7CFC9A : (fps >= 30 ? 0xFFFFD866 : 0xFFFF6B6B);
        textBox(ctx, mc.textRenderer, c.fpsBox, 1);
    }

    // ------------------------------------------------------------- coords
    private static void coords(DrawContext ctx, MinecraftClient mc, Config c) {
        double px = mc.player.getX(), py = mc.player.getY(), pz = mc.player.getZ();
        int dec = Math.max(0, Math.min(2, c.coordsDecimals));
        long m = dec == 0 ? 1L : (dec == 1 ? 10L : 100L);
        Direction dir = mc.player.getHorizontalFacing();

        long key = Math.floorDiv((long) Math.floor(px * m), 1L) * 31L
                + (long) Math.floor(py * m) * 131071L
                + (long) Math.floor(pz * m) * 524287L
                + dec * 7L + (c.coordsNether ? 3L : 0L) + (c.coordsDir ? 5L : 0L) + dir.ordinal() * 11L;
        World w = mc.world;
        if (w != null) key += w.getRegistryKey() == World.NETHER ? 17L : (w.getRegistryKey() == World.OVERWORLD ? 19L : 0L);

        if (key != coordKey) {
            coordKey = key;
            coordLine = "XYZ  " + num(px, dec) + "  " + num(py, dec) + "  " + num(pz, dec);
            otherLine = "";
            if (c.coordsNether && w != null) {
                if (w.getRegistryKey() == World.OVERWORLD) {
                    otherLine = "Nether  " + num(px / 8.0, dec) + "  " + num(pz / 8.0, dec);
                } else if (w.getRegistryKey() == World.NETHER) {
                    otherLine = "Overworld  " + num(px * 8.0, dec) + "  " + num(pz * 8.0, dec);
                }
            }
            dirLine = "";
            if (c.coordsDir) {
                switch (dir) {
                    case NORTH -> dirLine = "Facing  N (-Z)";
                    case SOUTH -> dirLine = "Facing  S (+Z)";
                    case EAST -> dirLine = "Facing  E (+X)";
                    case WEST -> dirLine = "Facing  W (-X)";
                    default -> dirLine = "";
                }
            }
        }

        int n = 0;
        LINES[n] = coordLine; COLS[n++] = 0xFFFFFFFF;
        if (!otherLine.isEmpty()) { LINES[n] = otherLine; COLS[n++] = 0xFFFF9F6B; }
        if (!dirLine.isEmpty()) { LINES[n] = dirLine; COLS[n++] = 0xFFB4B4C0; }
        textBox(ctx, mc.textRenderer, c.coordsBox, n);
    }

    // ---------------------------------------------------------------- CPS
    private static void trackClicks(MinecraftClient mc) {
        boolean down = mc.currentScreen == null
                && GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        if (down && !mouseWas) {
            CLICKS[clickHead] = System.currentTimeMillis();
            clickHead = (clickHead + 1) & 127;
            if (clickCount < 128) clickCount++;
        }
        mouseWas = down;
    }

    private static void cps(DrawContext ctx, MinecraftClient mc, Config c) {
        long now = System.currentTimeMillis();
        int n = 0;
        for (int i = 0; i < clickCount; i++) {
            if (now - CLICKS[i] <= 1000L) n++;
        }
        if (n != cpsLast) {
            cpsLast = n;
            cpsStr = "CPS  " + n;
        }
        LINES[0] = cpsStr;
        COLS[0] = 0xFFFFFFFF;
        textBox(ctx, mc.textRenderer, c.cpsBox, 1);
    }

    // ------------------------------------------------------------- target
    private static void target(DrawContext ctx, MinecraftClient mc, Config c) {
        long now = System.currentTimeMillis();
        HitResult h = mc.crosshairTarget;
        if (h instanceof EntityHitResult e && e.getEntity() instanceof LivingEntity le) {
            target = le;
            targetTime = now;
        }
        if (target == null || target.isRemoved() || !target.isAlive() || now - targetTime > 1500L) {
            target = null;
            return;
        }
        TextRenderer f = mc.textRenderer;
        String name = target.getName().getString();
        float hp = target.getHealth();
        float max = Math.max(1f, target.getMaxHealth());
        float frac = Math.max(0f, Math.min(1f, hp / max));
        String hpStr = c.targetNumber ? (Math.round(hp * 10f) / 10f) + " / " + (Math.round(max * 10f) / 10f) : "";

        int w = Math.max(100, f.getWidth(name) + 14);
        int hgt = 12 + 8 + (c.targetNumber ? 11 : 0);
        begin(ctx, c.targetBox, w, hgt);
        if (c.targetBox.bg) {
            Ui.rrect(ctx, 0, 0, w, hgt, 0xB0121316);
            ctx.fill(0, 2, 2, hgt - 2, Ui.ACC);
        }
        ctx.drawText(f, name, 7, 3, 0xFFFFFFFF, true);
        int col = frac > 0.5f ? 0xFF7CFC9A : (frac > 0.25f ? 0xFFFFD866 : 0xFFFF6B6B);
        ctx.fill(7, 14, w - 7, 18, 0xFF2A2B33);
        ctx.fill(7, 14, 7 + Math.round((w - 14) * frac), 18, col);
        if (c.targetNumber) ctx.drawText(f, hpStr, 7, 20, 0xFFB4B4C0, false);
        end(ctx);
    }

    // ------------------------------------------------------------ potions
    private static void potions(DrawContext ctx, MinecraftClient mc, Config c) {
        FX_LIST.clear();
        for (StatusEffectInstance e : mc.player.getStatusEffects()) {
            if (e.shouldShowIcon()) FX_LIST.add(e);
        }
        if (FX_LIST.isEmpty()) {
            FX_CACHE.clear();
            return;
        }
        frameId++;
        TextRenderer f = mc.textRenderer;
        boolean det = c.potionStyle == 0;
        int rowW = det ? 116 : 100;
        int rowH = det ? 26 : 15;
        int gap = 3;
        int count = FX_LIST.size();
        int totalH = count * (rowH + gap) - gap;
        boolean blink = (System.currentTimeMillis() / 250L) % 2L == 0L;

        begin(ctx, c.potionBox, rowW, totalH);
        for (int i = 0; i < count; i++) {
            StatusEffectInstance e = FX_LIST.get(i);
            Object key = e.getEffectType();
            Fx fx = FX_CACHE.get(key);
            if (fx == null) {
                fx = new Fx();
                fx.base = e.getEffectType().value().getName().getString();
                FX_CACHE.put(key, fx);
            }
            fx.frame = frameId;

            int amp = e.getAmplifier();
            if (amp != fx.amp) {
                fx.amp = amp;
                fx.name = fx.base + (amp > 0 ? " " + ROMAN[Math.min(amp, ROMAN.length - 1)] : "");
            }
            int dur = e.getDuration();
            fx.max = Math.max(fx.max, dur);
            int sec = e.isInfinite() ? -2 : dur / 20;
            if (sec != fx.sec) {
                fx.sec = sec;
                fx.time = e.isInfinite() ? "\u221E" : time(dur);
            }
            float frac = e.isInfinite() ? 1f : Math.min(1f, dur / (float) Math.max(1, fx.max));

            int ry = i * (rowH + gap);
            int col = 0xFF000000 | (e.getEffectType().value().getColor() & 0xFFFFFF);
            Ui.rrect(ctx, 0, ry, rowW, rowH, 0xC0121316);
            ctx.fill(1, ry + 3, 3, ry + rowH - 3, col);

            boolean low = !e.isInfinite() && dur < 200;
            int tcol = low ? ((dur < 100 && !blink) ? 0xFF7A2E2E : 0xFFFF5555) : 0xFFB4B4C0;

            ctx.drawText(f, fx.name, 8, ry + 3, 0xFFFFFFFF, true);
            if (det) {
                ctx.drawText(f, fx.time, 8, ry + 13, tcol, false);
                if (c.potionBars) {
                    ctx.fill(8, ry + rowH - 4, rowW - 6, ry + rowH - 2, 0xFF2A2B33);
                    ctx.fill(8, ry + rowH - 4, 8 + Math.round((rowW - 14) * frac), ry + rowH - 2, col);
                }
            } else {
                ctx.drawText(f, fx.time, rowW - 6 - f.getWidth(fx.time), ry + 3, tcol, false);
                if (c.potionBars) {
                    ctx.fill(3, ry + rowH - 2, 3 + Math.round((rowW - 6) * frac), ry + rowH - 1, col);
                }
            }
        }
        end(ctx);
        if (FX_CACHE.size() != count) FX_CACHE.values().removeIf(x -> x.frame != frameId);
    }

    // -------------------------------------------------------------- armor
    private static void armor(DrawContext ctx, MinecraftClient mc, Config c) {
        int n = 0;
        for (EquipmentSlot sl : SLOTS) {
            ItemStack is = mc.player.getEquippedStack(sl);
            if (!is.isEmpty()) ARM[n++] = is;
        }
        if (n == 0) return;

        TextRenderer f = mc.textRenderer;
        boolean vert = c.armorVertical;
        boolean text = c.armorDurability != 0;
        int gap = 3;
        int cw = vert ? 20 + (text ? 34 : 0) : (text ? 30 : 20);
        int ch = vert ? 20 : 20 + (text ? 11 : 0);
        int totalW = vert ? cw : n * cw + (n - 1) * gap;
        int totalH = vert ? n * ch + (n - 1) * gap : ch;

        begin(ctx, c.armorBox, totalW, totalH);
        for (int i = 0; i < n; i++) {
            ItemStack is = ARM[i];
            int cx = vert ? 0 : i * (cw + gap);
            int cy = vert ? i * (ch + gap) : 0;
            if (c.armorBox.bg) Ui.rrect(ctx, cx, cy, cw, ch, 0xA0121316);
            int ix = vert ? cx + 2 : cx + (cw - 16) / 2;
            ctx.drawItem(is, ix, cy + 2);

            if (text && is.isDamageable()) {
                int max = is.getMaxDamage();
                int left = max - is.getDamage();
                String t = c.armorDurability == 2
                        ? Math.round(left * 100f / Math.max(1, max)) + "%"
                        : Integer.toString(left);
                int col = 0xFF000000 | (is.getItemBarColor() & 0xFFFFFF);
                if (vert) {
                    ctx.drawText(f, t, cx + 24, cy + 6, col, true);
                } else {
                    ctx.drawText(f, t, cx + (cw - f.getWidth(t)) / 2, cy + 21, col, true);
                }
            }
        }
        end(ctx);
        for (int i = 0; i < n; i++) ARM[i] = null;
    }
}
