package com.vizmenu.ui;

import net.minecraft.client.gui.DrawContext;

public final class Ui {
    public static final int BORDER = 0xFF2B2C35;
    public static final int PANEL = 0xFF15161A;
    public static final int ROW = 0xFF1E1F26;
    public static final int ROWH = 0xFF272832;
    public static final int ACC = 0xFF8B5CF6;
    public static final int TXT = 0xFFE9E9F0;
    public static final int DIM = 0xFF8B8C98;
    public static final int OFF = 0xFF3A3B46;

    private Ui() {}

    /** Rectangle with softly cut corners. */
    public static void rrect(DrawContext c, int x, int y, int w, int h, int col) {
        if (w <= 2 || h <= 2) {
            c.fill(x, y, x + w, y + h, col);
            return;
        }
        c.fill(x + 1, y, x + w - 1, y + h, col);
        c.fill(x, y + 1, x + 1, y + h - 1, col);
        c.fill(x + w - 1, y + 1, x + w, y + h - 1, col);
    }
}
