package com.vizmenu.ui;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleFunction;
import java.util.function.DoubleSupplier;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

/** Small UI building blocks used on settings pages. */
final class Rows {
    private Rows() {}

    abstract static class Row {
        int x, y, w;
        final int h;

        Row(int h) { this.h = h; }

        abstract void draw(DrawContext c, TextRenderer f, int mx, int my);

        boolean click(double mx, double my, int btn) { return false; }

        void drag(double mx) { }

        boolean hit(double mx, double my) {
            return mx >= x && mx < x + w && my >= y && my < y + h;
        }
    }

    static class Label extends Row {
        final String text;

        Label(String text) { super(14); this.text = text; }

        @Override
        void draw(DrawContext c, TextRenderer f, int mx, int my) {
            c.drawText(f, text, x + 2, y + 3, Ui.DIM, false);
        }
    }

    static class Toggle extends Row {
        final String label;
        final BooleanSupplier get;
        final Consumer<Boolean> set;

        Toggle(String label, BooleanSupplier get, Consumer<Boolean> set) {
            super(24);
            this.label = label; this.get = get; this.set = set;
        }

        @Override
        void draw(DrawContext c, TextRenderer f, int mx, int my) {
            Ui.rrect(c, x, y, w, h, hit(mx, my) ? Ui.ROWH : Ui.ROW);
            c.drawText(f, label, x + 10, y + (h - 8) / 2, Ui.TXT, false);
            boolean on = get.getAsBoolean();
            int tx = x + w - 38, ty = y + (h - 12) / 2;
            Ui.rrect(c, tx, ty, 28, 12, on ? Ui.ACC : Ui.OFF);
            int kx = on ? tx + 17 : tx + 1;
            c.fill(kx, ty + 1, kx + 10, ty + 11, 0xFFFFFFFF);
        }

        @Override
        boolean click(double mx, double my, int btn) {
            if (btn != 0) return false;
            set.accept(!get.getAsBoolean());
            return true;
        }
    }

    static class Cycle extends Row {
        final String label;
        final String[] opts;
        final IntSupplier get;
        final IntConsumer set;

        Cycle(String label, String[] opts, IntSupplier get, IntConsumer set) {
            super(24);
            this.label = label; this.opts = opts; this.get = get; this.set = set;
        }

        @Override
        void draw(DrawContext c, TextRenderer f, int mx, int my) {
            Ui.rrect(c, x, y, w, h, hit(mx, my) ? Ui.ROWH : Ui.ROW);
            c.drawText(f, label, x + 10, y + (h - 8) / 2, Ui.TXT, false);
            String t = opts[MathHelper.clamp(get.getAsInt(), 0, opts.length - 1)];
            int pw = Math.max(64, f.getWidth(t) + 20);
            int bx = x + w - pw - 8;
            Ui.rrect(c, bx, y + 4, pw, h - 8, Ui.OFF);
            c.drawText(f, t, bx + (pw - f.getWidth(t)) / 2, y + (h - 8) / 2, Ui.ACC, false);
        }

        @Override
        boolean click(double mx, double my, int btn) {
            int n = opts.length;
            int cur = get.getAsInt();
            if (btn == 0) set.accept((cur + 1) % n);
            else if (btn == 1) set.accept((cur + n - 1) % n);
            else return false;
            return true;
        }
    }

    static class Buttons extends Row {
        final String[] labels;
        final IntConsumer action;

        Buttons(String[] labels, IntConsumer action) {
            super(24);
            this.labels = labels; this.action = action;
        }

        private int bw() { return (w - (labels.length - 1) * 4) / labels.length; }

        @Override
        void draw(DrawContext c, TextRenderer f, int mx, int my) {
            int bw = bw();
            for (int i = 0; i < labels.length; i++) {
                int bx = x + i * (bw + 4);
                boolean hov = mx >= bx && mx < bx + bw && my >= y && my < y + h;
                Ui.rrect(c, bx, y, bw, h, hov ? Ui.ACC : Ui.OFF);
                c.drawText(f, labels[i], bx + (bw - f.getWidth(labels[i])) / 2, y + (h - 8) / 2, Ui.TXT, false);
            }
        }

        @Override
        boolean click(double mx, double my, int btn) {
            if (btn != 0) return false;
            int bw = bw();
            for (int i = 0; i < labels.length; i++) {
                int bx = x + i * (bw + 4);
                if (mx >= bx && mx < bx + bw) {
                    action.accept(i);
                    return true;
                }
            }
            return false;
        }
    }

    static class Slider extends Row {
        final String label;
        final double min, max, step;
        final DoubleSupplier get;
        final DoubleConsumer set;
        final DoubleFunction<String> fmt;
        final IntSupplier knob;

        Slider(String label, double min, double max, double step, DoubleSupplier get,
               DoubleConsumer set, DoubleFunction<String> fmt, IntSupplier knob) {
            super(28);
            this.label = label; this.min = min; this.max = max; this.step = step;
            this.get = get; this.set = set; this.fmt = fmt; this.knob = knob;
        }

        @Override
        void draw(DrawContext c, TextRenderer f, int mx, int my) {
            Ui.rrect(c, x, y, w, h, hit(mx, my) ? Ui.ROWH : Ui.ROW);
            double v = get.getAsDouble();
            String vs = fmt.apply(v);
            c.drawText(f, label, x + 10, y + 4, Ui.TXT, false);
            c.drawText(f, vs, x + w - 10 - f.getWidth(vs), y + 4, Ui.DIM, false);
            int tx = x + 10, tw = w - 20, ty = y + 18;
            double t = MathHelper.clamp((v - min) / (max - min), 0, 1);
            c.fill(tx, ty, tx + tw, ty + 4, Ui.OFF);
            int fw = (int) Math.round(tw * t);
            c.fill(tx, ty, tx + fw, ty + 4, Ui.ACC);
            int kc = knob != null ? knob.getAsInt() : 0xFFFFFFFF;
            c.fill(tx + fw - 3, ty - 3, tx + fw + 3, ty + 7, 0xFFFFFFFF);
            c.fill(tx + fw - 2, ty - 2, tx + fw + 2, ty + 6, kc);
        }

        @Override
        boolean click(double mx, double my, int btn) {
            if (btn != 0) return false;
            drag(mx);
            return true;
        }

        @Override
        void drag(double mx) {
            double t = MathHelper.clamp((mx - (x + 10)) / (double) (w - 20), 0, 1);
            double v = min + t * (max - min);
            v = Math.round(v / step) * step;
            v = MathHelper.clamp(v, min, max);
            set.accept(v);
        }
    }
}
