package com.vizmenu;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.util.math.MathHelper;

import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

public class Config {
    public static Config I = new Config();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    /** Position (in % of the screen), scale and background of a HUD element. */
    public static class HudBox {
        public boolean bg = true;
        public double x = 0;
        public double y = 0;
        public double scale = 1.0;

        public HudBox() {}

        public HudBox(double x, double y) {
            this.x = x;
            this.y = y;
        }
    }

    // ---- general
    public int cfgVersion = 0;
    public boolean openOnRightClick = true;
    public Map<String, Integer> binds = new HashMap<>();

    // ---- HUD
    public boolean watermark = true;
    public boolean wmVersion = true;
    public boolean wmAnim = true;
    public HudBox wmBox = new HudBox(1, 1);

    public boolean fps = true;
    public HudBox fpsBox = new HudBox(1, 9);

    public boolean coords = true;
    public int coordsDecimals = 0;
    public boolean coordsDir = true;
    public boolean coordsNether = false;
    public HudBox coordsBox = new HudBox(1, 16);

    public boolean armorHud = true;
    public boolean armorVertical = true;
    public int armorDurability = 1; // 0 off, 1 number, 2 percent
    public HudBox armorBox = new HudBox(1, 45);

    public boolean potionHud = true;
    public boolean potionHideVanilla = true;
    public int potionStyle = 0; // 0 detailed, 1 compact
    public boolean potionBars = true;
    public HudBox potionBox = new HudBox(100, 4);

    // ---- Combat
    public boolean cps = false;
    public HudBox cpsBox = new HudBox(1, 30);

    public boolean targetInfo = false;
    public boolean targetNumber = true;
    public HudBox targetBox = new HudBox(50, 62);

    // ---- Movement
    public boolean autoSprint = false;
    public boolean trail = false;
    public int trailStyle = 0;
    public double trailLength = 30;
    public boolean trailAirOnly = false;

    // ---- Player
    public boolean fullbright = false;
    public boolean blockOverlay = false;
    public boolean blockRainbow = false;
    public double blockHue = 270;
    public double blockAlpha = 0.9;

    // ---- Misc
    public boolean weather = false;
    public int weatherType = 0; // 0 clear, 1 rain, 2 thunder
    public boolean timeChanger = false;
    public int timeValue = 6000;
    public boolean mainMenu = true;
    public boolean clock24 = true;
    public boolean clockSeconds = false;
    public boolean clockDate = true;
    public int clockStyle = 2; // 0 white, 1 purple, 2 gradient
    public boolean aspectOn = false;
    public double aspect = 16.0 / 9.0;

    public int outlineColor() {
        float h = blockRainbow ? (System.currentTimeMillis() % 4000L) / 4000f : (float) (blockHue / 360.0);
        int rgb = MathHelper.hsvToRgb(h, 0.85f, 1.0f) & 0xFFFFFF;
        int a = Math.round((float) blockAlpha * 255f);
        return (a << 24) | rgb;
    }

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("vizmenu.json");
    }

    public static void load() {
        try {
            Path p = path();
            if (Files.exists(p)) {
                try (Reader r = Files.newBufferedReader(p)) {
                    Config c = GSON.fromJson(r, Config.class);
                    if (c != null) I = c;
                }
            }
        } catch (Exception ignored) {
        }
        if (I.binds == null) I.binds = new HashMap<>();
        if (I.wmBox == null) I.wmBox = new HudBox(1, 1);
        if (I.fpsBox == null) I.fpsBox = new HudBox(1, 9);
        if (I.coordsBox == null) I.coordsBox = new HudBox(1, 16);
        if (I.armorBox == null) I.armorBox = new HudBox(1, 45);
        if (I.potionBox == null) I.potionBox = new HudBox(100, 4);
        if (I.cpsBox == null) I.cpsBox = new HudBox(1, 30);
        if (I.targetBox == null) I.targetBox = new HudBox(50, 62);
        if (I.cfgVersion < 2) {
            // watermark now sits top-left: move the other top-left elements below it
            I.fpsBox.x = 1; I.fpsBox.y = 9;
            I.coordsBox.x = 1; I.coordsBox.y = 16;
            I.cpsBox.x = 1; I.cpsBox.y = 30;
            I.cfgVersion = 2;
        }
    }

    public static void save() {
        try {
            Files.writeString(path(), GSON.toJson(I));
        } catch (Exception ignored) {
        }
    }
}
