package com.vizmenu.mixin;

import com.vizmenu.Config;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Custom hand: moves and scales the first-person hand / held item. */
@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {
    private static MatrixStack viz$pushed;

    @ModifyVariable(method = "renderFirstPersonItem", at = @At("HEAD"), argsOnly = true, require = 0)
    private MatrixStack viz$hand(MatrixStack m) {
        Config c = Config.I;
        if (c.customHand && m != null) {
            m.push();
            m.translate((float) c.handX, (float) c.handY, (float) c.handZ);
            float s = (float) c.handScale;
            if (s != 1.0f) {
                m.translate(0.45f, -0.35f, -0.7f);
                m.scale(s, s, s);
                m.translate(-0.45f, 0.35f, 0.7f);
            }
            viz$pushed = m;
        }
        return m;
    }

    @Inject(method = "renderFirstPersonItem", at = @At("RETURN"), require = 0)
    private void viz$handEnd(CallbackInfo ci) {
        if (viz$pushed != null) {
            viz$pushed.pop();
            viz$pushed = null;
        }
    }
}
