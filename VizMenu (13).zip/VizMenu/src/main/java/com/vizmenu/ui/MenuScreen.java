package com.vizmenu.ui;

import com.vizmenu.Brand;
import com.vizmenu.Config;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class MenuScreen extends Screen {
    static final int PW = 440;
    private static Category lastCat = Category.HUD;

    private Category cat = lastCat;
    private Module open;       // module whose settings are shown
    private Module capturing;  // module waiting for a key to bind
    private Module hovered;    // module under the cursor (for the description)
    private boolean escGuard;
    private final List<Rows.Row> rows = new ArrayList<>();
    private Rows.Row dragging;
    private int scroll = 0;
    private int contentH = 0;

    public MenuScreen() {
        super(Text.literal("DobriVisual"));
    }

    @Override
    protected void init() {
        build();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return capturing == null && !escGuard;
    }

    @Override
    public void removed() {
        Config.save();
    }

    private int ph() { return Math.min(300, height - 8); }
    private int px() { return (width - PW) / 2; }
    private int py() { return (height - ph()) / 2; }

    private void build() {
        rows.clear();
        scroll = 0;
        if (open == null) {
            for (Module m : Modules.ALL) {
                if (m.category == cat) rows.add(new ModuleRow(m));
            }
        } else {
            rows.addAll(open.settings.get());
        }
    }

    private long window() {
        return MinecraftClient.getInstance().getWindow().getHandle();
    }

    /** While binding: the next pressed key becomes the bind. */
    private void pollBind() {
        long w = window();
        if (GLFW.glfwGetKey(w, GLFW.GLFW_KEY_ESCAPE) == GLFW.GLFW_PRESS) {
            capturing = null;
            escGuard = true;
            return;
        }
        if (GLFW.glfwGetKey(w, GLFW.GLFW_KEY_DELETE) == GLFW.GLFW_PRESS
                || GLFW.glfwGetKey(w, GLFW.GLFW_KEY_BACKSPACE) == GLFW.GLFW_PRESS) {
            capturing.setBind(-1);
            capturing = null;
            return;
        }
        for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
            if (k == GLFW.GLFW_KEY_ESCAPE) continue;
            if (GLFW.glfwGetKey(w, k) == GLFW.GLFW_PRESS) {
                for (Module o : Modules.ALL) {
                    if (o != capturing && o.bind() == k) o.setBind(-1);
                }
                capturing.setBind(k);
                capturing = null;
                return;
            }
        }
    }

    // ---------------------------------------------------------------- render
    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        if (escGuard && GLFW.glfwGetKey(window(), GLFW.GLFW_KEY_ESCAPE) != GLFW.GLFW_PRESS) escGuard = false;
        if (capturing != null) pollBind();

        hovered = null;
        c.fill(0, 0, width, height, 0x55000000);
        int px = px(), py = py(), ph = ph();
        Ui.rrect(c, px - 1, py - 1, PW + 2, ph + 2, Ui.BORDER);
        Ui.rrect(c, px, py, PW, ph, Ui.PANEL);

        int x0 = px + 16;
        c.drawText(textRenderer, "DobriVisual", x0, py + 12, Ui.ACC, true);

        // top bar: categories, or Back + title when settings are open
        if (open == null) {
            int tw = (PW - 32) / Category.values().length;
            for (int i = 0; i < Category.values().length; i++) {
                Category cg = Category.values()[i];
                int tx = x0 + i * tw;
                int ty = py + 30;
                boolean sel = cg == cat;
                boolean hov = mx >= tx && mx < tx + tw - 4 && my >= ty && my < ty + 22;
                Ui.rrect(c, tx, ty, tw - 4, 22, sel ? Ui.ROW : (hov ? Ui.ROWH : Ui.PANEL));
                if (sel) c.fill(tx + 6, ty + 20, tx + tw - 10, ty + 22, Ui.ACC);
                int lw = textRenderer.getWidth(cg.label);
                c.drawText(textRenderer, cg.label, tx + (tw - 4 - lw) / 2, ty + 7, sel ? Ui.TXT : Ui.DIM, false);
            }
        } else {
            int ty = py + 30;
            boolean hov = mx >= x0 && mx < x0 + 70 && my >= ty && my < ty + 22;
            Ui.rrect(c, x0, ty, 70, 22, hov ? Ui.ACC : Ui.OFF);
            c.drawText(textRenderer, "< Back", x0 + (70 - textRenderer.getWidth("< Back")) / 2, ty + 7, Ui.TXT, false);
            c.drawText(textRenderer, open.name + " settings", x0 + 82, ty + 7, Ui.TXT, false);
            String b = open.bindLabel();
            if (!b.isEmpty()) {
                c.drawText(textRenderer, b, x0 + PW - 32 - textRenderer.getWidth(b), ty + 7, Ui.DIM, false);
            }
        }

        int cx = x0, cy = py + 58, cw = PW - 32, ch = ph - 58 - 22;
        boolean mouseInClip = my >= cy && my < cy + ch;
        c.enableScissor(cx - 2, cy, cx + cw + 2, cy + ch);
        int y = cy - scroll;
        for (Rows.Row r : rows) {
            r.x = cx;
            r.y = y;
            r.w = cw;
            r.draw(c, textRenderer, mouseInClip ? mx : -1000, mouseInClip ? my : -1000);
            y += r.h + 4;
        }
        contentH = y + scroll - cy;
        c.disableScissor();

        if (contentH > ch) {
            int bh = Math.max(20, ch * ch / contentH);
            int by = cy + (ch - bh) * scroll / Math.max(1, contentH - ch);
            c.fill(px + PW - 6, by, px + PW - 4, by + bh, Ui.OFF);
        }

        // description of the hovered function (top of the menu)
        String top;
        int topCol = Ui.TXT;
        Module shown = open != null ? open : hovered;
        if (shown != null) {
            top = shown.desc;
        } else {
            top = "Наведи на функцию, чтобы увидеть описание";
            topCol = Ui.DIM;
        }
        int dx = x0 + textRenderer.getWidth("DobriVisual") + 16;
        String ver = Brand.version();
        int verW = ver.isEmpty() ? 0 : textRenderer.getWidth(ver) + 10;
        int maxW = px + PW - 16 - dx - verW;
        c.fill(dx - 8, py + 11, dx - 7, py + 22, Ui.OFF);
        c.drawText(textRenderer, textRenderer.trimToWidth(top, maxW), dx, py + 12, topCol, false);
        if (!ver.isEmpty()) c.drawText(textRenderer, ver, px + PW - 16 - textRenderer.getWidth(ver), py + 12, Ui.DIM, false);

        // footer hint
        String hint;
        int hc = Ui.DIM;
        if (capturing != null) {
            hint = "Нажми клавишу для " + capturing.name + "   |   Esc: отмена   |   Del: убрать";
            hc = Ui.ACC;
        } else if (open == null) {
            hint = "ЛКМ: вкл/выкл   |   ПКМ: настройки   |   Колёсико: клавиша";
        } else {
            hint = "Изменения применяются сразу";
        }
        c.drawText(textRenderer, hint, x0, py + ph - 16, hc, false);
    }

    // ---------------------------------------------------------------- input
    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y();
        int btn = click.button();
        int px = px(), py = py(), ph = ph();

        if (capturing != null) {
            capturing = null;
            return true;
        }
        if (mx < px || mx > px + PW || my < py || my > py + ph) {
            close();
            return true;
        }

        int x0 = px + 16;
        int ty = py + 30;
        if (my >= ty && my < ty + 22) {
            if (open == null) {
                int n = Category.values().length;
                int tw = (PW - 32) / n;
                for (int i = 0; i < n; i++) {
                    int tx = x0 + i * tw;
                    if (mx >= tx && mx < tx + tw - 4) {
                        cat = Category.values()[i];
                        lastCat = cat;
                        build();
                        return true;
                    }
                }
            } else if (mx >= x0 && mx < x0 + 70) {
                open = null;
                build();
                return true;
            }
        }

        int cy = py + 58, ch = ph - 58 - 22;
        if (my >= cy && my < cy + ch) {
            for (Rows.Row r : rows) {
                if (r.hit(mx, my) && r.click(mx, my, btn)) {
                    dragging = r;
                    return true;
                }
            }
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        if (dragging != null) {
            dragging.drag(click.x());
            return true;
        }
        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        dragging = null;
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int max = Math.max(0, contentH - (ph() - 58 - 22));
        scroll = MathHelper.clamp(scroll - (int) (verticalAmount * 14), 0, max);
        return true;
    }

    // ---------------------------------------------------------------- module row
    /** LMB toggles, RMB opens settings, wheel click starts key binding. */
    private class ModuleRow extends Rows.Row {
        final Module m;

        ModuleRow(Module m) {
            super(28);
            this.m = m;
        }

        @Override
        void draw(DrawContext c, TextRenderer f, int mx, int my) {
            boolean on = m.isOn();
            boolean hov = hit(mx, my);
            if (hov) hovered = m;
            Ui.rrect(c, x, y, w, h, hov ? Ui.ROWH : Ui.ROW);
            if (on) c.fill(x, y + 6, x + 2, y + h - 6, Ui.ACC);
            c.drawText(f, m.name, x + 12, y + (h - 8) / 2, Ui.TXT, false);

            int tx = x + w - 38, ty = y + (h - 12) / 2;
            Ui.rrect(c, tx, ty, 28, 12, on ? Ui.ACC : Ui.OFF);
            int kx = on ? tx + 17 : tx + 1;
            c.fill(kx, ty + 1, kx + 10, ty + 11, 0xFFFFFFFF);

            String b = capturing == m ? "нажми клавишу..." : m.bindLabel();
            if (!b.isEmpty()) {
                c.drawText(f, b, tx - 8 - f.getWidth(b), y + (h - 8) / 2,
                        capturing == m ? Ui.ACC : Ui.DIM, false);
            }
        }

        @Override
        boolean click(double mx, double my, int btn) {
            if (btn == 0) {
                m.toggle();
            } else if (btn == 1) {
                open = m;
                build();
            } else if (btn == 2) {
                capturing = m;
            } else {
                return false;
            }
            return true;
        }
    }
}
