package com.vizmenu.ui;

import com.vizmenu.Brand;
import com.vizmenu.Config;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.Random;

/** Clean title screen with a big rounded clock in the middle. */
public class MainMenuScreen extends Screen {
    private static final String[] LABELS = {"Singleplayer", "Multiplayer", "Options", "Quit"};
    private static final int STARS = 70;
    private static final float[] SX = new float[STARS];
    private static final float[] SY = new float[STARS];
    private static final float[] SP = new float[STARS];

    static {
        Random r = new Random(7L);
        for (int i = 0; i < STARS; i++) {
            SX[i] = r.nextFloat();
            SY[i] = r.nextFloat();
            SP[i] = r.nextFloat() * 6.28f;
        }
    }

    private int btnX0, btnY, btnW, btnH, btnGap;
    private long dateDay = Long.MIN_VALUE;
    private int clockKeyLast = -1;
    private String mainStr = "", secStr = "";
    private String dateStr = "";

    public MainMenuScreen() {
        super(Text.literal("DobriVisual"));
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    private static String two(int v) {
        return v < 10 ? "0" + v : Integer.toString(v);
    }

    private int unit(MinecraftClient mc) {
        return MathHelper.clamp(Math.round(mc.getWindow().getFramebufferHeight() * 0.08f), 20, 160);
    }

    private void layout(MinecraftClient mc) {
        double sf = mc.getWindow().getScaleFactor();
        int unit = unit(mc);
        int fbh = mc.getWindow().getFramebufferHeight();
        double clockBottomGui = (fbh * 0.24 + 2 * unit + unit * 0.4) / sf;
        btnH = 22;
        btnGap = 8;
        btnW = Math.min(92, (width - 40 - 3 * btnGap) / 4);
        btnX0 = (width - (4 * btnW + 3 * btnGap)) / 2;
        btnY = (int) Math.min(clockBottomGui + 40, height - 46);
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        TextRenderer f = textRenderer;
        Config cfg = Config.I;
        long now = System.currentTimeMillis();

        // ---- background
        c.fillGradient(0, 0, width, height, 0xFF09090E, 0xFF17102B);
        c.fillGradient(0, height / 2, width, height, 0x00000000, 0x558B5CF6);
        c.fillGradient(0, 0, width, height / 3, 0x2A8B5CF6, 0x00000000);
        for (int i = 0; i < STARS; i++) {
            float tw = 0.5f + 0.5f * (float) Math.sin(now / 900.0 + SP[i]);
            int a = (int) (40 + 110 * tw);
            int sx = (int) (SX[i] * width), sy = (int) (SY[i] * height);
            c.fill(sx, sy, sx + 1, sy + 1, (a << 24) | 0xFFFFFF);
        }

        layout(mc);

        // ---- wordmark (top)
        c.getMatrices().pushMatrix();
        c.getMatrices().translate(width / 2f, Math.max(10f, height * 0.07f));
        c.getMatrices().scale(2f, 2f);
        Brand.drawName(c, f, -Brand.nameWidth(f) / 2, 0, true, true);
        c.getMatrices().popMatrix();

        // ---- clock
        LocalTime t = LocalTime.now();
        int hour = t.getHour();
        boolean pm = hour >= 12;
        int clockKey = (t.getSecond() + 60 * t.getMinute() + 3600 * hour) * 4 + (cfg.clock24 ? 1 : 0) + (cfg.clockSeconds ? 2 : 0);
        if (clockKey != clockKeyLast) {
            clockKeyLast = clockKey;
            int hh = cfg.clock24 ? hour : (hour % 12 == 0 ? 12 : hour % 12);
            mainStr = (cfg.clock24 ? two(hh) : Integer.toString(hh)) + ":" + two(t.getMinute());
            secStr = cfg.clockSeconds ? two(t.getSecond()) : "";
        }
        String main = mainStr;
        String sec = secStr;

        double sf = mc.getWindow().getScaleFactor();
        int fbw = mc.getWindow().getFramebufferWidth();
        int fbh = mc.getWindow().getFramebufferHeight();
        int unit = unit(mc);
        int secUnit = Math.max(8, Math.round(unit * 0.38f));
        int mainW = RoundDigits.width(main, unit);
        int gap = Math.round(unit * 0.35f);
        int secW = sec.isEmpty() ? 0 : RoundDigits.width(sec, secUnit);
        int totalW = mainW + (sec.isEmpty() ? 0 : gap + secW);
        int x0 = (fbw - totalW) / 2;
        int y0 = Math.round(fbh * 0.24f);

        c.getMatrices().pushMatrix();
        c.getMatrices().scale((float) (1.0 / sf), (float) (1.0 / sf));
        int shadow = Math.max(2, unit / 26);
        drawClock(c, main, x0 + shadow, y0 + shadow, unit, cfg.clockStyle, true);
        drawClock(c, main, x0, y0, unit, cfg.clockStyle, false);
        if (!sec.isEmpty()) {
            int sy = y0 + 2 * unit - 2 * secUnit;
            int sx = x0 + mainW + gap;
            drawClock(c, sec, sx + shadow / 2, sy + shadow / 2, secUnit, cfg.clockStyle, true);
            drawClock(c, sec, sx, sy, secUnit, cfg.clockStyle, false);
        }
        c.getMatrices().popMatrix();

        // ---- date
        if (cfg.clockDate) {
            LocalDate d = LocalDate.now();
            if (d.toEpochDay() != dateDay) {
                dateDay = d.toEpochDay();
                String s = d.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.getDefault()));
                dateStr = s.isEmpty() ? s : Character.toUpperCase(s.charAt(0)) + s.substring(1);
            }
            String line = cfg.clock24 ? dateStr : dateStr + "  -  " + (pm ? "PM" : "AM");
            int dy = (int) ((fbh * 0.24 + 2 * unit + unit * 0.4) / sf) + 8;
            c.drawText(f, line, (width - f.getWidth(line)) / 2, dy, 0xFFB4B4C0, true);
        }

        // ---- buttons
        for (int i = 0; i < 4; i++) {
            int bx = btnX0 + i * (btnW + btnGap);
            boolean hov = mx >= bx && mx < bx + btnW && my >= btnY && my < btnY + btnH;
            Ui.pill(c, bx - 1, btnY - 1, btnW + 2, btnH + 2, hov ? Ui.ACC : 0xFF2B2C35);
            Ui.pill(c, bx, btnY, btnW, btnH, hov ? 0xFF2A1F4A : 0xFF15161A);
            int lw = f.getWidth(LABELS[i]);
            c.drawText(f, LABELS[i], bx + (btnW - lw) / 2, btnY + (btnH - 8) / 2, hov ? 0xFFFFFFFF : Ui.TXT, false);
        }

        // ---- footer
        String ver = Brand.NAME + " " + Brand.version();
        c.drawText(f, ver, 8, height - 14, Ui.DIM, false);
        String mcv = "Minecraft 1.21.11";
        c.drawText(f, mcv, width - 8 - f.getWidth(mcv), height - 14, Ui.DIM, false);
    }

    private void drawClock(DrawContext c, String s, int x, int y, int unit, int style, boolean shadow) {
        int cx = x;
        int n = s.length();
        for (int i = 0; i < n; i++) {
            char ch = s.charAt(i);
            int col;
            if (shadow) {
                col = 0xFF120D22;
            } else if (style == 0) {
                col = 0xFFF2F2F7;
            } else if (style == 1) {
                col = 0xFFA78BFA;
            } else {
                col = Brand.lerp(0xFF8B5CF6, 0xFFE879F9, n <= 1 ? 0f : i / (float) (n - 1));
            }
            cx += RoundDigits.drawChar(c, ch, cx, y, unit, col);
        }
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (click.button() != 0) return super.mouseClicked(click, doubled);
        MinecraftClient mc = MinecraftClient.getInstance();
        layout(mc);
        double mx = click.x(), my = click.y();
        for (int i = 0; i < 4; i++) {
            int bx = btnX0 + i * (btnW + btnGap);
            if (mx >= bx && mx < bx + btnW && my >= btnY && my < btnY + btnH) {
                switch (i) {
                    case 0 -> mc.setScreen(new SelectWorldScreen(this));
                    case 1 -> mc.setScreen(new MultiplayerScreen(this));
                    case 2 -> mc.setScreen(new OptionsScreen(this, mc.options));
                    default -> mc.scheduleStop();
                }
                return true;
            }
        }
        return super.mouseClicked(click, doubled);
    }
}
