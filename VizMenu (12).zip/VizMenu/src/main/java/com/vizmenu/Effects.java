package com.vizmenu;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Jump circle, predictive trail and kill effect. */
public final class Effects {
    private static final Random RND = new Random();
    private static final BlockPos.Mutable MP = new BlockPos.Mutable();
    private static final double[] PT = new double[2];

    // ---- jump circle
    private static final int MAX_RINGS = 6;
    private static final double[] RX = new double[MAX_RINGS], RY = new double[MAX_RINGS], RZ = new double[MAX_RINGS];
    private static final long[] RT = new long[MAX_RINGS];
    private static int ringCount = 0;
    private static boolean wasGround = true;
    private static double groundX, groundY, groundZ;
    private static final double[] RING_X = new double[49], RING_Y = new double[49];
    private static final boolean[] RING_OK = new boolean[49];

    // ---- trail
    private static final int MAX_TRAIL = 64;
    private static final double[] TX = new double[MAX_TRAIL], TY = new double[MAX_TRAIL], TZ = new double[MAX_TRAIL];
    private static int trailN = 0;
    private static boolean trailLands = false;
    private static double baseX, baseY, baseZ;

    // ---- kill effect
    private static final int MAX_TRACK = 8;
    private static final LivingEntity[] TRK = new LivingEntity[MAX_TRACK];
    private static final long[] TRK_T = new long[MAX_TRACK];
    private static final class Burst {
        double minX, maxX, minY, maxY, minZ, maxZ;
        int age;
    }
    private static final List<Burst> BURSTS = new ArrayList<>();
    private static ParticleEffect[][] killSets;
    private static boolean killDirty = false;

    private Effects() {}

    // =================================================================== tick
    public static void tick(MinecraftClient mc, ClientPlayerEntity p, Config c) {
        // jump circle
        boolean ground = p.isOnGround();
        if (ground) {
            groundX = p.getX();
            groundY = p.getY();
            groundZ = p.getZ();
        }
        if (c.jumpCircle && wasGround && !ground && p.getVelocity().y > 0.1) {
            addRing(groundX, groundY, groundZ);
        }
        wasGround = ground;

        // predictive trail path
        if (c.trail && c.trailMode != 2) simTrail(mc, p, c);
        else trailN = 0;

        // kill effect
        killTick(mc, c);
    }

    // ============================================================ jump circle
    private static void addRing(double x, double y, double z) {
        if (ringCount == MAX_RINGS) {
            for (int i = 1; i < MAX_RINGS; i++) {
                RX[i - 1] = RX[i]; RY[i - 1] = RY[i]; RZ[i - 1] = RZ[i]; RT[i - 1] = RT[i];
            }
            ringCount--;
        }
        RX[ringCount] = x;
        RY[ringCount] = y;
        RZ[ringCount] = z;
        RT[ringCount] = System.currentTimeMillis();
        ringCount++;
    }

    private static void removeRing(int i) {
        for (int k = i + 1; k < ringCount; k++) {
            RX[k - 1] = RX[k]; RY[k - 1] = RY[k]; RZ[k - 1] = RZ[k]; RT[k - 1] = RT[k];
        }
        ringCount--;
    }

    private static int colorAt(int mode, float k, long now) {
        switch (mode) {
            case 1: return 0xFFA78BFA;
            case 2: return 0xFF000000 | (MathHelper.hsvToRgb(((k + now / 2500f) % 1f + 1f) % 1f, 0.8f, 1f) & 0xFFFFFF);
            case 3: return 0xFFFFFFFF;
            default: return Brand.lerp(0xFF8B5CF6, 0xFFE879F9, 0.5f + 0.5f * (float) Math.sin(k * 6.2831853f + now / 500f));
        }
    }

    private static void drawRing(DrawContext ctx, double x, double y, double z, double r, double alpha, int mode, int thin, long now) {
        if (alpha * 255.0 < 3.0) return;
        int n = 48;
        for (int i = 0; i <= n; i++) {
            double a = i * (Math.PI * 2.0 / n);
            RING_OK[i] = Proj.project(x + Math.cos(a) * r, y, z + Math.sin(a) * r, PT);
            RING_X[i] = PT[0];
            RING_Y[i] = PT[1];
        }
        int a255 = (int) Math.max(0, Math.min(255, alpha * 255.0));
        if (a255 < 3) return;
        int aGlow = (int) (a255 * 0.22);
        for (int i = 0; i < n; i++) {
            if (!RING_OK[i] || !RING_OK[i + 1]) continue;
            int rgb = colorAt(mode, i / (float) n, now) & 0xFFFFFF;
            Proj.line(ctx, RING_X[i], RING_Y[i], RING_X[i + 1], RING_Y[i + 1], thin * 4, (aGlow << 24) | rgb);
            Proj.line(ctx, RING_X[i], RING_Y[i], RING_X[i + 1], RING_Y[i + 1], thin, (a255 << 24) | rgb);
        }
    }

    private static void renderRings(DrawContext ctx, Config c, long now) {
        int thin = Math.max(2, Proj.fbh / 320);
        for (int i = ringCount - 1; i >= 0; i--) {
            double dur = 900.0 / Math.max(0.3, c.jcSpeed);
            double t = (now - RT[i]) / dur;
            if (t >= 1.0) {
                removeRing(i);
                continue;
            }
            double e = 1.0 - Math.pow(1.0 - t, 3.0);
            double r = 0.3 + (c.jcSize - 0.3) * e;
            drawRing(ctx, RX[i], RY[i] + 0.03, RZ[i], r, Math.pow(1.0 - t, 1.4), c.jcColor, thin, now);
            if (c.jcDouble && t > 0.1) {
                double t2 = (t - 0.1) / 0.9;
                double e2 = 1.0 - Math.pow(1.0 - t2, 3.0);
                double r2 = 0.2 + (c.jcSize * 0.62 - 0.2) * e2;
                drawRing(ctx, RX[i], RY[i] + 0.03, RZ[i], r2, Math.pow(1.0 - t2, 1.6) * 0.7, c.jcColor, thin, now);
            }
        }
    }

    // ================================================================= trail
    private static void simTrail(MinecraftClient mc, ClientPlayerEntity p, Config c) {
        Vec3d v = p.getVelocity();
        boolean moving = v.x * v.x + v.z * v.z > 0.0025 || Math.abs(v.y) > 0.1;
        if (!moving || (c.trailAirOnly && p.isOnGround())) {
            trailN = 0;
            return;
        }
        double x = p.getX(), y = p.getY() + 0.1, z = p.getZ();
        baseX = p.getX();
        baseY = p.getY();
        baseZ = p.getZ();
        double vx = v.x, vy = v.y, vz = v.z;
        int steps = Math.min(MAX_TRAIL - 1, (int) c.trailLength);
        boolean startedAirborne = !p.isOnGround();
        trailN = 0;
        trailLands = false;
        TX[trailN] = x; TY[trailN] = y; TZ[trailN] = z; trailN++;
        for (int i = 1; i <= steps; i++) {
            x += vx;
            y += vy;
            z += vz;
            if (!mc.world.getBlockState(MP.set(x, y, z)).isAir()) {
                trailLands = startedAirborne;
                break;
            }
            if (vy <= 0 && !mc.world.getBlockState(MP.set(x, y - 0.2, z)).isAir()) vy = 0;
            else vy = (vy - 0.08) * 0.98;
            vx *= 0.9;
            vz *= 0.9;
            TX[trailN] = x; TY[trailN] = y; TZ[trailN] = z; trailN++;
        }
    }

    private static void renderTrail(DrawContext ctx, MinecraftClient mc, Config c, float td, long now) {
        if (trailN < 2) return;
        Vec3d lp = mc.player.getLerpedPos(td);
        double sx = lp.x - baseX, sy = lp.y - baseY, sz = lp.z - baseZ;
        int thin = Math.max(2, (int) Math.round(c.trailThick * Proj.fbh / 540.0));
        double px = 0, py = 0;
        boolean prevOk = false;
        for (int i = 0; i < trailN; i++) {
            boolean ok = Proj.project(TX[i] + sx, TY[i] + sy, TZ[i] + sz, PT);
            double cxp = PT[0], cyp = PT[1];
            float f = i / (float) (trailN - 1);
            if (ok && prevOk) {
                int a = (int) (235 * Math.pow(1.0 - f, 0.9));
                int rgb;
                if (c.trailColor == 1) rgb = 0xA78BFA;
                else if (c.trailColor == 2) rgb = MathHelper.hsvToRgb(((f * 0.8f + now / 2500f) % 1f + 1f) % 1f, 0.8f, 1f) & 0xFFFFFF;
                else rgb = Brand.lerp(0xFF8B5CF6, 0xFF67E8F9, f) & 0xFFFFFF;
                int w = Math.max(2, Math.round(thin * (1.0f - 0.55f * f)));
                if (c.trailMode == 1) {
                    if ((i & 1) == 0) {
                        Proj.line(ctx, cxp, cyp, cxp, cyp, w * 3, ((a / 4) << 24) | rgb);
                        Proj.line(ctx, cxp, cyp, cxp, cyp, w * 2, (a << 24) | rgb);
                    }
                } else {
                    Proj.line(ctx, px, py, cxp, cyp, w * 3, ((a / 5) << 24) | rgb);
                    Proj.line(ctx, px, py, cxp, cyp, w, (a << 24) | rgb);
                }
            }
            px = cxp;
            py = cyp;
            prevOk = ok;
        }
        if (c.trailLanding && trailLands) {
            int last = trailN - 1;
            drawRing(ctx, TX[last] + sx, TY[last] + sy + 0.05 - 0.1, TZ[last] + sz, 0.35, 0.8, c.trailColor == 1 ? 1 : (c.trailColor == 2 ? 2 : 0), Math.max(2, thin), now);
        }
    }

    // =============================================================== render
    public static void render(DrawContext ctx, MinecraftClient mc, Config c, float td) {
        boolean rings = c.jumpCircle && ringCount > 0;
        boolean trail = c.trail && c.trailMode != 2 && trailN > 1;
        if (!rings && !trail) return;
        if (mc.currentScreen != null) return;
        if (!Proj.setup(mc, td)) return;

        long now = System.currentTimeMillis();
        float sf = (float) mc.getWindow().getScaleFactor();
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(1f / sf, 1f / sf);
        if (rings) renderRings(ctx, c, now);
        if (trail) renderTrail(ctx, mc, c, td, now);
        ctx.getMatrices().popMatrix();
    }

    // ============================================================ kill effect
    private static void track(LivingEntity le, long now) {
        int free = -1, oldest = 0;
        for (int i = 0; i < MAX_TRACK; i++) {
            if (TRK[i] == le) {
                TRK_T[i] = now;
                return;
            }
            if (TRK[i] == null && free < 0) free = i;
            if (TRK_T[i] < TRK_T[oldest]) oldest = i;
        }
        int slot = free >= 0 ? free : oldest;
        TRK[slot] = le;
        TRK_T[slot] = now;
    }

    private static void killTick(MinecraftClient mc, Config c) {
        if (!c.killFx) {
            if (killDirty) {
                BURSTS.clear();
                for (int i = 0; i < MAX_TRACK; i++) TRK[i] = null;
                killDirty = false;
            }
            return;
        }
        killDirty = true;
        long now = System.currentTimeMillis();
        if (mc.options.attackKey.isPressed() && mc.crosshairTarget instanceof EntityHitResult e
                && e.getEntity() instanceof LivingEntity le && le != mc.player) {
            track(le, now);
        }
        for (int i = 0; i < MAX_TRACK; i++) {
            LivingEntity le = TRK[i];
            if (le == null) continue;
            if (now - TRK_T[i] > 8000L) {
                TRK[i] = null;
                continue;
            }
            if (le.isDead() || le.getHealth() <= 0f || le.isRemoved()) {
                if (!c.killPlayersOnly || le instanceof PlayerEntity) startBurst(le);
                TRK[i] = null;
            }
        }
        for (int i = BURSTS.size() - 1; i >= 0; i--) {
            Burst b = BURSTS.get(i);
            spawnBurst(mc, c, b);
            if (++b.age >= 22) BURSTS.remove(i);
        }
    }

    private static void startBurst(LivingEntity le) {
        if (BURSTS.size() >= 6) BURSTS.remove(0);
        Box box = le.getBoundingBox();
        Burst b = new Burst();
        b.minX = box.minX; b.maxX = box.maxX;
        b.minY = box.minY; b.maxY = box.maxY;
        b.minZ = box.minZ; b.maxZ = box.maxZ;
        BURSTS.add(b);
    }

    private static void spawnBurst(MinecraftClient mc, Config c, Burst b) {
        if (killSets == null) {
            killSets = new ParticleEffect[][]{
                    {ParticleTypes.ASH, ParticleTypes.ASH, ParticleTypes.WHITE_ASH, ParticleTypes.POOF},
                    {ParticleTypes.SOUL, ParticleTypes.SOUL, ParticleTypes.SOUL_FIRE_FLAME},
                    {ParticleTypes.TOTEM_OF_UNDYING, ParticleTypes.TOTEM_OF_UNDYING, ParticleTypes.END_ROD},
                    {ParticleTypes.ELECTRIC_SPARK, ParticleTypes.END_ROD}
            };
        }
        ParticleEffect[] set = killSets[Math.max(0, Math.min(c.killStyle, killSets.length - 1))];
        double h = Math.max(0.1, b.maxY - b.minY);
        double f = b.age / 22.0;
        double top = b.maxY - h * f;
        double band = h / 22.0 * 1.6;
        int count = (int) Math.round((b.age == 0 ? 26 : 7) * c.killAmount);
        for (int i = 0; i < count; i++) {
            double x = b.minX + RND.nextDouble() * (b.maxX - b.minX);
            double z = b.minZ + RND.nextDouble() * (b.maxZ - b.minZ);
            double y = b.age == 0 ? b.minY + RND.nextDouble() * h : top - RND.nextDouble() * band;
            double vx = (RND.nextDouble() - 0.5) * 0.07;
            double vz = (RND.nextDouble() - 0.5) * 0.07;
            double vy = 0.02 + RND.nextDouble() * 0.07;
            mc.particleManager.addParticle(set[RND.nextInt(set.length)], x, y, z, vx, vy, vz);
        }
    }
}
