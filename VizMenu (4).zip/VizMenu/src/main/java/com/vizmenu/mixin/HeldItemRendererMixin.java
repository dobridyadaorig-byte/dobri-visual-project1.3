package com.vizmenu.mixin;

import com.vizmenu.Config;
import net.minecraft.client.render.item.HeldItemRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** Makes the first-person hand and held item fully lit (self-glowing). */
@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {

    @ModifyVariable(method = "renderItem", at = @At("HEAD"), argsOnly = true, ordinal = 0, require = 0)
    private int viz$fullLight(int light) {
        return (Config.I.handGlow && Config.I.glowLit) ? 0xF000F0 : light;
    }
}
