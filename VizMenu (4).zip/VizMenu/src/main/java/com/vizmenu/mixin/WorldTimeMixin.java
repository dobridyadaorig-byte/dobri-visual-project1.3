package com.vizmenu.mixin;

import com.vizmenu.Config;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(World.class)
public abstract class WorldTimeMixin {

    @Inject(method = "getTimeOfDay", at = @At("HEAD"), cancellable = true, require = 0)
    private void viz$timeOfDay(CallbackInfoReturnable<Long> cir) {
        if (Config.I.timeMode == 1 && (Object) this instanceof ClientWorld) {
            cir.setReturnValue((long) Config.I.timeValue);
        }
    }

    @Inject(method = "getSkyAngle", at = @At("HEAD"), cancellable = true, require = 0)
    private void viz$skyAngle(CallbackInfoReturnable<Float> cir) {
        if (Config.I.timeMode == 1 && (Object) this instanceof ClientWorld) {
            double d = Config.I.timeValue / 24000.0 - 0.25;
            d = d - Math.floor(d);
            double e = 0.5 - Math.cos(d * Math.PI) / 2.0;
            cir.setReturnValue((float) ((d * 2.0 + e) / 3.0));
        }
    }
}
