package com.vizmenu.ui;

import net.minecraft.client.gui.DrawContext;

public final class Ui {
    private Ui() {}

    /** Rectangle with softly cut corners. */
    public static void rrect(DrawContext c, int x, int y, int w, int h, int col) {
        if (w <= 2 || h <= 2) {
            c.fill(x, y, x + w, y + h, col);
            return;
        }
        c.fill(x + 1, y, x + w - 1, y + h, col);
        c.fill(x, y + 1, x + 1, y + h - 1, col);
        c.fill(x + w - 1, y + 1, x + w, y + h - 1, col);
    }
}
