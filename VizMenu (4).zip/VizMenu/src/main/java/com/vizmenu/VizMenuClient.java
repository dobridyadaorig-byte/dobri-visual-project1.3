package com.vizmenu;

import com.vizmenu.ui.MenuScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.hit.HitResult;
import org.lwjgl.glfw.GLFW;

public class VizMenuClient implements ClientModInitializer {
    public static KeyBinding OPEN;
    private boolean rmbWas = false;
    private boolean nvAdded = false;
    private int trailTick = 0;

    @Override
    public void onInitializeClient() {
        Config.load();

        OPEN = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.vizmenu.open",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyBinding.Category.create(Identifier.of("vizmenu", "main"))
        ));

        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
        HudElementRegistry.addLast(Identifier.of("vizmenu", "hud"), (ctx, tc) -> Hud.render(ctx));
    }

    private void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        if (p == null || w == null) {
            rmbWas = false;
            nvAdded = false;
            return;
        }

        // Open menu: keybind (Right Shift) ...
        while (OPEN.wasPressed()) {
            if (mc.currentScreen == null) mc.setScreen(new MenuScreen());
        }
        // ... or right click with empty hands on empty air
        boolean rmb = mc.options.useKey.isPressed();
        if (rmb && !rmbWas && mc.currentScreen == null && Config.I.openOnRightClick) {
            HitResult h = mc.crosshairTarget;
            boolean air = h == null || h.getType() == HitResult.Type.MISS;
            if (air && p.getMainHandStack().isEmpty() && p.getOffHandStack().isEmpty()) {
                mc.setScreen(new MenuScreen());
            }
        }
        rmbWas = rmb;

        Config c = Config.I;

        // Fullbright (client-side night vision, no particles / icon)
        StatusEffectInstance nv = p.getStatusEffect(StatusEffects.NIGHT_VISION);
        if (c.fullbright) {
            if (nv == null) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1_000_000, 0, false, false, false));
                nvAdded = true;
            }
        } else if (nvAdded) {
            if (nv != null && !nv.shouldShowIcon()) p.removeStatusEffect(StatusEffects.NIGHT_VISION);
            nvAdded = false;
        }

        // Auto sprint
        if (c.autoSprint && !p.isSprinting()
                && mc.options.forwardKey.isPressed()
                && !p.isSneaking() && !p.isUsingItem()
                && !p.horizontalCollision
                && p.getHungerManager().getFoodLevel() > 6
                && !p.hasStatusEffect(StatusEffects.BLINDNESS)) {
            p.setSprinting(true);
        }

        // Predictive trail
        if (c.trail && (!c.trailAirOnly || !p.isOnGround())) {
            Vec3d v = p.getVelocity();
            if (v.x * v.x + v.z * v.z > 0.0025 || Math.abs(v.y) > 0.1) {
                if (++trailTick % 4 == 0) spawnTrail(mc, p, c);
            }
        }

        // Weather control (client-side)
        switch (c.weatherMode) {
            case 1 -> { w.setRainGradient(0f); w.setThunderGradient(0f); }
            case 2 -> { w.setRainGradient(1f); w.setThunderGradient(0f); }
            case 3 -> { w.setRainGradient(1f); w.setThunderGradient(1f); }
            default -> { }
        }
    }

    private void spawnTrail(MinecraftClient mc, ClientPlayerEntity p, Config c) {
        ParticleEffect[] styles = {
                ParticleTypes.END_ROD, ParticleTypes.FLAME, ParticleTypes.SOUL_FIRE_FLAME,
                ParticleTypes.ELECTRIC_SPARK, ParticleTypes.HAPPY_VILLAGER
        };
        ParticleEffect type = styles[Math.max(0, Math.min(c.trailStyle, styles.length - 1))];
        Vec3d v = p.getVelocity();
        double x = p.getX(), y = p.getY() + 0.1, z = p.getZ();
        double vx = v.x, vy = v.y, vz = v.z;
        int steps = (int) c.trailLength;
        int stride = Math.max(2, steps / 10);
        for (int i = 1; i <= steps; i++) {
            x += vx;
            y += vy;
            z += vz;
            BlockPos here = BlockPos.ofFloored(x, y, z);
            if (!mc.world.getBlockState(here).isAir()) break;
            boolean ground = !mc.world.getBlockState(BlockPos.ofFloored(x, y - 0.2, z)).isAir();
            if (ground && vy <= 0) vy = 0; else vy = (vy - 0.08) * 0.98;
            vx *= 0.9;
            vz *= 0.9;
            if (i % stride == 0) {
                mc.particleManager.addParticle(type, x, y, z, 0.0, 0.0, 0.0);
            }
        }
    }
}
