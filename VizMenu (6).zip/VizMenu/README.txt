DobriVisual (проект VizMenu) — клиентский Fabric-мод для Minecraft Java 1.21.11

ОТКРЫТЬ МЕНЮ: ПКМ пустой рукой по воздуху ИЛИ Right Shift (меняется в Управлении).

В МЕНЮ
- Сверху разделы: HUD, Combat, Movement, Player, Misc.
- ЛКМ по функции — включить/выключить.
- ПКМ по функции — открыть её настройки (кнопка "< Back" возвращает назад).
- Колёсико мыши по функции — бинд: потом нажми клавишу. Esc — отмена, Del/Backspace — убрать бинд.
- Забинженная клавиша включает/выключает функцию в игре (сообщение в экшн-баре).

ФУНКЦИИ
HUD: FPS, Coordinates, Armor status, Potion visuals
Combat: CPS counter, Target info
Movement: Auto sprint, Predictive trail
Player: Fullbright, Block overlay
Misc: Weather control, Time changer, Aspect ratio, Open on right click

Настройки и бинды: config/vizmenu.json

ПОЛУЧИТЬ .JAR: положи VizMenu.zip в корень репозитория, workflow в .github/workflows соберёт мод.
Скачать jar: Actions -> последний запуск -> внизу Artifacts -> VizMenu-jar.

ШРИФТ
Во всей игре (меню, чат, HUD) вместо пиксельного шрифта используется Carlito (лицензия SIL OFL, файл LICENSE-Carlito.txt).
Настройки шрифта лежат в src/main/resources/assets/minecraft/font/default.json (size, shift).

ОПИСАНИЕ ФУНКЦИЙ
При наведении на функцию в меню её краткое описание показывается сверху, справа от названия DobriVisual.
