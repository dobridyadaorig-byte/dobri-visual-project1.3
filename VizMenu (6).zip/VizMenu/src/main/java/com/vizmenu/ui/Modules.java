package com.vizmenu.ui;

import com.vizmenu.Config;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Supplier;

/** Registry of all functions, grouped by category. */
public final class Modules {
    public static final List<Module> ALL = new ArrayList<>();

    private Modules() {}

    private static Config c() {
        return Config.I;
    }

    private static void add(Category cat, String id, String name, String desc,
                            BooleanSupplier get, Consumer<Boolean> set, Supplier<List<Rows.Row>> settings) {
        ALL.add(new Module(cat, id, name, desc, get, set, settings));
    }

    private static String f2(double v) {
        return String.format("%.2f", v);
    }

    private static String clock(int ticks) {
        int mins = (int) ((((ticks / 1000.0) + 6.0) % 24.0) * 60.0);
        return String.format("%02d:%02d", mins / 60, mins % 60);
    }

    /** Background / position / scale rows shared by all HUD elements. */
    private static List<Rows.Row> box(Config.HudBox b, List<Rows.Row> l) {
        l.add(new Rows.Toggle("Background", () -> b.bg, v -> b.bg = v));
        l.add(new Rows.Slider("Position X", 0, 100, 1, () -> b.x, v -> b.x = v, v -> (int) v + "%", null));
        l.add(new Rows.Slider("Position Y", 0, 100, 1, () -> b.y, v -> b.y = v, v -> (int) v + "%", null));
        l.add(new Rows.Slider("Scale", 0.5, 2.0, 0.05, () -> b.scale, v -> b.scale = v, v -> f2(v) + "x", null));
        return l;
    }

    private static List<Rows.Row> none() {
        List<Rows.Row> l = new ArrayList<>();
        l.add(new Rows.Label("No extra settings."));
        return l;
    }

    static {
        // ------------------------------------------------------------ HUD
        add(Category.HUD, "fps", "FPS", "Shows your current frames per second",
                () -> c().fps, v -> c().fps = v,
                () -> box(c().fpsBox, new ArrayList<>()));

        add(Category.HUD, "coords", "Coordinates", "Shows your XYZ position and facing direction",
                () -> c().coords, v -> c().coords = v,
                () -> {
                    List<Rows.Row> l = new ArrayList<>();
                    l.add(new Rows.Cycle("Decimals", new String[]{"0", "1", "2"},
                            () -> c().coordsDecimals, v -> c().coordsDecimals = v));
                    l.add(new Rows.Toggle("Facing direction", () -> c().coordsDir, v -> c().coordsDir = v));
                    l.add(new Rows.Toggle("Nether / Overworld coords", () -> c().coordsNether, v -> c().coordsNether = v));
                    return box(c().coordsBox, l);
                });

        add(Category.HUD, "armor", "Armor status", "Shows worn armor and its durability on screen",
                () -> c().armorHud, v -> c().armorHud = v,
                () -> {
                    List<Rows.Row> l = new ArrayList<>();
                    l.add(new Rows.Cycle("Layout", new String[]{"Vertical", "Horizontal"},
                            () -> c().armorVertical ? 0 : 1, v -> c().armorVertical = (v == 0)));
                    l.add(new Rows.Cycle("Durability", new String[]{"Off", "Number", "Percent"},
                            () -> c().armorDurability, v -> c().armorDurability = v));
                    return box(c().armorBox, l);
                });

        add(Category.HUD, "potions", "Potion visuals", "Cleaner active effects list with timers",
                () -> c().potionHud, v -> c().potionHud = v,
                () -> {
                    List<Rows.Row> l = new ArrayList<>();
                    l.add(new Rows.Toggle("Hide vanilla effects", () -> c().potionHideVanilla, v -> c().potionHideVanilla = v));
                    l.add(new Rows.Cycle("Style", new String[]{"Detailed", "Compact"},
                            () -> c().potionStyle, v -> c().potionStyle = v));
                    l.add(new Rows.Toggle("Timer bars", () -> c().potionBars, v -> c().potionBars = v));
                    return box(c().potionBox, l);
                });

        // --------------------------------------------------------- Combat
        add(Category.COMBAT, "cps", "CPS counter", "Shows how many times per second you left-click",
                () -> c().cps, v -> c().cps = v,
                () -> box(c().cpsBox, new ArrayList<>()));

        add(Category.COMBAT, "target", "Target info", "Shows name and health of the mob or player you aim at",
                () -> c().targetInfo, v -> c().targetInfo = v,
                () -> {
                    List<Rows.Row> l = new ArrayList<>();
                    l.add(new Rows.Toggle("Health number", () -> c().targetNumber, v -> c().targetNumber = v));
                    return box(c().targetBox, l);
                });

        // ------------------------------------------------------- Movement
        add(Category.MOVEMENT, "autosprint", "Auto sprint", "Sprints automatically while you walk forward",
                () -> c().autoSprint, v -> c().autoSprint = v,
                Modules::none);

        add(Category.MOVEMENT, "trail", "Predictive trail", "Particles show the path you are about to take",
                () -> c().trail, v -> c().trail = v,
                () -> {
                    List<Rows.Row> l = new ArrayList<>();
                    l.add(new Rows.Cycle("Style", new String[]{"End rod", "Flame", "Soul fire", "Spark", "Green"},
                            () -> c().trailStyle, v -> c().trailStyle = v));
                    l.add(new Rows.Slider("Length", 10, 60, 1, () -> c().trailLength, v -> c().trailLength = v,
                            v -> (int) v + " ticks", null));
                    l.add(new Rows.Toggle("Only in air", () -> c().trailAirOnly, v -> c().trailAirOnly = v));
                    return l;
                });

        // --------------------------------------------------------- Player
        add(Category.PLAYER, "fullbright", "Fullbright", "Makes everything fully bright, caves included",
                () -> c().fullbright, v -> c().fullbright = v,
                Modules::none);

        add(Category.PLAYER, "blockoverlay", "Block overlay", "Recolors the outline of the block you look at",
                () -> c().blockOverlay, v -> c().blockOverlay = v,
                () -> {
                    List<Rows.Row> l = new ArrayList<>();
                    l.add(new Rows.Toggle("Rainbow", () -> c().blockRainbow, v -> c().blockRainbow = v));
                    l.add(new Rows.Slider("Color (hue)", 0, 360, 1, () -> c().blockHue, v -> c().blockHue = v,
                            v -> (int) v + "\u00B0",
                            () -> 0xFF000000 | (MathHelper.hsvToRgb((float) (c().blockHue / 360.0), 0.85f, 1f) & 0xFFFFFF)));
                    l.add(new Rows.Slider("Opacity", 0.1, 1.0, 0.05, () -> c().blockAlpha, v -> c().blockAlpha = v,
                            v -> Math.round(v * 100) + "%", null));
                    return l;
                });

        // ----------------------------------------------------------- Misc
        add(Category.MISC, "weather", "Weather control", "Changes the weather for you only (client-side)",
                () -> c().weather, v -> c().weather = v,
                () -> {
                    List<Rows.Row> l = new ArrayList<>();
                    l.add(new Rows.Cycle("Weather", new String[]{"Clear", "Rain", "Thunder"},
                            () -> c().weatherType, v -> { c().weatherType = v; c().weather = true; }));
                    return l;
                });

        add(Category.MISC, "time", "Time changer", "Changes the time of day for you only (client-side)",
                () -> c().timeChanger, v -> c().timeChanger = v,
                () -> {
                    List<Rows.Row> l = new ArrayList<>();
                    l.add(new Rows.Slider("Time of day", 0, 24000, 100, () -> c().timeValue,
                            v -> { c().timeValue = (int) v; c().timeChanger = true; },
                            v -> clock((int) v), null));
                    int[] presets = {23000, 1000, 6000, 12000, 13000, 18000};
                    l.add(new Rows.Buttons(new String[]{"Dawn", "Day", "Noon", "Dusk", "Night", "Mid."}, i -> {
                        c().timeValue = presets[i];
                        c().timeChanger = true;
                    }));
                    return l;
                });

        add(Category.MISC, "aspect", "Aspect ratio", "Stretches the game view to a custom aspect ratio",
                () -> c().aspectOn, v -> c().aspectOn = v,
                () -> {
                    List<Rows.Row> l = new ArrayList<>();
                    l.add(new Rows.Slider("Ratio", 0.5, 4.0, 0.01, () -> c().aspect,
                            v -> { c().aspect = v; c().aspectOn = true; }, v -> f2(v), null));
                    double[] pr = {16.0 / 9.0, 16.0 / 10.0, 4.0 / 3.0, 21.0 / 9.0, 1.0, 32.0 / 9.0};
                    l.add(new Rows.Buttons(new String[]{"16:9", "16:10", "4:3", "21:9", "1:1", "32:9"}, i -> {
                        c().aspect = pr[i];
                        c().aspectOn = true;
                    }));
                    l.add(new Rows.Buttons(new String[]{"-0.05", "+0.05", "Reset"}, i -> {
                        if (i == 0) c().aspect = Math.max(0.5, c().aspect - 0.05);
                        if (i == 1) c().aspect = Math.min(4.0, c().aspect + 0.05);
                        if (i == 2) c().aspect = 16.0 / 9.0;
                        c().aspectOn = true;
                    }));
                    l.add(new Rows.Label("Changes the world view only, HUD stays native."));
                    return l;
                });

        add(Category.MISC, "rmbopen", "Open on right click", "Right click with empty hands on air opens this menu",
                () -> c().openOnRightClick, v -> c().openOnRightClick = v,
                Modules::none);
    }
}
