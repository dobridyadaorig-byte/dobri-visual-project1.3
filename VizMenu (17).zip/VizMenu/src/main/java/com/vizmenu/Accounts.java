package com.vizmenu;

import net.minecraft.client.MinecraftClient;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.util.Optional;
import java.util.UUID;

/**
 * Offline account switcher: replaces the client's session with an offline one (nickname only).
 * Works for singleplayer and offline-mode servers. Licensed servers will not accept it.
 * Reflection is used on purpose: no class names are written as strings, so it survives remapping.
 */
public final class Accounts {
    private static Object original;
    private static String originalName = "";
    private static boolean applied = false;

    private Accounts() {}

    public static String currentName() {
        try {
            return MinecraftClient.getInstance().getSession().getUsername();
        } catch (Throwable t) {
            return "?";
        }
    }

    public static String originalName() {
        captureOriginal();
        return originalName;
    }

    private static void captureOriginal() {
        if (original != null) return;
        try {
            original = MinecraftClient.getInstance().getSession();
            originalName = MinecraftClient.getInstance().getSession().getUsername();
        } catch (Throwable ignored) {
        }
    }

    public static boolean validName(String n) {
        return n != null && n.matches("[A-Za-z0-9_]{3,16}");
    }

    /** Applies the account saved in the config once after startup. */
    public static void applySavedOnce() {
        if (applied) return;
        applied = true;
        captureOriginal();
        String n = Config.I.lastAccount;
        if (Config.I.accountAutoApply && n != null && validName(n)) useOffline(n);
    }

    public static boolean useOffline(String name) {
        if (!validName(name)) return false;
        captureOriginal();
        try {
            Object cur = MinecraftClient.getInstance().getSession();
            Class<?> sc = cur.getClass();
            Constructor<?> best = null;
            for (Constructor<?> k : sc.getDeclaredConstructors()) {
                if (best == null || k.getParameterCount() > best.getParameterCount()) best = k;
            }
            if (best == null) return false;
            UUID uuid = UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8));
            Class<?>[] pt = best.getParameterTypes();
            Object[] args = new Object[pt.length];
            int strings = 0;
            for (int i = 0; i < pt.length; i++) {
                Class<?> t = pt[i];
                if (t == String.class) {
                    args[i] = strings++ == 0 ? name : "";
                } else if (t == UUID.class) {
                    args[i] = uuid;
                } else if (t == Optional.class) {
                    args[i] = Optional.empty();
                } else if (t.isEnum()) {
                    Object[] cs = t.getEnumConstants();
                    Object pick = cs.length > 0 ? cs[0] : null;
                    for (Object o : cs) {
                        if (String.valueOf(o).equalsIgnoreCase("MOJANG")) pick = o;
                    }
                    args[i] = pick;
                } else {
                    args[i] = null;
                }
            }
            best.setAccessible(true);
            Object fresh = best.newInstance(args);
            if (!setSession(fresh, sc)) return false;
            Config.I.lastAccount = name;
            Config.I.accountAutoApply = true;
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    public static boolean restoreOriginal() {
        captureOriginal();
        if (original == null) return false;
        boolean ok = setSession(original, original.getClass());
        if (ok) {
            Config.I.lastAccount = "";
            Config.I.accountAutoApply = false;
        }
        return ok;
    }

    private static boolean setSession(Object session, Class<?> sessionClass) {
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            for (Field f : MinecraftClient.class.getDeclaredFields()) {
                if (f.getType() == sessionClass) {
                    f.setAccessible(true);
                    f.set(mc, session);
                    return true;
                }
            }
        } catch (Throwable ignored) {
        }
        return false;
    }
}
