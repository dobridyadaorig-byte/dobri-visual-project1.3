package com.vizmenu;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/** Client name, version and the animated gradient wordmark. */
public final class Brand {
    public static final String NAME = "DobriVisual";
    private static final String[] CH = new String[NAME.length()];
    private static String version;

    static {
        for (int i = 0; i < NAME.length(); i++) CH[i] = String.valueOf(NAME.charAt(i));
    }

    private Brand() {}

    public static String version() {
        if (version == null) {
            try {
                version = "v" + FabricLoader.getInstance().getModContainer("vizmenu").get()
                        .getMetadata().getVersion().getFriendlyString();
            } catch (Exception e) {
                version = "";
            }
        }
        return version;
    }

    public static int lerp(int a, int b, float t) {
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        int r = Math.round(ar + (br - ar) * t);
        int g = Math.round(ag + (bg - ag) * t);
        int bl = Math.round(ab + (bb - ab) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    /** Draws "DobriVisual" letter by letter with a purple to pink gradient. */
    public static void drawName(DrawContext ctx, TextRenderer f, int x, int y, boolean animated, boolean shadow) {
        double ph = animated ? System.currentTimeMillis() / 600.0 : 0.0;
        int cx = x;
        for (int i = 0; i < CH.length; i++) {
            float k = animated ? (float) (0.5 + 0.5 * Math.sin(ph - i * 0.6)) : i / (float) (CH.length - 1);
            ctx.drawText(f, CH[i], cx, y, lerp(0xFF000000 | Config.I.wmCol1, 0xFF000000 | Config.I.wmCol2, k), shadow);
            cx += f.getWidth(CH[i]);
        }
    }

    public static int nameWidth(TextRenderer f) {
        return f.getWidth(NAME);
    }
}
