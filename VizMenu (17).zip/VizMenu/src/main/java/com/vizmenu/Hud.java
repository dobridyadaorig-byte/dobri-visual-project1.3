package com.vizmenu;

import com.vizmenu.ui.Theme;
import com.vizmenu.ui.Ui;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** All HUD elements. Strings are cached so almost nothing is allocated per frame. */
public final class Hud {
    private static final String[] ROMAN = {"", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
    private static final EquipmentSlot[] SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };

    private static final String[] LINES = new String[4];
    private static final int[] COLS = new int[4];

    // watermark: fps + coordinates
    private static int fpsLast = -1;
    private static String fpsStr = "";
    private static long coordKey = Long.MIN_VALUE;
    private static String coordStr = "";

    // cps
    private static final long[] CLICKS = new long[128];
    private static int clickHead = 0, clickCount = 0;
    private static boolean mouseWas = false;
    private static int cpsLast = -1;
    private static String cpsStr = "";

    // target
    private static int hpLast = Integer.MIN_VALUE;
    private static String hpStr = "";
    private static LivingEntity target;
    private static long targetTime;

    // potions
    private static final class Fx {
        String base = "", name = "", time = "";
        Identifier icon;
        int amp = -1, sec = -3, max = 0, frame = 0;
    }
    private static final Map<Object, Fx> FX_CACHE = new HashMap<>();
    private static final List<StatusEffectInstance> FX_LIST = new ArrayList<>();
    private static int frameId = 0;

    // armor
    private static final ItemStack[] ARM = new ItemStack[4];

    private Hud() {}

    public static void render(DrawContext ctx, RenderTickCounter tc) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        Config c = Config.I;
        if (!(c.misty || c.watermark || c.crosshair || c.cps || c.targetInfo
                || c.potionHud || c.armorHud || c.jumpCircle || c.trail || c.sky || c.esp || c.killFx)) return;
        float td = tc.getTickProgress(false);
        Proj.beginFrame();
        Ui.begin(mc);
        if (c.sky) Sky.render(ctx, mc, c, td);
        if (c.misty) misty(ctx, mc, c, td);
        Effects.render(ctx, mc, c, td);
        if (c.cps) trackClicks(mc);
        if (c.watermark) watermark(ctx, mc, c);
        if (c.crosshair) crosshair(ctx, mc, c);
        if (c.cps) cps(ctx, mc, c);
        if (c.targetInfo) target(ctx, mc, c);
        if (c.potionHud) potions(ctx, mc, c);
        if (c.armorHud) armor(ctx, mc, c);
    }

    // ------------------------------------------------------------ helpers
    private static void begin(DrawContext ctx, Config.HudBox b, int w, int h) {
        float s = (float) b.scale;
        int sw = ctx.getScaledWindowWidth();
        int sh = ctx.getScaledWindowHeight();
        int x = Math.round((sw - w * s) * (float) (b.x / 100.0));
        int y = Math.round((sh - h * s) * (float) (b.y / 100.0));
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate((float) x, (float) y);
        ctx.getMatrices().scale(s, s);
    }

    private static void end(DrawContext ctx) {
        ctx.getMatrices().popMatrix();
    }

    private static void textBox(DrawContext ctx, TextRenderer f, Config.HudBox b, int n) {
        int w = 0;
        for (int i = 0; i < n; i++) w = Math.max(w, f.getWidth(LINES[i]));
        w += 14;
        int h = n * 11 + 5;
        begin(ctx, b, w, h);
        if (b.bg) {
            Ui.rr(ctx, 0, 0, w, h, 7, 0xC0121316);
            Ui.rr(ctx, 4, 5, 2, h - 10, 1, Theme.accent());
        }
        for (int i = 0; i < n; i++) {
            ctx.drawText(f, LINES[i], 10, 3 + i * 11, COLS[i], true);
        }
        end(ctx);
    }

    private static String time(int ticks) {
        int s = Math.max(0, ticks / 20);
        if (s < 60) return s + "s";
        return (s / 60) + ":" + (s % 60 < 10 ? "0" : "") + (s % 60);
    }

    private static String num(double v, int dec) {
        if (dec == 0) return Integer.toString((int) Math.floor(v));
        long m = dec == 1 ? 10L : 100L;
        long r = Math.round(v * m);
        long a = Math.abs(r);
        long frac = a % m;
        String fs = dec == 2 && frac < 10 ? "0" + frac : Long.toString(frac);
        return (r < 0 ? "-" : "") + (a / m) + "." + fs;
    }

    private static int argb(int a, int rgb) {
        return (Math.max(0, Math.min(255, a)) << 24) | (rgb & 0xFFFFFF);
    }

    // ---------------------------------------------------------- watermark
    private static String coordText(MinecraftClient mc, Config c) {
        double px = mc.player.getX(), py = mc.player.getY(), pz = mc.player.getZ();
        int dec = Math.max(0, Math.min(2, c.coordsDecimals));
        long m = dec == 0 ? 1L : (dec == 1 ? 10L : 100L);
        long key = (long) Math.floor(px * m) * 73856093L ^ (long) Math.floor(py * m) * 19349663L
                ^ (long) Math.floor(pz * m) * 83492791L ^ dec;
        if (key != coordKey) {
            coordKey = key;
            coordStr = num(px, dec) + "  " + num(py, dec) + "  " + num(pz, dec);
        }
        return coordStr;
    }

    private static void watermark(DrawContext ctx, MinecraftClient mc, Config c) {
        TextRenderer f = mc.textRenderer;
        final int h = 24;
        final int logoH = 17;
        double logoW = Logo.widthFor(logoH);
        int nameW = Brand.nameWidth(f);
        String ver = c.wmVersion ? Brand.version() : "";

        String fpsS = null;
        int fpsCol = 0;
        if (c.wmFps) {
            int fps = mc.getCurrentFps();
            if (fps != fpsLast) {
                fpsLast = fps;
                fpsStr = fps + " FPS";
            }
            fpsS = fpsStr;
            fpsCol = fps >= 60 ? 0xFF7CFC9A : (fps >= 30 ? 0xFFFFD866 : 0xFFFF6B6B);
        }
        String coordS = c.wmCoords ? coordText(mc, c) : null;

        double w = 10 + (c.wmLogo ? logoW + 7 : 0) + nameW
                + (ver.isEmpty() ? 0 : f.getWidth(ver) + 6)
                + (fpsS != null ? 13 + f.getWidth(fpsS) : 0)
                + (coordS != null ? 13 + f.getWidth(coordS) : 0) + 12;

        begin(ctx, c.wmBox, (int) Math.ceil(w), h);
        if (c.wmBox.bg) {
            Ui.rr(ctx, -1, -1, w + 2, h + 2, h / 2.0 + 1, argb(0x70, c.wmCol1));
            Ui.rr(ctx, 0, 0, w, h, h / 2.0, 0xE80E0E13);
        }
        double x = 10;
        if (c.wmLogo) {
            Logo.draw(ctx, x, (h - logoH) / 2.0, logoH, Ui.sf);
            x += logoW + 7;
        }
        int ty = (h - 8) / 2;
        Brand.drawName(ctx, f, (int) x, ty, c.wmAnim, true);
        x += nameW;
        if (!ver.isEmpty()) {
            x += 6;
            ctx.drawText(f, ver, (int) x, ty, 0xFF8B8C98, false);
            x += f.getWidth(ver);
        }
        if (fpsS != null) {
            x += 6;
            ctx.fill((int) x, 7, (int) x + 1, h - 7, 0x38FFFFFF);
            x += 7;
            ctx.drawText(f, fpsS, (int) x, ty, fpsCol, false);
            x += f.getWidth(fpsS);
        }
        if (coordS != null) {
            x += 6;
            ctx.fill((int) x, 7, (int) x + 1, h - 7, 0x38FFFFFF);
            x += 7;
            ctx.drawText(f, coordS, (int) x, ty, 0xFFE9E9F0, false);
        }
        end(ctx);
    }

    // ---------------------------------------------------------------- CPS
    private static void trackClicks(MinecraftClient mc) {
        boolean down = mc.currentScreen == null
                && GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        if (down && !mouseWas) {
            CLICKS[clickHead] = System.currentTimeMillis();
            clickHead = (clickHead + 1) & 127;
            if (clickCount < 128) clickCount++;
        }
        mouseWas = down;
    }

    private static void cps(DrawContext ctx, MinecraftClient mc, Config c) {
        long now = System.currentTimeMillis();
        int n = 0;
        for (int i = 0; i < clickCount; i++) {
            if (now - CLICKS[i] <= 1000L) n++;
        }
        if (n != cpsLast) {
            cpsLast = n;
            cpsStr = "CPS  " + n;
        }
        LINES[0] = cpsStr;
        COLS[0] = 0xFFFFFFFF;
        textBox(ctx, mc.textRenderer, c.cpsBox, 1);
    }

    // ------------------------------------------------------------- target
    private static void target(DrawContext ctx, MinecraftClient mc, Config c) {
        long now = System.currentTimeMillis();
        HitResult h = mc.crosshairTarget;
        if (h instanceof EntityHitResult e && e.getEntity() instanceof LivingEntity le) {
            target = le;
            targetTime = now;
        }
        if (target == null || target.isRemoved() || !target.isAlive() || now - targetTime > 1500L) {
            target = null;
            return;
        }
        TextRenderer f = mc.textRenderer;
        String name = target.getName().getString();
        float hp = target.getHealth();
        float max = Math.max(1f, target.getMaxHealth());
        float frac = Math.max(0f, Math.min(1f, hp / max));
        int hpKey = Math.round(hp * 10f) * 100003 + Math.round(max * 10f) + (c.targetNumber ? 1 : 0);
        if (hpKey != hpLast) {
            hpLast = hpKey;
            hpStr = c.targetNumber ? (Math.round(hp * 10f) / 10f) + " / " + (Math.round(max * 10f) / 10f) : "";
        }

        int w = Math.max(104, f.getWidth(name) + 18);
        int hgt = 14 + 10 + (c.targetNumber ? 11 : 0);
        begin(ctx, c.targetBox, w, hgt);
        if (c.targetBox.bg) {
            Ui.rr(ctx, 0, 0, w, hgt, 8, 0xC0121316);
        }
        ctx.drawText(f, name, 9, 4, 0xFFFFFFFF, true);
        int col = frac > 0.5f ? 0xFF7CFC9A : (frac > 0.25f ? 0xFFFFD866 : 0xFFFF6B6B);
        Ui.rr(ctx, 9, 16, w - 18, 4, 2, 0xFF2A2B33);
        if (frac > 0.01f) Ui.rr(ctx, 9, 16, (w - 18) * frac, 4, 2, col);
        if (c.targetNumber) ctx.drawText(f, hpStr, 9, 24, 0xFFB4B4C0, false);
        end(ctx);
    }

    // ------------------------------------------------------------ potions
    private static void potions(DrawContext ctx, MinecraftClient mc, Config c) {
        FX_LIST.clear();
        for (StatusEffectInstance e : mc.player.getStatusEffects()) {
            if (e.shouldShowIcon()) FX_LIST.add(e);
        }
        if (FX_LIST.isEmpty()) {
            FX_CACHE.clear();
            return;
        }
        frameId++;
        TextRenderer f = mc.textRenderer;
        boolean icons = c.potionIcons;
        int rowW = icons ? 138 : 104;
        int rowH = icons ? 34 : 16;
        int gap = icons ? 4 : 3;
        int count = FX_LIST.size();
        int totalH = count * (rowH + gap) - gap;
        boolean blink = (System.currentTimeMillis() / 250L) % 2L == 0L;

        begin(ctx, c.potionBox, rowW, totalH);
        for (int i = 0; i < count; i++) {
            StatusEffectInstance e = FX_LIST.get(i);
            Object key = e.getEffectType();
            Fx fx = FX_CACHE.get(key);
            if (fx == null) {
                fx = new Fx();
                fx.base = e.getEffectType().value().getName().getString();
                var rk = e.getEffectType().getKey();
                Identifier id = rk.isPresent() ? rk.get().getValue() : Identifier.of("minecraft", "speed");
                fx.icon = Identifier.of(id.getNamespace(), "mob_effect/" + id.getPath());
                FX_CACHE.put(key, fx);
            }
            fx.frame = frameId;

            int amp = e.getAmplifier();
            if (amp != fx.amp) {
                fx.amp = amp;
                fx.name = fx.base + (amp > 0 ? " " + ROMAN[Math.min(amp, ROMAN.length - 1)] : "");
            }
            int dur = e.getDuration();
            fx.max = Math.max(fx.max, dur);
            int sec = e.isInfinite() ? -2 : dur / 20;
            if (sec != fx.sec) {
                fx.sec = sec;
                fx.time = e.isInfinite() ? "\u221E" : time(dur);
            }
            float frac = e.isInfinite() ? 1f : Math.min(1f, dur / (float) Math.max(1, fx.max));
            int effectRgb = e.getEffectType().value().getColor() & 0xFFFFFF;
            int barRgb = c.potionBarEffect ? effectRgb : (c.potionBarCol & 0xFFFFFF);
            boolean low = !e.isInfinite() && dur < 200;
            int tcol = low ? ((dur < 100 && !blink) ? 0xFF7A2E2E : 0xFFFF5555) : 0xFFE9E9F0;

            int ry = i * (rowH + gap);
            if (icons) {
                Ui.rr(ctx, 0, ry, rowW, rowH, 9, 0xB8121316);
                ctx.drawGuiTexture(RenderPipelines.GUI_TEXTURED, fx.icon, 8, ry + 8, 18, 18);
                ctx.drawText(f, fx.name, 33, ry + 5, 0xFFFFFFFF, true);
                ctx.drawText(f, fx.time, 33, ry + 15, tcol, false);
                if (c.potionBars) {
                    Ui.rr(ctx, 33, ry + 26, rowW - 41, 4, 2, 0xFF2A2B33);
                    if (frac > 0.01f) Ui.rr(ctx, 33, ry + 26, (rowW - 41) * frac, 4, 2, 0xFF000000 | barRgb);
                }
            } else {
                Ui.rr(ctx, 0, ry, rowW, rowH, 6, 0xC0121316);
                ctx.fill(3, ry + 4, 5, ry + rowH - 4, 0xFF000000 | effectRgb);
                ctx.drawText(f, fx.name, 9, ry + 4, 0xFFFFFFFF, true);
                ctx.drawText(f, fx.time, rowW - 7 - f.getWidth(fx.time), ry + 4, tcol, false);
                if (c.potionBars && frac > 0.01f) {
                    Ui.rr(ctx, 9, ry + rowH - 3, (rowW - 18) * frac, 2, 1, 0xFF000000 | barRgb);
                }
            }
        }
        end(ctx);
        if (FX_CACHE.size() != count) FX_CACHE.values().removeIf(x -> x.frame != frameId);
    }

    // -------------------------------------------------------------- armor
    private static void armor(DrawContext ctx, MinecraftClient mc, Config c) {
        int n = 0;
        for (EquipmentSlot sl : SLOTS) {
            ItemStack is = mc.player.getEquippedStack(sl);
            if (!is.isEmpty()) ARM[n++] = is;
        }
        if (n == 0) return;

        TextRenderer f = mc.textRenderer;
        boolean vert = c.armorVertical;
        boolean text = c.armorDurability != 0;
        int gap = 3;
        int cw = vert ? 22 + (text ? 34 : 0) : (text ? 30 : 22);
        int ch = vert ? 22 : 22 + (text ? 11 : 0);
        int totalW = vert ? cw : n * cw + (n - 1) * gap;
        int totalH = vert ? n * ch + (n - 1) * gap : ch;

        begin(ctx, c.armorBox, totalW, totalH);
        for (int i = 0; i < n; i++) {
            ItemStack is = ARM[i];
            int cx = vert ? 0 : i * (cw + gap);
            int cy = vert ? i * (ch + gap) : 0;
            if (c.armorBox.bg) Ui.rr(ctx, cx, cy, cw, ch, 7, 0xB0121316);
            int ix = vert ? cx + 3 : cx + (cw - 16) / 2;
            ctx.drawItem(is, ix, cy + 3);

            if (text && is.isDamageable()) {
                int max = is.getMaxDamage();
                int left = max - is.getDamage();
                String t = c.armorDurability == 2
                        ? Math.round(left * 100f / Math.max(1, max)) + "%"
                        : Integer.toString(left);
                int col = 0xFF000000 | (is.getItemBarColor() & 0xFFFFFF);
                if (vert) {
                    ctx.drawText(f, t, cx + 25, cy + 7, col, true);
                } else {
                    ctx.drawText(f, t, cx + (cw - f.getWidth(t)) / 2, cy + 23, col, true);
                }
            }
        }
        end(ctx);
        for (int i = 0; i < n; i++) ARM[i] = null;
    }

    // ------------------------------------------------------------------ misty
    private static void misty(DrawContext ctx, MinecraftClient mc, Config c, float td) {
        if (mc.currentScreen != null) return;
        int sw = ctx.getScaledWindowWidth();
        int sh = ctx.getScaledWindowHeight();
        int rgb;
        switch (c.mistStyle) {
            case 1 -> rgb = 0x9CC4FF;
            case 2 -> rgb = 0xB89CFF;
            case 3 -> rgb = 0xFFD9B0;
            case 4 -> rgb = c.mistCol & 0xFFFFFF;
            default -> rgb = 0xDDE6F2;
        }
        float k = (float) c.mistStrength;

        float pitch = CameraControl.pitch(mc.player.getPitch(td));
        double tanHalf = Math.tan(Math.toRadians(Proj.fovDegrees(mc)) / 2.0);
        double horizon = sh / 2.0 - Math.tan(Math.toRadians(pitch)) / tanHalf * (sh / 2.0);
        int hy = (int) Math.max(-sh * 0.3, Math.min(sh * 1.3, horizon));
        int band = (int) (sh * 0.32);
        int aMax = (int) (150 * k);

        ctx.fill(0, 0, sw, sh, argb((int) (26 * k), rgb));
        ctx.fillGradient(0, hy - band, sw, hy, argb(0, rgb), argb(aMax, rgb));
        ctx.fillGradient(0, hy, sw, hy + band, argb(aMax, rgb), argb(0, rgb));

        int eh = (int) (sh * 0.22);
        ctx.fillGradient(0, 0, sw, eh, argb((int) (70 * k), rgb), argb(0, rgb));
        ctx.fillGradient(0, sh - eh, sw, sh, argb(0, rgb), argb((int) (70 * k), rgb));

        if (c.mistWisps) {
            long now = System.currentTimeMillis();
            int slices = 14;
            for (int i = 0; i < 6; i++) {
                double speed = 14000.0 + i * 2300.0;
                double u = ((now / speed + i * 0.37) % 1.5) - 0.25;
                int wcx = (int) (u * sw);
                int ww = (int) (sw * (0.38 + 0.08 * (i % 3)));
                if (wcx + ww / 2 < 0 || wcx - ww / 2 > sw) continue;
                int wy = hy + (int) ((i - 2.5) * sh * 0.04 + Math.sin(now / 3200.0 + i) * sh * 0.01);
                int wh = (int) (sh * 0.05);
                int peak = (int) (80 * k);
                int sliceW = Math.max(1, ww / slices);
                for (int sIdx = 0; sIdx < slices; sIdx++) {
                    double uu = (sIdx + 0.5) / slices;
                    double bell = Math.sin(Math.PI * uu);
                    int a = (int) (peak * bell * bell);
                    if (a <= 0) continue;
                    int x0 = wcx - ww / 2 + sIdx * sliceW;
                    if (x0 + sliceW < 0 || x0 > sw) continue;
                    ctx.fillGradient(x0, wy - wh, x0 + sliceW, wy, argb(0, rgb), argb(a, rgb));
                    ctx.fillGradient(x0, wy, x0 + sliceW, wy + wh, argb(a, rgb), argb(0, rgb));
                }
            }
        }
    }

    // ----------------------------------------------------------- crosshair
    private static void ring(DrawContext ctx, int cx, int cy, int ri, int ro, int col) {
        for (int dy = -ro; dy <= ro; dy++) {
            int ho = (int) Math.round(Math.sqrt(Math.max(0, ro * ro - dy * dy)));
            if (Math.abs(dy) < ri) {
                int hi = (int) Math.round(Math.sqrt(ri * ri - dy * dy));
                ctx.fill(cx - ho, cy + dy, cx - hi, cy + dy + 1, col);
                ctx.fill(cx + hi, cy + dy, cx + ho, cy + dy + 1, col);
            } else {
                ctx.fill(cx - ho, cy + dy, cx + ho, cy + dy + 1, col);
            }
        }
    }

    private static void crosshair(DrawContext ctx, MinecraftClient mc, Config c) {
        if (mc.currentScreen != null || !mc.options.getPerspective().isFirstPerson()) return;
        int cx = ctx.getScaledWindowWidth() / 2;
        int cy = ctx.getScaledWindowHeight() / 2;

        int rgb;
        if (c.chTargetRed && mc.crosshairTarget instanceof EntityHitResult) {
            rgb = 0xFF5555;
        } else if (c.chColorMode == 1) {
            rgb = c.chColor & 0xFFFFFF;
        } else if (c.chColorMode == 2) {
            rgb = MathHelper.hsvToRgb((System.currentTimeMillis() % 4000L) / 4000f, 0.85f, 1f) & 0xFFFFFF;
        } else {
            rgb = 0xFFFFFF;
        }
        int a = Math.max(20, Math.min(255, (int) Math.round(c.chAlpha * 255.0)));
        int col = (a << 24) | rgb;
        int dark = (Math.round(a * 0.8f) << 24);

        int size = (int) c.chSize;
        int th = (int) c.chThick;
        int gap = (int) c.chGap;
        if (c.chDynamic) {
            net.minecraft.util.math.Vec3d v = mc.player.getVelocity();
            gap += (int) Math.min(6, Math.sqrt(v.x * v.x + v.z * v.z) * 25.0) + (mc.player.isOnGround() ? 0 : 3);
        }
        int lo = th / 2;

        int style = c.chStyle;
        boolean bars = style == 0 || style == 3;
        boolean dot = style == 1 || style == 3;
        boolean circle = style == 2;

        for (int pass = 0; pass < 2; pass++) {
            boolean outlinePass = pass == 0;
            if (outlinePass && !c.chOutline) continue;
            int e = outlinePass ? 1 : 0;
            int color = outlinePass ? dark : col;
            if (bars) {
                ctx.fill(cx - gap - size - e, cy - lo - e, cx - gap + e, cy - lo + th + e, color);
                ctx.fill(cx + gap - e, cy - lo - e, cx + gap + size + e, cy - lo + th + e, color);
                ctx.fill(cx - lo - e, cy - gap - size - e, cx - lo + th + e, cy - gap + e, color);
                ctx.fill(cx - lo - e, cy + gap - e, cx - lo + th + e, cy + gap + size + e, color);
            }
            if (dot) {
                int d = Math.max(1, th);
                ctx.fill(cx - d / 2 - e, cy - d / 2 - e, cx - d / 2 + d + e, cy - d / 2 + d + e, color);
            }
            if (circle) {
                int r = Math.max(2, size);
                ring(ctx, cx, cy, Math.max(0, r - e), r + th + e, color);
            }
        }
    }
}
