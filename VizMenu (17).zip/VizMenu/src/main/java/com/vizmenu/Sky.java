package com.vizmenu;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

import java.util.Random;

/**
 * Custom sky drawn over the picture: night tint, stars, galaxy and aurora.
 * A terrain "horizon profile" (max elevation of the terrain per compass direction) keeps the sky
 * from being drawn on top of hills and buildings.
 */
public final class Sky {
    private static final int BINS = 72;
    private static final double[] HORIZON = new double[BINS];
    private static final double[] DIST = {3, 4, 5, 6, 8, 10, 12, 15, 18, 22, 27, 33, 40, 48, 57, 68, 80, 95, 112, 128, 145, 160};
    private static int tickCounter = 0;
    private static double fade = 0.0;

    // stars
    private static final int N_STARS = 1100;
    private static final float[] SX = new float[N_STARS], SY = new float[N_STARS], SZ = new float[N_STARS];
    private static final float[] SM = new float[N_STARS], SP = new float[N_STARS];
    private static final int[] SC = new int[N_STARS];
    // galaxy band
    private static final int N_GAL = 900;
    private static final float[] GX = new float[N_GAL], GY = new float[N_GAL], GZ = new float[N_GAL], GM = new float[N_GAL];
    private static final float[][] BLOBS = new float[6][4]; // x, y, z, angular radius
    private static final int[] BLOB_RGB = {0x7C3AED, 0x2563EB, 0xDB2777, 0x0EA5E9, 0x9333EA, 0x14B8A6};

    // shooting star
    private static long nextShoot = 0L, shootT0 = 0L;
    private static double shAz, shEl, shDAz, shDEl;

    private static final double[] DIR = new double[3];
    private static final double[] PT = new double[3];
    private static final Random RND = new Random();

    static {
        Random r = new Random(42L);
        for (int i = 0; i < N_STARS; i++) {
            double z = r.nextDouble() * 2.0 - 1.0;
            double phi = r.nextDouble() * Math.PI * 2.0;
            double rr = Math.sqrt(1.0 - z * z);
            SX[i] = (float) (rr * Math.cos(phi));
            SY[i] = (float) z;
            SZ[i] = (float) (rr * Math.sin(phi));
            double m = r.nextDouble();
            SM[i] = (float) (0.25 + 0.75 * m * m);
            SP[i] = (float) (r.nextDouble() * 6.28);
            double ct = r.nextDouble();
            SC[i] = ct < 0.6 ? 0xFFFFFF : (ct < 0.8 ? 0xBFD4FF : (ct < 0.92 ? 0xFFE2B8 : 0xFFC4E8));
        }
        // great circle of the "milky way"
        double nx = 0.35, ny = 0.8, nz = -0.5;
        double nl = Math.sqrt(nx * nx + ny * ny + nz * nz);
        nx /= nl; ny /= nl; nz /= nl;
        double ux = -nz, uy = 0, uz = nx;
        double ul = Math.sqrt(ux * ux + uz * uz);
        ux /= ul; uz /= ul;
        double vx = ny * uz - nz * uy, vy = nz * ux - nx * uz, vz = nx * uy - ny * ux;
        for (int i = 0; i < N_GAL; i++) {
            double a = r.nextDouble() * Math.PI * 2.0;
            double off = r.nextGaussian() * 0.13;
            double x = ux * Math.cos(a) + vx * Math.sin(a) + nx * off;
            double y = uy * Math.cos(a) + vy * Math.sin(a) + ny * off;
            double z = uz * Math.cos(a) + vz * Math.sin(a) + nz * off;
            double l = Math.sqrt(x * x + y * y + z * z);
            GX[i] = (float) (x / l); GY[i] = (float) (y / l); GZ[i] = (float) (z / l);
            double m = r.nextDouble();
            GM[i] = (float) (0.2 + 0.7 * m * m);
        }
        for (int i = 0; i < BLOBS.length; i++) {
            double a = i * (Math.PI * 2.0 / BLOBS.length) + 0.4;
            double off = (r.nextDouble() - 0.5) * 0.12;
            double x = ux * Math.cos(a) + vx * Math.sin(a) + nx * off;
            double y = uy * Math.cos(a) + vy * Math.sin(a) + ny * off;
            double z = uz * Math.cos(a) + vz * Math.sin(a) + nz * off;
            double l = Math.sqrt(x * x + y * y + z * z);
            BLOBS[i][0] = (float) (x / l); BLOBS[i][1] = (float) (y / l); BLOBS[i][2] = (float) (z / l);
            BLOBS[i][3] = (float) (0.14 + r.nextDouble() * 0.16);
        }
    }

    private Sky() {}

    // ===================================================================== tick
    public static void tick(MinecraftClient mc, ClientPlayerEntity p, Config c) {
        if (!c.sky) {
            fade = 0.0;
            return;
        }
        ClientWorld w = mc.world;
        boolean overworld = w.getRegistryKey() == World.OVERWORLD;
        double eye = p.getEyeY();
        boolean roofed = w.getTopY(Heightmap.Type.MOTION_BLOCKING, MathHelper.floor(p.getX()), MathHelper.floor(p.getZ())) > eye + 0.6;
        double target = (overworld && !roofed) ? 1.0 : 0.0;
        fade += (target - fade) * 0.12;
        if (fade < 0.02) return;
        if ((tickCounter++ & 7) == 0) updateHorizon(w, p.getX(), eye, p.getZ());
    }

    private static void updateHorizon(ClientWorld w, double px, double eye, double pz) {
        for (int b = 0; b < BINS; b++) {
            double az = (b + 0.5) / BINS * Math.PI * 2.0 - Math.PI;
            double sx = Math.sin(az), cz = Math.cos(az);
            double best = -0.3;
            for (double d : DIST) {
                int x = MathHelper.floor(px + sx * d), z = MathHelper.floor(pz + cz * d);
                int top = w.getTopY(Heightmap.Type.MOTION_BLOCKING, x, z);
                double el = Math.atan2(top - eye, d);
                if (el > best) best = el;
            }
            HORIZON[b] = best + 0.03;
        }
    }

    private static double horizonAt(double az) {
        double f = (az + Math.PI) / (Math.PI * 2.0) * BINS - 0.5;
        int b0 = (int) Math.floor(f);
        double fr = f - b0;
        int i0 = ((b0 % BINS) + BINS) % BINS;
        int i1 = (i0 + 1) % BINS;
        return HORIZON[i0] * (1.0 - fr) + HORIZON[i1] * fr;
    }

    // =================================================================== helpers
    private static int argb(double a, int rgb) {
        return (Math.max(0, Math.min(255, (int) a)) << 24) | (rgb & 0xFFFFFF);
    }

    private static int lerpArgb(int a, int b, double t) {
        int aa = (a >>> 24), ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int ba = (b >>> 24), br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        return ((int) (aa + (ba - aa) * t) << 24) | ((int) (ar + (br - ar) * t) << 16)
                | ((int) (ag + (bg - ag) * t) << 8) | (int) (ab + (bb - ab) * t);
    }

    private static boolean isSky(double x, double y) {
        Proj.pixelDir(x, y, DIR);
        double az = Math.atan2(DIR[0], DIR[2]);
        double el = Math.asin(MathHelper.clamp(DIR[1], -1.0, 1.0));
        return el > horizonAt(az);
    }

    private static int skyBottom(int x) {
        int h = Proj.fbh;
        if (!isSky(x, 0)) return 0;
        if (isSky(x, h - 1)) return h;
        int lo = 0, hi = h - 1;
        for (int i = 0; i < 9; i++) {
            int mid = (lo + hi) >>> 1;
            if (isSky(x, mid)) lo = mid; else hi = mid;
        }
        return hi;
    }

    // ===================================================================== render
    public static void render(DrawContext ctx, MinecraftClient mc, Config c, float td) {
        if (!c.sky || fade < 0.02 || mc.currentScreen != null) return;
        ClientWorld w = mc.world;
        if (w == null || !Proj.ensure(mc, td)) return;

        double alpha = fade * (1.0 - 0.85 * w.getRainGradient(td));
        if (c.skyNightOnly) {
            long tod = c.timeChanger ? c.timeValue : (w.getTime() % 24000L);
            double nf;
            if (tod >= 13000L && tod <= 23000L) nf = 1.0;
            else if (tod >= 12000L && tod < 13000L) nf = (tod - 12000L) / 1000.0;
            else if (tod > 23000L) nf = 1.0 - (tod - 23000L) / 1000.0;
            else nf = 0.0;
            alpha *= nf;
        }
        if (alpha < 0.02) return;

        long now = System.currentTimeMillis();
        float sf = (float) mc.getWindow().getScaleFactor();
        double theta = (w.getTime() + td) / 24000.0 * Math.PI;
        double cosT = Math.cos(theta), sinT = Math.sin(theta);

        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(1f / sf, 1f / sf);

        if (c.skyTint > 0.01) drawTint(ctx, c, alpha);

        int mode = c.skyMode;
        if (mode == 2) drawGalaxy(ctx, c, alpha, now, cosT, sinT);
        drawStars(ctx, c, alpha, now, cosT, sinT, mode);
        if (mode != 0) drawShootingStar(ctx, alpha, now);
        if (mode == 0) drawAurora(ctx, c, alpha, now);

        ctx.getMatrices().popMatrix();
    }

    private static void drawTint(DrawContext ctx, Config c, double alpha) {
        int stride = Math.max(6, Proj.fbw / 160);
        int topCol = argb(205.0 * c.skyTint * alpha, 0x040716);
        int botCol = argb(150.0 * c.skyTint * alpha, 0x2B1B55);
        int fadeH = Math.max(8, Proj.fbh / 60);
        for (int x = 0; x < Proj.fbw; x += stride) {
            int yb = skyBottom(x + stride / 2);
            if (yb <= 0) continue;
            int x1 = Math.min(Proj.fbw, x + stride);
            int ye = Math.max(0, yb - fadeH);
            int mid = lerpArgb(topCol, botCol, ye / (double) Proj.fbh);
            if (ye > 0) ctx.fillGradient(x, 0, x1, ye, topCol, mid);
            if (yb > ye) ctx.fillGradient(x, ye, x1, yb, mid, mid & 0x00FFFFFF);
        }
    }

    private static void drawStars(DrawContext ctx, Config c, double alpha, long now, double cosT, double sinT, int mode) {
        double factor = mode == 0 ? 0.6 : 1.0;
        int nUse = (int) (N_STARS * MathHelper.clamp(c.skyStars / 2.0 * factor, 0.04, 1.0));
        int unit = Math.max(1, Math.round(Proj.fbh / 700f));
        for (int i = 0; i < nUse; i++) {
            starAt(ctx, SX[i], SY[i], SZ[i], SM[i], SP[i], SC[i], i, alpha, now, cosT, sinT, unit, true);
        }
        if (mode == 2) {
            for (int i = 0; i < N_GAL; i++) {
                starAt(ctx, GX[i], GY[i], GZ[i], GM[i] * 0.85f, i * 0.7f, 0xDDE4FF, i, alpha * 0.8, now, cosT, sinT, unit, false);
            }
        }
    }

    private static void starAt(DrawContext ctx, double x, double y, double z, double mag, double phase, int rgb,
                               int i, double alpha, long now, double cosT, double sinT, int unit, boolean glowAllowed) {
        double y2 = y * cosT - z * sinT;
        double z2 = y * sinT + z * cosT;
        if (y2 < -0.1) return;
        double el = Math.asin(MathHelper.clamp(y2, -1.0, 1.0));
        double hz = horizonAt(Math.atan2(x, z2));
        if (el <= hz) return;
        double edge = MathHelper.clamp((el - hz) / 0.05, 0.0, 1.0);
        if (!Proj.dirToScreen(x, y2, z2, PT)) return;
        double tw = 0.75 + 0.25 * Math.sin(now / (350.0 + (i % 7) * 60.0) + phase);
        double a = alpha * mag * tw * edge;
        if (a < 0.03) return;
        int size = mag > 0.85 ? 3 * unit : (mag > 0.55 ? 2 * unit : unit);
        int px = (int) Math.round(PT[0]) - size / 2, py = (int) Math.round(PT[1]) - size / 2;
        ctx.fill(px, py, px + size, py + size, argb(a * 255.0, rgb));
        if (glowAllowed && mag > 0.9) {
            int len = size * 2;
            int cxp = px + size / 2, cyp = py + size / 2;
            int ga = argb(a * 90.0, rgb);
            ctx.fill(cxp - len, cyp, cxp + len, cyp + 1, ga);
            ctx.fill(cxp, cyp - len, cxp + 1, cyp + len, ga);
        }
    }

    private static void drawGalaxy(DrawContext ctx, Config c, double alpha, long now, double cosT, double sinT) {
        for (int i = 0; i < BLOBS.length; i++) {
            double x = BLOBS[i][0], y = BLOBS[i][1], z = BLOBS[i][2];
            double y2 = y * cosT - z * sinT;
            double z2 = y * sinT + z * cosT;
            double rad = BLOBS[i][3];
            double el = Math.asin(MathHelper.clamp(y2, -1.0, 1.0));
            if (el < horizonAt(Math.atan2(x, z2)) + rad * 0.6) continue;
            if (!Proj.dirToScreen(x, y2, z2, PT)) continue;
            double px = Proj.pxPerRad() * rad / Math.max(0.3, PT[2]);
            double pulse = 0.8 + 0.2 * Math.sin(now / 2600.0 + i);
            int rgb = BLOB_RGB[i % BLOB_RGB.length];
            Proj.disc(ctx, PT[0], PT[1], px * 1.5, argb(alpha * 14.0 * pulse, rgb));
            Proj.disc(ctx, PT[0], PT[1], px, argb(alpha * 22.0 * pulse, rgb));
            Proj.disc(ctx, PT[0], PT[1], px * 0.5, argb(alpha * 28.0 * pulse, rgb));
        }
    }

    private static void drawShootingStar(DrawContext ctx, double alpha, long now) {
        if (now > nextShoot) {
            shootT0 = now;
            nextShoot = now + 5000L + RND.nextInt(6000);
            shAz = RND.nextDouble() * Math.PI * 2.0 - Math.PI;
            shEl = 0.5 + RND.nextDouble() * 0.7;
            double dir = RND.nextDouble() * Math.PI * 2.0;
            shDAz = Math.cos(dir) * 0.5;
            shDEl = Math.sin(dir) * 0.35 - 0.15;
        }
        double t = (now - shootT0) / 800.0;
        if (t < 0.0 || t > 1.0) return;
        double px = 0, py = 0;
        boolean prev = false;
        int th = Math.max(2, Proj.fbh / 500);
        for (int k = 0; k <= 8; k++) {
            double tt = t - k * 0.025;
            if (tt < 0.0) break;
            double az = shAz + shDAz * tt;
            double el = shEl + shDEl * tt;
            if (el < horizonAt(az) + 0.04) {
                prev = false;
                continue;
            }
            double ce = Math.cos(el);
            boolean ok = Proj.dirToScreen(Math.sin(az) * ce, Math.sin(el), Math.cos(az) * ce, PT);
            if (ok && prev) {
                double a = alpha * (1.0 - k / 9.0) * Math.sin(Math.PI * t);
                Proj.line(ctx, px, py, PT[0], PT[1], th * 2, argb(a * 70.0, 0xBFD4FF));
                Proj.line(ctx, px, py, PT[0], PT[1], th, argb(a * 255.0, 0xFFFFFF));
            }
            px = PT[0];
            py = PT[1];
            prev = ok;
        }
    }

    private static void drawAurora(DrawContext ctx, Config c, double alpha, long now) {
        int bottomRgb, topRgb;
        switch (c.skyAurora) {
            case 1 -> { bottomRgb = 0x34D5FF; topRgb = 0x6C7BFF; }
            case 2 -> { bottomRgb = 0xFF6BD6; topRgb = 0x7A5CFF; }
            case 3 -> { bottomRgb = c.auroraBottom & 0xFFFFFF; topRgb = c.auroraTop & 0xFFFFFF; }
            default -> { bottomRgb = 0x3CFF9E; topRgb = 0x9A6BFF; }
        }
        double t = now / 1000.0;
        int rays = 96;
        int wpx = Math.max(3, (int) (Proj.fbw * 0.012));
        double az0 = Math.PI + 0.3 * Math.sin(t / 20.0);
        for (int i = 0; i < rays; i++) {
            double u = i / (double) (rays - 1) * 2.0 - 1.0;
            double az = az0 + u * 1.05 + 0.12 * Math.sin(u * 3.0 + t * 0.25);
            double e0 = 0.20 + 0.06 * Math.sin(u * 2.3 + t * 0.35);
            double hgt = 0.35 + 0.18 * (0.5 + 0.5 * Math.sin(u * 4.1 - t * 0.5));
            double inten = (0.55 + 0.45 * Math.sin(i * 0.9 + t * 1.7)) * (0.6 + 0.4 * Math.sin(u * 5.0 + t * 0.8));
            inten = Math.max(0.0, inten);
            double hz = horizonAt(az) + 0.03;
            double eb = Math.max(e0, hz);
            double et = e0 + hgt;
            if (eb >= et || inten < 0.05) continue;

            double cb = Math.cos(eb), ct = Math.cos(et);
            if (!Proj.dirToScreen(Math.sin(az) * cb, Math.sin(eb), Math.cos(az) * cb, PT)) continue;
            double xb = PT[0], yb = PT[1];
            if (!Proj.dirToScreen(Math.sin(az) * ct, Math.sin(et), Math.cos(az) * ct, PT)) continue;
            double xt = PT[0], yt = PT[1];
            if (yt >= yb) continue;
            int xm = (int) Math.round((xb + xt) * 0.5);
            int y1 = (int) Math.round(yt), y2 = (int) Math.round(yb);
            double a = alpha * inten;
            ctx.fillGradient(xm - wpx * 2, y1, xm + wpx * 2, y2, argb(0, topRgb), argb(a * 55.0, bottomRgb));
            ctx.fillGradient(xm - wpx / 2, y1, xm + wpx / 2 + 1, y2, argb(0, topRgb), argb(a * 170.0, bottomRgb));
        }
    }
}
