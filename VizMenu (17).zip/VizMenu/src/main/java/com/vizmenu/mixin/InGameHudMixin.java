package com.vizmenu.mixin;

import com.vizmenu.Config;
import net.minecraft.client.gui.hud.InGameHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public abstract class InGameHudMixin {

    @Inject(method = "renderStatusEffectOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private void viz$hideVanillaEffects(CallbackInfo ci) {
        if (Config.I.potionHud && Config.I.potionHideVanilla) ci.cancel();
    }

    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true, require = 0)
    private void viz$hideVanillaCrosshair(CallbackInfo ci) {
        if (Config.I.crosshair) ci.cancel();
    }

    @Inject(method = "renderVignetteOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private void viz$noVignette(CallbackInfo ci) {
        if (Config.I.noRender && Config.I.nrVignette) ci.cancel();
    }

    @Inject(method = "renderPortalOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private void viz$noPortal(CallbackInfo ci) {
        if (Config.I.noRender && Config.I.nrPortal) ci.cancel();
    }

    @Inject(method = "renderScoreboardSidebar", at = @At("HEAD"), cancellable = true, require = 0)
    private void viz$noScoreboard(CallbackInfo ci) {
        if (Config.I.noRender && Config.I.nrScore) ci.cancel();
    }
}
