package com.vizmenu.mixin;

import com.vizmenu.Config;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** NoRender: boss bars. */
@Mixin(targets = "net.minecraft.client.gui.hud.BossBarHud")
public abstract class BossBarMixin {

    @Inject(method = "render", at = @At("HEAD"), cancellable = true, require = 0)
    private void viz$noBossBars(CallbackInfo ci) {
        if (Config.I.noRender && Config.I.nrBoss) ci.cancel();
    }
}
