package com.vizmenu.mixin;

import com.vizmenu.Config;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** NoRender: fire, underwater and inside-block overlays. String target keeps the build safe if the class moves. */
@Mixin(targets = "net.minecraft.client.gui.hud.InGameOverlayRenderer")
public abstract class OverlayRendererMixin {

    @Inject(method = "renderFireOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private static void viz$fire(CallbackInfo ci) {
        if (Config.I.noRender && Config.I.nrFire) ci.cancel();
    }

    @Inject(method = "renderUnderwaterOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private static void viz$water(CallbackInfo ci) {
        if (Config.I.noRender && Config.I.nrWater) ci.cancel();
    }

    @Inject(method = "renderInWallOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private static void viz$wall(CallbackInfo ci) {
        if (Config.I.noRender && Config.I.nrWall) ci.cancel();
    }
}
