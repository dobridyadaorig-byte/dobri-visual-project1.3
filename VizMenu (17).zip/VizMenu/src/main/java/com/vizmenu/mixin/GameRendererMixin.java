package com.vizmenu.mixin;

import com.vizmenu.Config;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {

    @ModifyArg(
            method = "getBasicProjectionMatrix",
            at = @At(value = "INVOKE", target = "Lorg/joml/Matrix4f;perspective(FFFF)Lorg/joml/Matrix4f;"),
            index = 1,
            require = 0
    )
    private float viz$aspect(float aspect) {
        return Config.I.aspectOn ? (float) Config.I.aspect : aspect;
    }

    @Inject(method = "tiltViewWhenHurt", at = @At("HEAD"), cancellable = true, require = 0)
    private void viz$noHurtCam(CallbackInfo ci) {
        if (Config.I.noRender && Config.I.nrHurt) ci.cancel();
    }

    @Inject(method = "showFloatingItem", at = @At("HEAD"), cancellable = true, require = 0)
    private void viz$noTotem(CallbackInfo ci) {
        if (Config.I.noRender && Config.I.nrTotem) ci.cancel();
    }
}
