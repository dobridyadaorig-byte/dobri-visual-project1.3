package com.vizmenu.ui;

import com.vizmenu.Brand;
import com.vizmenu.Config;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Settings menu: sidebar with categories, two columns of rounded module cards, settings expand inside the card. */
public class MenuScreen extends Screen {
    static final int SIDE = 116, TOPH = 48, HEADER = 40, GAP = 8;
    private static Category lastCat = Category.HUD;
    private static final Set<String> EXPANDED = new HashSet<>();

    private final Map<String, List<Rows.Row>> rowCache = new HashMap<>();
    private final List<Card> cards = new ArrayList<>();
    private Category cat = lastCat;
    private Module capturing;
    private Module hovered;
    private String sideHint = "";
    private boolean escGuard;
    private Rows.Row dragging;
    private int scroll = 0;
    private int contentH = 0;

    // geometry shared by render + clicks
    private int px, py, pw, ph, cx, cy, cw, ch;
    private double collapseX, collapseW;
    private double themeCx, accentCx, btnCy;

    public MenuScreen() {
        super(Text.literal("DobriVisual"));
    }

    @Override
    protected void init() {
        build();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return capturing == null && !escGuard;
    }

    @Override
    public void removed() {
        Config.save();
    }

    private void build() {
        cards.clear();
        scroll = 0;
        for (Module m : Modules.ALL) {
            if (m.category == cat) cards.add(new Card(m));
        }
    }

    private List<Rows.Row> rowsOf(Module m) {
        return rowCache.computeIfAbsent(m.id, k -> new ArrayList<>(m.settings.get()));
    }

    private void geometry() {
        pw = Math.min(520, width - 8);
        ph = Math.min(312, height - 8);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        cx = px + SIDE + 12;
        cy = py + TOPH;
        cw = pw - SIDE - 24;
        ch = ph - TOPH - 22;
        btnCy = py + ph - 24;
        themeCx = px + 24;
        accentCx = px + 48;
    }

    private long window() {
        return MinecraftClient.getInstance().getWindow().getHandle();
    }

    /** While binding: the next pressed key becomes the bind. */
    private void pollBind() {
        long w = window();
        if (GLFW.glfwGetKey(w, GLFW.GLFW_KEY_ESCAPE) == GLFW.GLFW_PRESS) {
            capturing = null;
            escGuard = true;
            return;
        }
        if (GLFW.glfwGetKey(w, GLFW.GLFW_KEY_DELETE) == GLFW.GLFW_PRESS
                || GLFW.glfwGetKey(w, GLFW.GLFW_KEY_BACKSPACE) == GLFW.GLFW_PRESS) {
            capturing.setBind(-1);
            capturing = null;
            return;
        }
        for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
            if (k == GLFW.GLFW_KEY_ESCAPE) continue;
            if (GLFW.glfwGetKey(w, k) == GLFW.GLFW_PRESS) {
                for (Module o : Modules.ALL) {
                    if (o != capturing && o.bind() == k) o.setBind(-1);
                }
                capturing.setBind(k);
                capturing = null;
                return;
            }
        }
    }

    // ------------------------------------------------------------ cards
    private final class Card {
        final Module m;
        double x, y, w, h;

        Card(Module m) { this.m = m; }

        boolean expanded() { return EXPANDED.contains(m.id); }

        double height() {
            if (!expanded()) return HEADER;
            double hh = HEADER + 10;
            for (Rows.Row r : rowsOf(m)) hh += r.h + 4;
            return hh + 4;
        }

        void toggleExpand() {
            if (!EXPANDED.remove(m.id)) EXPANDED.add(m.id);
        }
    }

    private void layoutCards() {
        int n = cw >= 300 ? 2 : 1;
        double colW = (cw - GAP * (n - 1)) / (double) n;
        double[] colH = new double[n];
        for (Card cd : cards) {
            int col = 0;
            for (int i = 1; i < n; i++) if (colH[i] < colH[col]) col = i;
            cd.w = colW;
            cd.x = cx + col * (colW + GAP);
            cd.y = cy - scroll + colH[col];
            cd.h = cd.height();
            colH[col] += cd.h + GAP;
            if (cd.expanded()) {
                double ry = cd.y + HEADER + 10;
                for (Rows.Row r : rowsOf(cd.m)) {
                    r.x = (int) Math.round(cd.x + 12);
                    r.y = (int) Math.round(ry);
                    r.w = (int) Math.round(cd.w - 24);
                    ry += r.h + 4;
                }
            }
        }
        double max = 0;
        for (double v : colH) max = Math.max(max, v);
        contentH = (int) max;
    }

    // ---------------------------------------------------------------- render
    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        TextRenderer f = textRenderer;
        Ui.begin(mc);
        geometry();
        if (escGuard && GLFW.glfwGetKey(window(), GLFW.GLFW_KEY_ESCAPE) != GLFW.GLFW_PRESS) escGuard = false;
        if (capturing != null) pollBind();
        layoutCards();
        hovered = null;
        sideHint = "";

        int acc = Theme.accent();
        c.fill(0, 0, width, height, 0x66000000);
        Ui.rr(c, px - 1, py - 1, pw + 2, ph + 2, 15, Theme.border());
        Ui.rr(c, px, py, pw, ph, 14, Theme.window());

        // ---- sidebar
        Ui.rr(c, px + 6, py + 6, SIDE - 4, ph - 12, 11, Theme.sidebar());
        Ui.rr(c, px + 14, py + 14, 18, 18, 6, acc);
        c.drawText(f, "D", px + 20, py + 19, 0xFFFFFFFF, false);
        c.drawText(f, Brand.NAME, px + 38, py + 15, Theme.text(), false);
        String ver = Brand.version();
        if (!ver.isEmpty()) c.drawText(f, ver, px + 38, py + 25, Theme.dim(), false);

        c.drawText(f, "Функции", px + 16, py + 46, Theme.dim(), false);
        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++) {
            double ty = py + 58 + i * 25;
            boolean sel = cats[i] == cat;
            boolean hov = mx >= px + 10 && mx < px + SIDE - 2 && my >= ty && my < ty + 22;
            if (sel) Ui.rr(c, px + 10, ty, SIDE - 12, 22, 8, Theme.soft());
            else if (hov) Ui.rr(c, px + 10, ty, SIDE - 12, 22, 8, Theme.window());
            Ui.rr(c, px + 17, ty + 5, 12, 12, 4, sel ? acc : Theme.track());
            Ui.circle(c, px + 23, ty + 11, 2.1, 0xFFFFFFFF);
            c.drawText(f, cats[i].label, px + 36, (int) ty + 7, sel ? Theme.text() : Theme.dim(), false);
        }

        // account manager button
        double acY = py + ph - 62;
        boolean hAccBtn = mx >= px + 10 && mx < px + SIDE - 2 && my >= acY && my < acY + 22;
        Ui.rr(c, px + 10, acY, SIDE - 12, 22, 11, hAccBtn ? acc : Theme.soft());
        String accLbl = "Аккаунты";
        c.drawText(f, accLbl, px + 10 + (SIDE - 12 - f.getWidth(accLbl)) / 2, (int) acY + 7,
                hAccBtn ? 0xFFFFFFFF : Theme.text(), false);
        if (hAccBtn) sideHint = "Менеджер аккаунтов: смена офлайн-ника";

        // theme + accent buttons
        boolean hTheme = Math.hypot(mx - themeCx, my - btnCy) <= 10;
        boolean hAcc = Math.hypot(mx - accentCx, my - btnCy) <= 10;
        Ui.circle(c, themeCx, btnCy, 10, hTheme ? Theme.track() : Theme.soft());
        Ui.circle(c, themeCx, btnCy, 5, Config.I.menuLight ? 0xFFF5B83D : 0xFFB8B8D8);
        if (!Config.I.menuLight) Ui.circle(c, themeCx + 2.5, btnCy - 1.5, 4.2, Theme.soft());
        Ui.circle(c, accentCx, btnCy, 10, hAcc ? Theme.track() : Theme.soft());
        Ui.circle(c, accentCx, btnCy, 5.5, acc);
        if (hTheme) sideHint = Config.I.menuLight ? "Тема: светлая (нажми, чтобы сменить)" : "Тема: тёмная (нажми, чтобы сменить)";
        if (hAcc) sideHint = "Цвет акцента: " + Theme.ACCENT_NAMES[Math.floorMod(Config.I.menuAccent, Theme.ACCENT_COUNT)];

        // ---- top bar
        c.drawText(f, "DobriVisual", cx, py + 12, Theme.dim(), false);
        int bw0 = f.getWidth("DobriVisual");
        c.drawText(f, "/", cx + bw0 + 6, py + 12, Theme.dim(), false);
        c.drawText(f, cat.label, cx + bw0 + 15, py + 12, Theme.text(), false);

        String collapse = "Свернуть всё";
        collapseW = f.getWidth(collapse) + 20;
        collapseX = px + pw - 12 - collapseW;
        boolean hCol = mx >= collapseX && mx < collapseX + collapseW && my >= py + 7 && my < py + 25;
        Ui.rr(c, collapseX, py + 7, collapseW, 18, 9, hCol ? Theme.track() : Theme.soft());
        c.drawText(f, collapse, (int) collapseX + 10, py + 12, Theme.text(), false);

        int on = 0;
        for (Card cd : cards) if (cd.m.isOn()) on++;
        String cnt = "Включено: " + on;
        double cntW = f.getWidth(cnt) + 20;
        Ui.rr(c, collapseX - 6 - cntW, py + 7, cntW, 18, 9, Theme.soft());
        c.drawText(f, cnt, (int) (collapseX - 6 - cntW) + 10, py + 12, Theme.dim(), false);

        // ---- cards
        boolean inClip = my >= cy && my < cy + ch;
        c.enableScissor(cx - 2, cy, cx + cw + 2, cy + ch);
        for (Card cd : cards) {
            if (cd.y + cd.h < cy - 2 || cd.y > cy + ch + 2) continue;
            drawCard(c, f, cd, mx, my, inClip);
        }
        c.disableScissor();

        if (contentH > ch) {
            int bh = Math.max(20, ch * ch / contentH);
            int by = cy + (ch - bh) * scroll / Math.max(1, contentH - ch);
            Ui.rr(c, px + pw - 7, by, 3, bh, 1.5, Theme.track());
        }

        // ---- description of the hovered function (top) and hint line (bottom)
        String top;
        int topCol = Theme.text();
        if (hovered != null) {
            top = hovered.desc;
        } else {
            top = "Наведи на функцию, чтобы увидеть описание";
            topCol = Theme.dim();
        }
        c.drawText(f, f.trimToWidth(top, cw), cx, py + 31, topCol, false);

        String hint;
        int hc = Theme.dim();
        if (capturing != null) {
            hint = "Нажми клавишу для " + capturing.name + "   |   Esc: отмена   |   Del: убрать";
            hc = acc;
        } else if (!sideHint.isEmpty()) {
            hint = sideHint;
        } else {
            hint = "ЛКМ: вкл/выкл   |   ПКМ или стрелка: настройки   |   Колёсико: клавиша";
        }
        c.drawText(f, f.trimToWidth(hint, cw), cx, py + ph - 16, hc, false);
    }

    private void drawCard(DrawContext c, TextRenderer f, Card cd, int mx, int my, boolean inClip) {
        Module m = cd.m;
        boolean on = m.isOn();
        boolean headHover = inClip && mx >= cd.x && mx < cd.x + cd.w && my >= cd.y && my < cd.y + HEADER;
        if (headHover) hovered = m;

        Ui.rr(c, cd.x - 0.5, cd.y - 0.5, cd.w + 1, cd.h + 1, 11, Theme.border());
        Ui.rr(c, cd.x, cd.y, cd.w, cd.h, 10.5, headHover ? Theme.cardHover() : Theme.card());

        int tx = (int) cd.x + 12;
        c.drawText(f, m.name, tx, (int) cd.y + 9, Theme.text(), false);
        double chevX = cd.x + cd.w - 28;
        double togX = chevX - 8 - 26;
        String bl = capturing == m ? "нажми клавишу..." : m.bindLabel();
        int descMax = (int) (togX - tx - 8);
        if (!bl.isEmpty()) descMax -= f.getWidth(bl) + 6;
        c.drawText(f, f.trimToWidth(m.desc, Math.max(20, descMax)), tx, (int) cd.y + 22, Theme.dim(), false);
        if (!bl.isEmpty()) {
            c.drawText(f, bl, (int) togX - 6 - f.getWidth(bl), (int) cd.y + 15,
                    capturing == m ? Theme.accent() : Theme.dim(), false);
        }

        // toggle switch
        double ty = cd.y + (HEADER - 14) / 2.0;
        Ui.rr(c, togX, ty, 26, 14, 7, on ? Theme.accent() : Theme.track());
        Ui.circle(c, on ? togX + 19 : togX + 7, ty + 7, 5.2, Theme.knob());

        // chevron button
        boolean chHover = inClip && mx >= chevX && mx < chevX + 20 && my >= cd.y + 10 && my < cd.y + 30;
        Ui.rr(c, chevX, cd.y + 10, 20, 20, 7, chHover ? Theme.track() : Theme.soft());
        Ui.chevron(c, chevX + 10, cd.y + 20, cd.expanded(), Theme.dim());

        if (cd.expanded()) {
            c.fill((int) cd.x + 12, (int) cd.y + HEADER, (int) (cd.x + cd.w - 12), (int) cd.y + HEADER + 1, Theme.border());
            int rmx = inClip ? mx : -1000, rmy = inClip ? my : -1000;
            for (Rows.Row r : rowsOf(m)) r.draw(c, f, rmx, rmy);
        }
    }

    // ---------------------------------------------------------------- input
    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y();
        int btn = click.button();
        geometry();

        if (capturing != null) {
            capturing = null;
            return true;
        }
        if (mx < px || mx > px + pw || my < py || my > py + ph) {
            close();
            return true;
        }

        // account manager
        double acY = py + ph - 62;
        if (mx >= px + 10 && mx < px + SIDE - 2 && my >= acY && my < acY + 22) {
            MinecraftClient.getInstance().setScreen(new AccountScreen(this));
            return true;
        }

        // theme / accent
        if (Math.hypot(mx - themeCx, my - btnCy) <= 10) {
            Config.I.menuLight = !Config.I.menuLight;
            return true;
        }
        if (Math.hypot(mx - accentCx, my - btnCy) <= 10) {
            Config.I.menuAccent = (Config.I.menuAccent + 1) % Theme.ACCENT_COUNT;
            return true;
        }

        // sidebar
        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++) {
            double ty = py + 58 + i * 25;
            if (mx >= px + 10 && mx < px + SIDE - 2 && my >= ty && my < ty + 22) {
                cat = cats[i];
                lastCat = cat;
                build();
                return true;
            }
        }

        // collapse all
        if (mx >= collapseX && mx < collapseX + collapseW && my >= py + 7 && my < py + 25) {
            EXPANDED.clear();
            scroll = 0;
            return true;
        }

        // cards
        if (my >= cy && my < cy + ch) {
            for (Card cd : cards) {
                if (mx < cd.x || mx >= cd.x + cd.w || my < cd.y || my >= cd.y + cd.h) continue;
                if (my < cd.y + HEADER) {
                    double chevX = cd.x + cd.w - 28;
                    if (mx >= chevX && mx < chevX + 20) {
                        cd.toggleExpand();
                    } else if (btn == 0) {
                        cd.m.toggle();
                    } else if (btn == 1) {
                        cd.toggleExpand();
                    } else if (btn == 2) {
                        capturing = cd.m;
                    }
                    return true;
                }
                if (cd.expanded()) {
                    for (Rows.Row r : rowsOf(cd.m)) {
                        if (r.hit(mx, my) && r.click(mx, my, btn)) {
                            dragging = r;
                            return true;
                        }
                    }
                }
                return true;
            }
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        if (dragging != null) {
            dragging.drag(click.x());
            return true;
        }
        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        dragging = null;
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        geometry();
        int max = Math.max(0, contentH - ch);
        scroll = MathHelper.clamp(scroll - (int) (verticalAmount * 16), 0, max);
        return true;
    }
}
