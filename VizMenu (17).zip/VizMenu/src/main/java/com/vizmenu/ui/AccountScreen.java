package com.vizmenu.ui;

import com.vizmenu.Accounts;
import com.vizmenu.Brand;
import com.vizmenu.Config;
import com.vizmenu.Logo;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

import java.util.Random;

/** Account manager (offline nicknames). */
public class AccountScreen extends Screen {
    private static final int ROW = 30;
    private final Screen parent;
    private TextFieldWidget field;
    private String message = "";
    private long messageAt = 0L;
    private int scroll = 0;
    private int px, py, pw, ph, lx, ly, lw, lh;
    private final Random rnd = new Random();

    public AccountScreen(Screen parent) {
        super(Text.literal("Аккаунты"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        field = new TextFieldWidget(textRenderer, 0, 0, 120, 14, Text.literal(""));
        field.setMaxLength(16);
        field.setDrawsBackground(false);
        addSelectableChild(field);
        setInitialFocus(field);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void close() {
        Config.save();
        MinecraftClient.getInstance().setScreen(parent);
    }

    @Override
    public void removed() {
        Config.save();
    }

    private void say(String s) {
        message = s;
        messageAt = System.currentTimeMillis();
    }

    private void geometry() {
        pw = Math.min(380, width - 8);
        ph = Math.min(300, height - 8);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        lx = px + 14;
        ly = py + 62;
        lw = pw - 28;
        lh = ph - 62 - 58;
    }

    private int totalRows() {
        return 1 + Config.I.accounts.size();
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        TextRenderer f = textRenderer;
        Ui.begin(mc);
        geometry();
        MenuBackground.draw(c, mc, width, height);

        Ui.rr(c, px - 1, py - 1, pw + 2, ph + 2, 15, Theme.border());
        Ui.rr(c, px, py, pw, ph, 14, Theme.window());

        Logo.draw(c, px + 14, py + 12, 22, Ui.sf);
        c.drawText(f, "Менеджер аккаунтов", px + 14 + 24, py + 13, Theme.text(), false);
        c.drawText(f, "Сейчас: " + Accounts.currentName(), px + 14 + 24, py + 25, Theme.accent(), false);

        String note = "Только офлайн-ники: для одиночной игры и серверов без проверки лицензии.";
        c.drawText(f, f.trimToWidth(note, pw - 28), px + 14, py + 44, Theme.dim(), false);

        // ---- list
        c.enableScissor(lx - 2, ly, lx + lw + 2, ly + lh);
        int total = totalRows();
        for (int i = 0; i < total; i++) {
            double ry = ly + i * (ROW + 4) - scroll;
            if (ry + ROW < ly || ry > ly + lh) continue;
            boolean original = i == 0;
            String name = original ? Accounts.originalName() : Config.I.accounts.get(i - 1);
            boolean active = name.equals(Accounts.currentName());
            Ui.rr(c, lx - 0.5, ry - 0.5, lw + 1, ROW + 1, 10, active ? Theme.accent() : Theme.border());
            Ui.rr(c, lx, ry, lw, ROW, 9.5, Theme.card());
            c.drawText(f, name, lx + 12, (int) ry + 7, Theme.text(), false);
            c.drawText(f, original ? "оригинальный аккаунт" : "офлайн", lx + 12, (int) ry + 18, Theme.dim(), false);

            double bw = 82, bx = lx + lw - bw - (original ? 8 : 34), by = ry + 5;
            boolean hv = mx >= bx && mx < bx + bw && my >= by && my < by + 20;
            Ui.rr(c, bx, by, bw, 20, 10, active ? Theme.soft() : (hv ? Theme.accent() : Theme.soft()));
            String lbl = active ? "Выбран" : "Использовать";
            c.drawText(f, lbl, (int) (bx + (bw - f.getWidth(lbl)) / 2), (int) by + 6,
                    active ? Theme.dim() : (hv ? 0xFFFFFFFF : Theme.text()), false);
            if (!original) {
                double dx = lx + lw - 26, dy = ry + 5;
                boolean hd = mx >= dx && mx < dx + 20 && my >= dy && my < dy + 20;
                Ui.circle(c, dx + 10, dy + 10, 10, hd ? 0xFFEF4444 : Theme.soft());
                c.drawText(f, "x", (int) dx + 7, (int) dy + 6, hd ? 0xFFFFFFFF : Theme.dim(), false);
            }
        }
        c.disableScissor();

        // ---- input row
        double iy = py + ph - 48;
        Ui.rr(c, lx, iy, lw - 188, 24, 12, Theme.soft());
        field.setX(lx + 12);
        field.setY((int) iy + 8);
        field.setWidth(lw - 188 - 24);
        field.render(c, mx, my, delta);
        if (field.getText().isEmpty() && !field.isFocused()) {
            c.drawText(f, "Новый ник (3-16 символов)", lx + 12, (int) iy + 8, Theme.dim(), false);
        }
        double ax = lx + lw - 182;
        pillButton(c, f, ax, iy, 62, "Добавить", mx, my);
        pillButton(c, f, ax + 66, iy, 54, "Случайный", mx, my);
        pillButton(c, f, ax + 124, iy, 58, "Оригинал", mx, my);

        // ---- footer / messages
        String foot = System.currentTimeMillis() - messageAt < 3500L && !message.isEmpty()
                ? message : "Esc: назад   |   смена аккаунта действует сразу";
        c.drawText(f, f.trimToWidth(foot, pw - 28), px + 14, py + ph - 16, Theme.dim(), false);
    }

    private void pillButton(DrawContext c, TextRenderer f, double x, double y, double w, String label, int mx, int my) {
        boolean hv = mx >= x && mx < x + w && my >= y && my < y + 24;
        Ui.rr(c, x, y, w, 24, 12, hv ? Theme.accent() : Theme.soft());
        c.drawText(f, label, (int) (x + (w - f.getWidth(label)) / 2), (int) y + 8, hv ? 0xFFFFFFFF : Theme.text(), false);
    }

    private void addName(String name) {
        if (!Accounts.validName(name)) {
            say("Ник: 3-16 символов, только латиница, цифры и _");
            return;
        }
        if (!Config.I.accounts.contains(name)) Config.I.accounts.add(name);
        field.setText("");
        say("Добавлено: " + name);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y();
        geometry();
        if (click.button() == 0) {
            // list
            if (my >= ly && my < ly + lh && mx >= lx && mx < lx + lw) {
                int total = totalRows();
                for (int i = 0; i < total; i++) {
                    double ry = ly + i * (ROW + 4) - scroll;
                    if (my < ry || my >= ry + ROW) continue;
                    boolean original = i == 0;
                    String name = original ? Accounts.originalName() : Config.I.accounts.get(i - 1);
                    double bw = 82, bx = lx + lw - bw - (original ? 8 : 34), by = ry + 5;
                    if (mx >= bx && mx < bx + bw && my >= by && my < by + 20) {
                        boolean ok = original ? Accounts.restoreOriginal() : Accounts.useOffline(name);
                        say(ok ? "Аккаунт: " + Accounts.currentName() : "Не удалось сменить аккаунт");
                        return true;
                    }
                    if (!original && mx >= lx + lw - 26 && mx < lx + lw - 6) {
                        Config.I.accounts.remove(i - 1);
                        say("Удалено: " + name);
                        return true;
                    }
                    return true;
                }
            }
            // input row buttons
            double iy = py + ph - 48, ax = lx + lw - 182;
            if (my >= iy && my < iy + 24) {
                if (mx >= ax && mx < ax + 62) {
                    addName(field.getText().trim());
                    return true;
                }
                if (mx >= ax + 66 && mx < ax + 120) {
                    field.setText("Dobri" + (1000 + rnd.nextInt(9000)));
                    return true;
                }
                if (mx >= ax + 124 && mx < ax + 182) {
                    boolean ok = Accounts.restoreOriginal();
                    say(ok ? "Вернулся оригинальный аккаунт: " + Accounts.currentName() : "Не удалось вернуть аккаунт");
                    return true;
                }
            }
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        geometry();
        int max = Math.max(0, totalRows() * (ROW + 4) - lh);
        scroll = MathHelper.clamp(scroll - (int) (verticalAmount * 16), 0, max);
        return true;
    }
}
