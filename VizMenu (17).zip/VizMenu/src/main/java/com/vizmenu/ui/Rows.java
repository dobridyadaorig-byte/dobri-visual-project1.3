package com.vizmenu.ui;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleFunction;
import java.util.function.DoubleSupplier;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

/** Setting rows shown inside an expanded module card (rounded, theme aware). */
final class Rows {
    private Rows() {}

    abstract static class Row {
        int x, y, w;
        int h;

        Row(int h) { this.h = h; }

        abstract void draw(DrawContext c, TextRenderer f, int mx, int my);

        boolean click(double mx, double my, int btn) { return false; }

        void drag(double mx) { }

        boolean hit(double mx, double my) {
            return mx >= x && mx < x + w && my >= y && my < y + h;
        }
    }

    static class Label extends Row {
        final String text;

        Label(String text) { super(14); this.text = text; }

        @Override
        void draw(DrawContext c, TextRenderer f, int mx, int my) {
            c.drawText(f, text, x, y + 3, Theme.dim(), false);
        }
    }

    static class Toggle extends Row {
        final String label;
        final BooleanSupplier get;
        final Consumer<Boolean> set;

        Toggle(String label, BooleanSupplier get, Consumer<Boolean> set) {
            super(24);
            this.label = label; this.get = get; this.set = set;
        }

        @Override
        void draw(DrawContext c, TextRenderer f, int mx, int my) {
            c.drawText(f, label, x, y + (h - 8) / 2, Theme.text(), false);
            boolean on = get.getAsBoolean();
            double tx = x + w - 26, ty = y + (h - 14) / 2.0;
            Ui.rr(c, tx, ty, 26, 14, 7, on ? Theme.accent() : Theme.track());
            Ui.circle(c, on ? tx + 19 : tx + 7, ty + 7, 5.2, Theme.knob());
        }

        @Override
        boolean click(double mx, double my, int btn) {
            if (btn != 0) return false;
            set.accept(!get.getAsBoolean());
            return true;
        }
    }

    static class Cycle extends Row {
        final String label;
        final String[] opts;
        final IntSupplier get;
        final IntConsumer set;

        Cycle(String label, String[] opts, IntSupplier get, IntConsumer set) {
            super(26);
            this.label = label; this.opts = opts; this.get = get; this.set = set;
        }

        @Override
        void draw(DrawContext c, TextRenderer f, int mx, int my) {
            c.drawText(f, label, x, y + (h - 8) / 2, Theme.text(), false);
            String t = opts[MathHelper.clamp(get.getAsInt(), 0, opts.length - 1)];
            int pw = Math.max(64, f.getWidth(t) + 28);
            double bx = x + w - pw;
            Ui.rr(c, bx, y + 2, pw, h - 4, 7, hit(mx, my) ? Theme.track() : Theme.soft());
            c.drawText(f, t, (int) bx + 9, y + (h - 8) / 2, Theme.text(), false);
            Ui.chevron(c, bx + pw - 11, y + h / 2.0, true, Theme.dim());
        }

        @Override
        boolean click(double mx, double my, int btn) {
            int n = opts.length;
            int cur = get.getAsInt();
            if (btn == 0) set.accept((cur + 1) % n);
            else if (btn == 1) set.accept((cur + n - 1) % n);
            else return false;
            return true;
        }
    }

    static class Buttons extends Row {
        final String[] labels;
        final IntConsumer action;

        Buttons(String[] labels, IntConsumer action) {
            super(26);
            this.labels = labels; this.action = action;
        }

        private double bw() { return (w - (labels.length - 1) * 4.0) / labels.length; }

        @Override
        void draw(DrawContext c, TextRenderer f, int mx, int my) {
            double bw = bw();
            for (int i = 0; i < labels.length; i++) {
                double bx = x + i * (bw + 4);
                boolean hov = mx >= bx && mx < bx + bw && my >= y && my < y + h;
                Ui.rr(c, bx, y + 2, bw, h - 4, 7, hov ? Theme.accent() : Theme.soft());
                c.drawText(f, labels[i], (int) (bx + (bw - f.getWidth(labels[i])) / 2), y + (h - 8) / 2,
                        hov ? 0xFFFFFFFF : Theme.text(), false);
            }
        }

        @Override
        boolean click(double mx, double my, int btn) {
            if (btn != 0) return false;
            double bw = bw();
            for (int i = 0; i < labels.length; i++) {
                double bx = x + i * (bw + 4);
                if (mx >= bx && mx < bx + bw) {
                    action.accept(i);
                    return true;
                }
            }
            return false;
        }
    }

    static class Slider extends Row {
        final String label;
        final double min, max, step;
        final DoubleSupplier get;
        final DoubleConsumer set;
        final DoubleFunction<String> fmt;
        final IntSupplier knob;

        Slider(String label, double min, double max, double step, DoubleSupplier get,
               DoubleConsumer set, DoubleFunction<String> fmt, IntSupplier knob) {
            super(30);
            this.label = label; this.min = min; this.max = max; this.step = step;
            this.get = get; this.set = set; this.fmt = fmt; this.knob = knob;
        }

        @Override
        void draw(DrawContext c, TextRenderer f, int mx, int my) {
            double v = get.getAsDouble();
            String vs = fmt.apply(v);
            int acc = knob != null ? knob.getAsInt() : Theme.accent();
            c.drawText(f, label, x, y + 2, Theme.text(), false);
            c.drawText(f, vs, x + w - f.getWidth(vs), y + 2, acc, false);
            double t = MathHelper.clamp((v - min) / (max - min), 0, 1);
            double ty = y + 19.0;
            Ui.rr(c, x, ty - 1.5, w, 3, 1.5, Theme.track());
            double fw = w * t;
            if (fw > 0.5) Ui.rr(c, x, ty - 1.5, fw, 3, 1.5, acc);
            double kx = x + fw;
            Ui.circle(c, kx, ty, 5.2, acc);
            Ui.circle(c, kx, ty, 3.2, Theme.knob());
        }

        @Override
        boolean click(double mx, double my, int btn) {
            if (btn != 0) return false;
            drag(mx);
            return true;
        }

        @Override
        void drag(double mx) {
            double t = MathHelper.clamp((mx - x) / (double) w, 0, 1);
            double v = min + t * (max - min);
            v = Math.round(v / step) * step;
            v = MathHelper.clamp(v, min, max);
            set.accept(v);
        }
    }

    /** Colour picker: swatch + hex in the header, presets and hue / saturation / brightness strips when open. */
    static class ColorRow extends Row {
        static final int HEAD = 26, OPEN_H = 104;
        static final int[] PRESETS = {0xFFFFFF, 0xEF4444, 0xF97316, 0xFACC15, 0x22C55E, 0x06B6D4, 0x3B82F6, 0x8B5CF6, 0xEC4899, 0x111111};
        final String label;
        final IntSupplier get;
        final IntConsumer set;
        boolean open;
        final float[] hsv = {0f, 1f, 1f};
        int lastRgb = -1;
        int strip = -1;
        String hex = "";

        ColorRow(String label, IntSupplier get, IntConsumer set) {
            super(HEAD);
            this.label = label; this.get = get; this.set = set;
        }

        private static float[] toHsv(int rgb) {
            float r = ((rgb >> 16) & 255) / 255f, g = ((rgb >> 8) & 255) / 255f, b = (rgb & 255) / 255f;
            float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b));
            float d = max - min, hh = 0f;
            if (d > 1e-6f) {
                if (max == r) hh = ((g - b) / d) % 6f;
                else if (max == g) hh = (b - r) / d + 2f;
                else hh = (r - g) / d + 4f;
                hh /= 6f;
                if (hh < 0f) hh += 1f;
            }
            return new float[]{hh, max <= 0f ? 0f : d / max, max};
        }

        private void sync(int rgb) {
            if (rgb == lastRgb) return;
            lastRgb = rgb;
            hex = String.format("#%06X", rgb);
            float[] t = toHsv(rgb);
            hsv[1] = t[1];
            hsv[2] = t[2];
            if (t[1] > 0.01f && t[2] > 0.01f) hsv[0] = t[0];
        }

        private void apply() {
            int rgb = MathHelper.hsvToRgb(hsv[0], hsv[1], hsv[2]) & 0xFFFFFF;
            lastRgb = rgb;
            hex = String.format("#%06X", rgb);
            set.accept(rgb);
        }

        private void strip(DrawContext c, double sy, int kind) {
            int n = 40;
            Ui.rr(c, x, sy, w, 8, 4, Theme.border());
            double x0 = x + 1, ww = w - 2;
            for (int i = 0; i < n; i++) {
                int xa = (int) Math.round(x0 + ww * i / n), xb = (int) Math.round(x0 + ww * (i + 1) / n);
                if (xb <= xa) xb = xa + 1;
                float t = (i + 0.5f) / n;
                int col = kind == 0 ? MathHelper.hsvToRgb(t, 1f, 1f)
                        : (kind == 1 ? MathHelper.hsvToRgb(hsv[0], t, hsv[2]) : MathHelper.hsvToRgb(hsv[0], hsv[1], t));
                c.fill(xa, (int) sy + 1, xb, (int) sy + 7, 0xFF000000 | (col & 0xFFFFFF));
            }
            double kx = x + w * hsv[kind];
            Ui.circle(c, kx, sy + 4, 6.4, 0xFFFFFFFF);
            Ui.circle(c, kx, sy + 4, 4.4, 0xFF000000 | lastRgb);
        }

        @Override
        void draw(DrawContext c, TextRenderer f, int mx, int my) {
            int rgb = get.getAsInt() & 0xFFFFFF;
            sync(rgb);
            c.drawText(f, label, x, y + 9, Theme.text(), false);
            double sw = 66, sx = x + w - sw;
            Ui.rr(c, sx - 1, y + 2, sw + 2, 22, 9, Theme.border());
            Ui.rr(c, sx, y + 3, sw, 20, 8, 0xFF000000 | rgb);
            int lum = (((rgb >> 16) & 255) * 299 + ((rgb >> 8) & 255) * 587 + (rgb & 255) * 114) / 1000;
            c.drawText(f, hex, (int) (sx + (sw - f.getWidth(hex)) / 2), y + 9, lum > 150 ? 0xFF111111 : 0xFFFFFFFF, false);
            if (!open) return;

            double y0 = y + HEAD + 2;
            for (int i = 0; i < PRESETS.length; i++) {
                double px = x + 7 + i * ((w - 14) / (PRESETS.length - 1.0));
                boolean sel = PRESETS[i] == rgb;
                Ui.circle(c, px, y0 + 8, 7.6, sel ? Theme.text() : Theme.border());
                Ui.circle(c, px, y0 + 8, 6.2, 0xFF000000 | PRESETS[i]);
            }
            strip(c, y0 + 24, 0);
            strip(c, y0 + 42, 1);
            strip(c, y0 + 60, 2);
        }

        private void applyStrip(double mx) {
            if (strip < 0) return;
            hsv[strip] = (float) MathHelper.clamp((mx - x) / (double) w, 0.0, 1.0);
            apply();
        }

        @Override
        boolean click(double mx, double my, int btn) {
            if (btn != 0) return false;
            strip = -1;
            if (my < y + HEAD) {
                open = !open;
                h = open ? OPEN_H : HEAD;
                return true;
            }
            if (!open) return false;
            double y0 = y + HEAD + 2;
            if (my >= y0 && my < y0 + 17) {
                for (int i = 0; i < PRESETS.length; i++) {
                    double px = x + 7 + i * ((w - 14) / (PRESETS.length - 1.0));
                    if (Math.abs(mx - px) <= 8) {
                        lastRgb = PRESETS[i];
                        hex = String.format("#%06X", lastRgb);
                        float[] t = toHsv(lastRgb);
                        hsv[1] = t[1];
                        hsv[2] = t[2];
                        if (t[1] > 0.01f && t[2] > 0.01f) hsv[0] = t[0];
                        set.accept(lastRgb);
                        return true;
                    }
                }
            }
            for (int k = 0; k < 3; k++) {
                double sy = y0 + 24 + 18 * k;
                if (my >= sy - 4 && my < sy + 12) {
                    strip = k;
                    applyStrip(mx);
                    return true;
                }
            }
            return false;
        }

        @Override
        void drag(double mx) {
            applyStrip(mx);
        }
    }
}
