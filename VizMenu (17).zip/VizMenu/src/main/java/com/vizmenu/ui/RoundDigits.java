package com.vizmenu.ui;

import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Clock digits drawn from the real Fredoka outlines (rounded font), independent of the game font.
 * Glyphs are rasterised once per size into a few rectangles and then drawn with plain fills.
 * Coordinates are in device pixels (the caller scales the matrix by 1 / guiScale).
 */
public final class RoundDigits {
    private static final float[][][] OUT = new float[11][][]; // glyph -> contours -> x,y,x,y...
    private static final float[] GW = new float[11];
    private static float maxDigitW = 1f;
    private static final float GAP = 0.30f;

    private static final class Glyphs {
        int pad, h;
        final int[] w = new int[11];
        final int[][] rects = new int[11][];
    }

    private static final Map<Integer, Glyphs> CACHE = new HashMap<>();

    static {
        for (int g = 0; g < 11; g++) {
            String s = FredokaOutlines.DATA[g];
            int t = s.indexOf('~');
            GW[g] = Float.parseFloat(s.substring(0, t));
            String[] contours = s.substring(t + 1).split("\\|");
            OUT[g] = new float[contours.length][];
            for (int i = 0; i < contours.length; i++) {
                String[] v = contours[i].trim().split(" ");
                float[] a = new float[v.length];
                for (int k = 0; k < v.length; k++) a[k] = Float.parseFloat(v[k]);
                OUT[g][i] = a;
            }
            if (g < 10) maxDigitW = Math.max(maxDigitW, GW[g]);
        }
    }

    private RoundDigits() {}

    // ---------------------------------------------------------------- rasterising
    private static boolean[][] raster(int glyph, int unit, int pad, int w, int h, double offUnits) {
        boolean[][] bm = new boolean[h][w];
        float[][] cs = OUT[glyph];
        int edges = 0;
        for (float[] c : cs) edges += c.length / 2;
        double[] ex0 = new double[edges], ey0 = new double[edges], ex1 = new double[edges], ey1 = new double[edges];
        int n = 0;
        for (float[] c : cs) {
            int pts = c.length / 2;
            for (int i = 0; i < pts; i++) {
                int j = (i + 1) % pts;
                ex0[n] = (c[i * 2] + offUnits) * unit + pad;
                ey0[n] = c[i * 2 + 1] * unit + pad;
                ex1[n] = (c[j * 2] + offUnits) * unit + pad;
                ey1[n] = c[j * 2 + 1] * unit + pad;
                n++;
            }
        }
        double[] xs = new double[edges + 2];
        int[] ds = new int[edges + 2];
        for (int y = 0; y < h; y++) {
            double yc = y + 0.5;
            int k = 0;
            for (int e = 0; e < n; e++) {
                double y0 = ey0[e], y1 = ey1[e];
                if ((y0 <= yc && y1 > yc) || (y1 <= yc && y0 > yc)) {
                    double x = ex0[e] + (yc - y0) / (y1 - y0) * (ex1[e] - ex0[e]);
                    int d = y1 > y0 ? 1 : -1;
                    int p = k++;
                    while (p > 0 && xs[p - 1] > x) {
                        xs[p] = xs[p - 1];
                        ds[p] = ds[p - 1];
                        p--;
                    }
                    xs[p] = x;
                    ds[p] = d;
                }
            }
            int wind = 0;
            for (int i = 0; i < k - 1; i++) {
                wind += ds[i];
                if (wind != 0) {
                    int xa = Math.max(0, (int) Math.ceil(xs[i] - 0.5));
                    int xb = Math.min(w - 1, (int) Math.floor(xs[i + 1] - 0.5));
                    for (int x = xa; x <= xb; x++) bm[y][x] = true;
                }
            }
        }
        return bm;
    }

    private static int[] runs(boolean[] row) {
        List<Integer> l = new ArrayList<>();
        int x = 0;
        while (x < row.length) {
            if (row[x]) {
                int s = x;
                while (x < row.length && row[x]) x++;
                l.add(s);
                l.add(x);
            } else {
                x++;
            }
        }
        int[] r = new int[l.size()];
        for (int i = 0; i < r.length; i++) r[i] = l.get(i);
        return r;
    }

    private static int[] toRects(boolean[][] bm) {
        List<Integer> out = new ArrayList<>();
        int[] prev = new int[0];
        int start = 0;
        for (int y = 0; y <= bm.length; y++) {
            int[] cur = y < bm.length ? runs(bm[y]) : new int[0];
            if (y == 0) {
                prev = cur;
                start = 0;
                continue;
            }
            if (!Arrays.equals(cur, prev)) {
                for (int i = 0; i < prev.length; i += 2) {
                    out.add(prev[i]);
                    out.add(start);
                    out.add(prev[i + 1]);
                    out.add(y);
                }
                prev = cur;
                start = y;
            }
        }
        int[] r = new int[out.size()];
        for (int i = 0; i < r.length; i++) r[i] = out.get(i);
        return r;
    }

    private static Glyphs glyphs(int unit) {
        Glyphs g = CACHE.get(unit);
        if (g != null) return g;
        if (CACHE.size() > 6) CACHE.clear();
        g = new Glyphs();
        g.pad = 2;
        g.h = 2 * unit + 2 * g.pad;
        for (int d = 0; d <= 10; d++) {
            double cell = d == 10 ? GW[10] : maxDigitW;
            int gw = (int) Math.ceil(cell * unit) + 2 * g.pad;
            double off = d == 10 ? 0.0 : (maxDigitW - GW[d]) / 2.0;
            g.w[d] = gw;
            g.rects[d] = toRects(raster(d, unit, g.pad, gw, g.h, off));
        }
        CACHE.put(unit, g);
        return g;
    }

    // ---------------------------------------------------------------- public api
    private static int index(char ch) {
        if (ch >= '0' && ch <= '9') return ch - '0';
        return ch == ':' ? 10 : -1;
    }

    public static int advance(char ch, int unit) {
        int i = index(ch);
        if (i < 0) return Math.round(unit * 0.5f);
        return Math.round(((i == 10 ? GW[10] : maxDigitW) + GAP) * unit);
    }

    public static int width(String s, int unit) {
        int w = 0;
        for (int i = 0; i < s.length(); i++) w += advance(s.charAt(i), unit);
        return w - Math.round(GAP * unit);
    }

    public static int height(int unit) {
        return 2 * unit;
    }

    public static int pad(int unit) {
        return glyphs(unit).pad;
    }

    /** Draws one glyph with its cell origin at (x, y); returns the advance. */
    public static int drawChar(DrawContext ctx, char ch, int x, int y, int unit, int color) {
        int i = index(ch);
        if (i >= 0) {
            Glyphs g = glyphs(unit);
            int ox = x - g.pad, oy = y - g.pad;
            int[] r = g.rects[i];
            for (int k = 0; k + 3 < r.length; k += 4) {
                ctx.fill(ox + r[k], oy + r[k + 1], ox + r[k + 2], oy + r[k + 3], color);
            }
        }
        return advance(ch, unit);
    }
}
