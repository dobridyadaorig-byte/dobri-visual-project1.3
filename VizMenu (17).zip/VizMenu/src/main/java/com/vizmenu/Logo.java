package com.vizmenu;

import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

/** The DobriVisual logo (pixel art), drawn with plain fills so it stays crisp at any GUI scale. */
public final class Logo {
    public static final int W = 14, H = 15;
    private static final int[] PIX = {
        0x00000000, 0x00000000, 0xFF22073D, 0xFF22073D, 0xFF22073D, 0xFF22073D, 0xFF22073E, 0xFF23083F, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000,
        0x00000000, 0xFF22073D, 0xFF8F36DB, 0xFF601DA3, 0xFF8D36DA, 0xFF8D35DA, 0xFF601DA1, 0xFF8D36DA, 0xFF300A54, 0xFF320B56, 0x00000000, 0xFFCFC4D9, 0xFF8A7C98, 0x00000000,
        0xFF22073C, 0xFF22073C, 0xFF1C0830, 0xFF1C0731, 0xFF1C0731, 0xFF1C0831, 0xFF1C0831, 0xFF1C0830, 0xFF7F2CCA, 0xFF0C0315, 0xFF8D36DA, 0xFF1D0832, 0xFF1A072D, 0x00000000,
        0xFF21073A, 0xFFAC9FB9, 0xFF0E0319, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0xFF160526, 0xFFBFAAD4, 0xFF10041B, 0xFF5B1B9B, 0x00000000, 0x00000000,
        0xFF21073B, 0xFFAC9FB8, 0xFF0F031A, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0xFF8C35D8, 0xFF140523, 0xFFC0ACD4, 0xFF150524, 0x00000000, 0x00000000,
        0x00000000, 0xFF20073A, 0xFFAFA2BB, 0xFF19072C, 0x00000000, 0x00000000, 0x00000000, 0xFF8E37DC, 0xFF1B072F, 0x00000000, 0xFF150525, 0xFF7A2AC5, 0xFF23073F, 0x00000000,
        0x00000000, 0x00000000, 0xFFAEA1BB, 0xFF1A072C, 0x00000000, 0x00000000, 0xFF8D36DB, 0xFF160626, 0x00000000, 0x00000000, 0x00000000, 0xFF21073C, 0xFF8F37DB, 0xFF21073C,
        0x00000000, 0x00000000, 0xFFADA1BA, 0xFF1A072D, 0x00000000, 0xFF8D36DB, 0xFF1C0732, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0xFF21073C, 0xFF621EA4, 0xFF22073C,
        0x00000000, 0x00000000, 0xFFAC9FB8, 0xFF19072C, 0xFF8D37DA, 0xFF1C0832, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0xFF21073C, 0xFF8F35DB, 0xFF22073C,
        0x00000000, 0x00000000, 0xFF3A1A5D, 0xFFAFA2BC, 0xFF1C0832, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0xFF22073C, 0xFF8E36DB, 0xFF22073C,
        0x00000000, 0x00000000, 0xFF2E084D, 0xFF9182A1, 0xFF1E0933, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0xFF22073C, 0xFF8F36DA, 0xFF21073B,
        0x00000000, 0x00000000, 0x00000000, 0xFF2E0950, 0xFF897B97, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0xFF22073C, 0xFF641FA7, 0xFF21073B,
        0x00000000, 0x00000000, 0x00000000, 0x00000000, 0xFF2A0849, 0xFFAC9FB9, 0xFFAA9EB8, 0xFFA99CB6, 0xFFA69AB4, 0x00000000, 0x00000000, 0xFF22073C, 0xFF8F36DB, 0xFF22073C,
        0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0xFF1C0830, 0xFFAFA2BB, 0xFFAEA2BB, 0xFF22073C, 0xFF8D34D9, 0xFF21073A,
        0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0xFF21073C, 0xFF22073C, 0xFF21073C, 0xFF22073D, 0x00000000,
    };

    /** Horizontal runs {x0, x1, y, argb}. */
    private static final int[][] RUNS;

    static {
        List<int[]> l = new ArrayList<>();
        for (int y = 0; y < H; y++) {
            int x = 0;
            while (x < W) {
                int c = PIX[y * W + x];
                if (c == 0) { x++; continue; }
                int s = x;
                while (x < W && PIX[y * W + x] == c) x++;
                l.add(new int[]{s, x, y, c});
            }
        }
        RUNS = l.toArray(new int[0][]);
    }

    private Logo() {}

    /** Width in GUI units for a logo that is {@code size} GUI units tall. */
    public static double widthFor(double size) {
        return size * W / H;
    }

    /** Draws the logo with its top-left corner at (x, y) in GUI units, {@code size} units tall. */
    public static void draw(DrawContext ctx, double x, double y, double size, double sf) {
        int cell = Math.max(1, (int) Math.round(size * sf / H));
        int ox = (int) Math.round(x * sf), oy = (int) Math.round(y * sf);
        ctx.getMatrices().pushMatrix();
        float inv = (float) (1.0 / sf);
        ctx.getMatrices().scale(inv, inv);
        for (int[] r : RUNS) {
            ctx.fill(ox + r[0] * cell, oy + r[2] * cell, ox + r[1] * cell, oy + (r[2] + 1) * cell, r[3]);
        }
        ctx.getMatrices().popMatrix();
    }
}
